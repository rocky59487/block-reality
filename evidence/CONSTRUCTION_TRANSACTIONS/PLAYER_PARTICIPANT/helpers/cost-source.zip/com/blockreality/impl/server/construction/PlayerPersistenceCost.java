package com.blockreality.impl.server.construction;

import net.minecraft.nbt.*;
import java.nio.file.*;
import java.util.*;
import java.lang.management.ManagementFactory;
import java.security.MessageDigest;

/** External measurement helper; never a production source or jar entry. */
public final class PlayerPersistenceCost {
    public static void main(String[] args) throws Exception {
        Path root = Path.of(args[0]); Files.createDirectory(root);
        UUID actor = new UUID(11, 12);
        var bean = (com.sun.management.ThreadMXBean) ManagementFactory.getThreadMXBean();
        if (!bean.isThreadAllocatedMemoryEnabled()) bean.setThreadAllocatedMemoryEnabled(true);
        List<String> csv = new ArrayList<>(); csv.add("fixture,iteration,phase,warmup,nanos,allocated_bytes,compressed_bytes,canonical_sha256");
        for (String fixture : List.of("two-slots", "forty-one-slots", "forty-one-with-16k-tags")) {
            var store = new PlayerFileParticipant(root.resolve(fixture));
            CompoundTag player = new CompoundTag(); player.putUUID("UUID", actor); player.putInt("DataVersion", 3465);
            player.putString("Dimension", "minecraft:overworld"); player.putFloat("Health", 17.5f);
            CompoundTag unrelated = new CompoundTag(); unrelated.putString("custom", "preserve"); player.put("ForgeData", unrelated);
            ListTag inventory = new ListTag(); Random random = new Random(42);
            for (int slot = 0; slot < (fixture.equals("two-slots") ? 2 : 41); slot++) {
                CompoundTag item = new CompoundTag(); item.putByte("Slot", (byte) (slot < 36 ? slot : slot < 40 ? slot + 64 : 150));
                item.putString("id", "blockreality:steel"); item.putByte("Count", (byte) 10);
                CompoundTag tag = new CompoundTag(); tag.putString("display", "鋼骨 " + slot);
                if (fixture.endsWith("tags")) { byte[] payload = new byte[16384]; random.nextBytes(payload); tag.putByteArray("custom", payload); }
                item.put("tag", tag); inventory.add(item);
            }
            player.put("Inventory", inventory); store.write(store.capture(actor), player);
            for (int iteration = 0; iteration < 48; iteration++) for (String phase : List.of("checkpoint", "commit")) {
                // File-level simulation: real full-file writes, no Minecraft player/chunk/server.
                player.putInt("XpTotal", 2 * iteration + (phase.equals("commit") ? 1 : 0));
                inventory.getCompound(0).putByte("Count", (byte) (phase.equals("commit") ? 9 : 10));
                long bytes = bean.getCurrentThreadAllocatedBytes(), start = System.nanoTime();
                var saved = store.write(store.capture(actor), player);
                long nanos = System.nanoTime() - start, allocated = bean.getCurrentThreadAllocatedBytes() - bytes;
                byte[] expected = CanonicalNbt.encode(player, CanonicalNbt.MAX_DOCUMENT_BYTES);
                if (!Arrays.equals(expected, CanonicalNbt.encode(saved.data(), CanonicalNbt.MAX_DOCUMENT_BYTES))) throw new AssertionError("image changed");
                String hash = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(expected));
                csv.add(String.join(",", fixture, "" + iteration, phase, "" + (iteration < 8), "" + nanos, "" + allocated,
                        "" + Files.size(root.resolve(fixture).resolve(actor + ".dat")), hash));
            }
        }
        Files.write(root.resolve("samples.csv"), csv);
        Files.writeString(root.resolve("scope.txt"), "Recorded only. One JVM;3 deterministic NBT fixtures;8 warmups+40 measured pairs each.\n"
                + "Each phase times capture+canonical gzip/atomic replace/force/reload verification and thread allocation.\n"
                + "File-level simulated checkpoint/commit; no Forge server, live inventory, chunk, UI, native engine or FPS qualification.\n"
                + "os=" + System.getProperty("os.name") + ";java=" + System.getProperty("java.version") + "\n");
        System.out.println("Recorded288 player writes;240 measured; all exact NBT comparisons passed");
    }
}
