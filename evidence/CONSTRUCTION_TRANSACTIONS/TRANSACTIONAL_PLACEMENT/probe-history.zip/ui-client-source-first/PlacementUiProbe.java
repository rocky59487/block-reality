package com.blockreality.impl.client;

import com.google.gson.*;
import io.netty.channel.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.minecraft.commands.arguments.EntityAnchorArgument;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.Connection;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.protocol.game.*;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.*;
import net.minecraftforge.api.distmarker.*;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import java.lang.reflect.Field;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import org.lwjgl.opengl.GL11;

/** Owned synthetic Linux development client only; never added to ordinary builds. */
@OnlyIn(Dist.CLIENT)
@Mod.EventBusSubscriber(modid="blockreality", value=Dist.CLIENT)
public final class PlacementUiProbe {
    private static final Gson JSON=new GsonBuilder().setPrettyPrinting().create();
    private static final String ADDRESS="127.0.0.1:25630";
    private static final List<Map<String,Object>> frames=new CopyOnWriteArrayList<>();
    private static final AtomicBoolean dropOutcome=new AtomicBoolean();
    private static Path out;
    private static long started,handled;
    private static int ticks,warmFrames;
    private static boolean joined,writing;
    private static Connection tapped;
    private static JsonObject capture;
    private static CompletableFuture<Void> reload=CompletableFuture.completedFuture(null);

    @SubscribeEvent public static void tick(TickEvent.ClientTickEvent event) {
        if(event.phase!=TickEvent.Phase.END || !Boolean.getBoolean("br.placementUiProbe"))return;
        Minecraft mc=Minecraft.getInstance();
        try {
            if(out==null) {
                out=Path.of(System.getProperty("br.placementUiOutput"));
                require(Files.readString(out.resolve("OWNER")).strip().equals("block-reality-placement-ui-v1"),"owned client output");
                started=System.nanoTime();mc.options.pauseOnLostFocus=false;
                mc.options.framerateLimit().set(30);mc.options.enableVsync().set(false);
                mc.getWindow().setTitle("Block Reality isolated placement qualification");
            }
            require(System.nanoTime()-started<900_000_000_000L,"client deadline");
            if(!joined && mc.screen instanceof TitleScreen && mc.getOverlay()==null) {
                joined=true;ConnectScreen.startConnecting(mc.screen,mc,ServerAddress.parseString(ADDRESS),new ServerData("Owned placement fixture",ADDRESS,false),false);
            }
            if(mc.getConnection()!=null && tapped!=mc.getConnection().getConnection())tap(mc.getConnection().getConnection());
            if(++ticks%10==0) {
                Files.writeString(out.resolve("state.next"),JSON.toJson(state(mc)));
                Files.move(out.resolve("state.next"),out.resolve("state.json"),StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);
            }
            if(capture!=null || writing || !reload.isDone() || !Files.exists(out.resolve("control.json")))return;
            reload.join();String raw=Files.readString(out.resolve("control.json"));require(raw.length()<4096,"bounded fixture command");
            JsonObject command=JsonParser.parseString(raw).getAsJsonObject();long id=command.get("id").getAsLong();
            if(id==handled)return;require(id>handled,"ordered fixture command");
            String action=command.get("action").getAsString(),name=command.get("name").getAsString();
            require(name.matches("[a-z0-9_-]{1,64}"),"fixture receipt name");
            Path receipt=out.resolve(name+".json");require(!Files.exists(receipt),"new fixture receipt");
            if(action.equals("exit")) {handled=id;Files.writeString(receipt,JSON.toJson(state(mc)),StandardOpenOption.CREATE_NEW);mc.stop();return;}
            require(mc.player!=null && mc.level!=null && mc.gameMode!=null && mc.getCurrentServer()!=null && mc.getCurrentServer().ip.equals(ADDRESS),"owned connected client");
            Map<String,Object> result=new LinkedHashMap<>();result.put("request",command);result.put("before",state(mc));
            switch(action) {
                case "aim" -> {
                    int x=command.get("x").getAsInt();require(x>=1026 && x<=1038,"fixture aim bounds");
                    double y=command.has("y")?command.get("y").getAsDouble():81;
                    require(y>=81 && y<=82,"fixture aim height");
                    mc.player.lookAt(EntityAnchorArgument.Anchor.EYES,new Vec3(x+.5,y,1026.5));mc.gameRenderer.pick(1);
                }
                case "interact" -> {
                    require(mc.screen==null,"world interaction requires closed screen");mc.gameRenderer.pick(1);
                    require(mc.hitResult instanceof BlockHitResult && mc.hitResult.getType()==HitResult.Type.BLOCK,"real crosshair block");
                    BlockHitResult hit=(BlockHitResult)mc.hitResult;
                    require(hit.getBlockPos().getX()>=1024 && hit.getBlockPos().getX()<=1040 && hit.getBlockPos().getY()>=80 && hit.getBlockPos().getY()<=82,"owned hit bounds");
                    result.put("entryPoint","MultiPlayerGameMode.useItemOn(real mc.hitResult)");
                    result.put("returned",mc.gameMode.useItemOn(mc.player,InteractionHand.MAIN_HAND,hit).name());
                }
                case "button" -> {
                    require(mc.screen instanceof PlacementScreen,"actual placement screen");
                    List<Button> buttons=buttons(mc);int index=command.get("index").getAsInt();
                    require(index>=0 && index<buttons.size(),"button index");Button button=buttons.get(index);
                    require(button.active && button.visible,"enabled visible button");
                    double x=button.getX()+button.getWidth()/2.0,y=button.getY()+button.getHeight()/2.0;
                    var screen=mc.screen;require(screen.mouseClicked(x,y,0),"native button click accepted");screen.mouseReleased(x,y,0);
                }
                case "key" -> {
                    require(mc.screen!=null,"keyboard screen");int key=command.get("key").getAsInt();
                    require(Set.of(256,258,257,266,267).contains(key),"bounded native key");
                    result.put("accepted",mc.screen.keyPressed(key,0,0));
                }
                case "drop-outcome" -> require(dropOutcome.compareAndSet(false,true),"only one armed lost response");
                case "capture" -> {
                    int width=command.get("width").getAsInt(),height=command.get("height").getAsInt(),scale=command.get("scale").getAsInt();
                    String language=command.get("language").getAsString();
                    require((width==1280 && height==720 || width==1920 && height==1080) && scale>=1 && scale<=3 && Set.of("en_us","zh_tw").contains(language),"frozen capture sizes/languages");
                    mc.getWindow().setWindowed(width,height);mc.options.guiScale().set(scale);mc.resizeDisplay();
                    if(!mc.getLanguageManager().getSelected().equals(language)) {
                        mc.getLanguageManager().setSelected(language);mc.options.languageCode=language;reload=mc.reloadResourcePacks();
                    }
                    capture=command;warmFrames=0;
                }
                case "inspect" -> { }
                default -> throw new IllegalArgumentException("Unknown owned action "+action);
            }
            handled=id;
            if(!action.equals("capture")) {result.put("after",state(mc));Files.writeString(receipt,JSON.toJson(result),StandardOpenOption.CREATE_NEW);}
        } catch(Throwable failure) {fail(mc,failure);}
    }

    @SubscribeEvent public static void render(TickEvent.RenderTickEvent event) {
        if(event.phase!=TickEvent.Phase.END || capture==null || writing)return;
        Minecraft mc=Minecraft.getInstance();
        try {
            if(!reload.isDone() || mc.getOverlay()!=null)return;reload.join();
            if(++warmFrames<12)return;
            JsonObject requested=capture;String name=requested.get("name").getAsString();
            Map<String,Object> receipt=new LinkedHashMap<>();receipt.put("request",requested);receipt.put("actual",state(mc));
            for(Button button:buttons(mc))require(button.getX()>=0 && button.getY()>=0 && button.getX()+button.getWidth()<=mc.getWindow().getGuiScaledWidth() && button.getY()+button.getHeight()<=mc.getWindow().getGuiScaledHeight(),"all actual buttons inside viewport");
            capture=null;writing=true;
            Screenshot.grab(out.toFile(),name+".png",mc.getMainRenderTarget(),message->{
                try {
                    Path png=out.resolve("screenshots").resolve(name+".png");require(Files.isRegularFile(png) && Files.size(png)>0,"actual screenshot file");
                    receipt.put("png_bytes",Files.size(png));Files.writeString(out.resolve(name+".json"),JSON.toJson(receipt),StandardOpenOption.CREATE_NEW);
                } catch(Throwable failure) {mc.execute(()->fail(mc,failure));}finally{writing=false;}
            });
        } catch(Throwable failure) {fail(mc,failure);}
    }

    private static void tap(Connection connection)throws Exception {
        Channel channel=null;
        for(Field field:Connection.class.getDeclaredFields())if(Channel.class.isAssignableFrom(field.getType())){field.setAccessible(true);channel=(Channel)field.get(connection);}
        require(channel!=null,"actual socket channel");
        channel.pipeline().addBefore("packet_handler","br_placement_observer",new ChannelDuplexHandler(){
            @Override public void write(ChannelHandlerContext ctx,Object packet,ChannelPromise promise)throws Exception {
                if(packet instanceof ServerboundCustomPayloadPacket custom && custom.getIdentifier().toString().equals("blockreality:construction"))record(custom.getData(),"C2S",false);
                super.write(ctx,packet,promise);
            }
            @Override public void channelRead(ChannelHandlerContext ctx,Object packet)throws Exception {
                if(packet instanceof ClientboundCustomPayloadPacket custom && custom.getIdentifier().toString().equals("blockreality:construction")) {
                    FriendlyByteBuf copy=custom.getData();boolean dropped;
                    try {int discriminator=copy.getUnsignedByte(copy.readerIndex());dropped=discriminator==3 && dropOutcome.compareAndSet(true,false);record(copy,"S2C",dropped);}finally{copy.release();}
                    if(dropped) {
                        // This is a received packet, whose constructor owns its buffer.
                        for(Field field:ClientboundCustomPayloadPacket.class.getDeclaredFields())if(field.getType()==FriendlyByteBuf.class){field.setAccessible(true);((FriendlyByteBuf)field.get(custom)).release();}
                        return;
                    }
                }
                super.channelRead(ctx,packet);
            }
        });tapped=connection;
    }
    private static void record(FriendlyByteBuf data,String direction,boolean dropped) {
        require(frames.size()<256 && data.readableBytes()<=8192,"bounded wire evidence");
        byte[] bytes=new byte[data.readableBytes()];data.getBytes(data.readerIndex(),bytes);
        frames.add(Map.of("direction",direction,"dropped",dropped,"discriminator",bytes[0]&255,"base64",Base64.getEncoder().encodeToString(bytes),"nanoTime",System.nanoTime()));
    }
    private static List<Button> buttons(Minecraft mc) {return mc.screen==null?List.of():mc.screen.children().stream().filter(Button.class::isInstance).map(Button.class::cast).toList();}
    private static Map<String,Object> state(Minecraft mc)throws Exception {
        Map<String,Object> result=new LinkedHashMap<>();result.put("handled",handled);result.put("connected",mc.player!=null && mc.level!=null);
        result.put("screen",mc.screen==null?"none":mc.screen.getClass().getSimpleName());result.put("writing",writing);
        result.put("width",mc.getWindow().getWidth());result.put("height",mc.getWindow().getHeight());result.put("guiWidth",mc.getWindow().getGuiScaledWidth());result.put("guiHeight",mc.getWindow().getGuiScaledHeight());
        result.put("language",mc.getLanguageManager().getSelected());result.put("glRenderer",GL11.glGetString(GL11.GL_RENDERER));result.put("frames",List.copyOf(frames));
        List<Map<String,Object>> widgets=new ArrayList<>();for(Button button:buttons(mc))widgets.add(Map.of("label",button.getMessage().getString(),"active",button.active,"x",button.getX(),"y",button.getY(),"width",button.getWidth(),"height",button.getHeight(),"focused",button.isFocused()));result.put("buttons",widgets);
        if(mc.player!=null) {result.put("heldCount",mc.player.getMainHandItem().getCount());result.put("inventory",mc.player.getInventory().save(new ListTag()).toString());result.put("position",List.of(mc.player.getX(),mc.player.getY(),mc.player.getZ()));}
        if(mc.hitResult instanceof BlockHitResult hit)result.put("hit",Map.of("type",hit.getType().name(),"position",List.of(hit.getBlockPos().getX(),hit.getBlockPos().getY(),hit.getBlockPos().getZ()),"face",hit.getDirection().getName()));
        Field field=ClientConstruction.class.getDeclaredField("active");field.setAccessible(true);ClientConstruction.Session session=(ClientConstruction.Session)field.get(null);
        if(session!=null) {
            Map<String,Object> s=new LinkedHashMap<>();s.put("waiting",session.waiting);s.put("terminal",session.terminal);s.put("status",String.valueOf(session.status));s.put("localError",session.localError);s.put("message",ClientConstruction.status(session).getString());
            s.put("ghost",ClientConstruction.ghost()!=null);s.put("request",session.sent==null?"none":session.sent.id().toString());
            if(session.offer!=null) {s.put("axis",session.offer.axis());s.put("target",List.of(session.offer.target().getX(),session.offer.target().getY(),session.offer.target().getZ()));s.put("product",session.offer.product());}
            result.put("session",s);
        }
        return result;
    }
    private static void require(boolean condition,String message) {if(!condition)throw new AssertionError(message);}
    private static void fail(Minecraft mc,Throwable failure) {
        failure.printStackTrace();try {if(out!=null && !Files.exists(out.resolve("fatal.txt"))){var writer=new java.io.StringWriter();failure.printStackTrace(new java.io.PrintWriter(writer));Files.writeString(out.resolve("fatal.txt"),writer.toString(),StandardOpenOption.CREATE_NEW);}}catch(Exception secondary){secondary.printStackTrace();}
        capture=null;mc.stop();
    }
}
