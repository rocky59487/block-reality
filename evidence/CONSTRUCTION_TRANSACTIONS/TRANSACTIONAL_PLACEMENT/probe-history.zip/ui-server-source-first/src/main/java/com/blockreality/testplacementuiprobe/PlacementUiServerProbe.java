package com.blockreality.testplacementuiprobe;

import com.google.gson.*;
import net.minecraft.core.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.*;
import net.minecraft.world.*;
import net.minecraft.world.item.*;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.fml.common.Mod;
import java.lang.reflect.*;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;

/** Owned loopback fixture with an actual connected synthetic client; no result injection. */
@Mod("br_placement_ui_probe")
public final class PlacementUiServerProbe {
    private static final Gson JSON=new GsonBuilder().setPrettyPrinting().create();
    private MinecraftServer server;private ServerLevel level;private Path out;
    private long handled;private int ticks;private boolean cancelNext,finished;
    private Object service,metadata,journal,manager;
    public PlacementUiServerProbe() {
        MinecraftForge.EVENT_BUS.addListener(this::started);MinecraftForge.EVENT_BUS.addListener(this::tick);
        MinecraftForge.EVENT_BUS.addListener(EventPriority.LOWEST,this::placed);
    }
    private void started(ServerStartedEvent event) {
        server=event.getServer();level=server.overworld();
        try {
            out=Path.of(System.getProperty("br.placementUiOutput"));require(Files.readString(out.resolve("OWNER")).strip().equals("block-reality-placement-ui-v1"),"owned server output");
            Class<?> type=Class.forName("com.blockreality.impl.server.construction.ConstructionService");
            require(type.getResource("ConstructionService.class").toString().contains("blockreality-0.4.0-dev.jar"),"ordinary installed jar");
            require((boolean)call(type,"available",server),"construction recovery finished before login");
            service=((Map<?,?>)field(type,"SERVERS")).get(server);metadata=field(service,"metadata");journal=field(service,"journal");
            manager=call(Class.forName("com.blockreality.impl.server.StructureManager"),"of",level);
            level.setChunkForced(64,64,true);level.getChunk(64,64);
            for(int x=1024;x<=1039;x++)for(int z=1024;z<=1031;z++)level.setBlock(new BlockPos(x,80,z),Blocks.STONE.defaultBlockState(),3);
            level.setDayTime(6000);server.getGameRules().getRule(net.minecraft.world.level.GameRules.RULE_DAYLIGHT).set(false,server);
            Files.writeString(out.resolve("started.json"),JSON.toJson(Map.of("ordinary_jar",true,"port",server.getPort(),"synthetic_client","BRPlacementProbe")),StandardOpenOption.CREATE_NEW);
        } catch(Throwable failure){fail(failure);}
    }
    private ServerPlayer actor() {
        ServerPlayer player=server.getPlayerList().getPlayerByName("BRPlacementProbe");
        if(player!=null)require(player.level()==level,"fixture overworld player");return player;
    }
    private void tick(TickEvent.ServerTickEvent event) {
        if(event.phase!=TickEvent.Phase.END || out==null || finished)return;
        try {
            if(++ticks%10==0) {
                Files.writeString(out.resolve("state.next"),JSON.toJson(state()));
                Files.move(out.resolve("state.next"),out.resolve("state.json"),StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);
            }
            if(!Files.exists(out.resolve("control.json")))return;
            String raw=Files.readString(out.resolve("control.json"));require(raw.length()<4096,"bounded server command");
            JsonObject command=JsonParser.parseString(raw).getAsJsonObject();long id=command.get("id").getAsLong();
            if(id==handled)return;require(id>handled,"ordered server command");
            String action=command.get("action").getAsString(),name=command.get("name").getAsString();require(name.matches("[a-z0-9_-]{1,64}"),"server receipt name");
            Map<String,Object> receipt=new LinkedHashMap<>();receipt.put("request",command);receipt.put("before",state());
            if(action.equals("exit")) {handled=id;receipt.put("after",state());Files.writeString(out.resolve(name+".json"),JSON.toJson(receipt),StandardOpenOption.CREATE_NEW);finished=true;server.halt(false);return;}
            ServerPlayer actor=actor();require(actor!=null,"actual connected synthetic player");
            switch(action) {
                case "prepare" -> {
                    int x=command.get("x").getAsInt();require(x>=1026 && x<=1038,"fixture target bounds");
                    actor.closeContainer();actor.getInventory().selected=0;
                    actor.gameMode.changeGameModeForPlayer(command.has("creative") && command.get("creative").getAsBoolean()?GameType.CREATIVE:GameType.SURVIVAL);
                    ItemStack held=new ItemStack(BuiltInRegistries.ITEM.get(new ResourceLocation("blockreality:steel_beam")),8);
                    held.getOrCreateTag().putString("fixture","網路材料完整保留");held.getOrCreateTag().putFloat("typed",3.5f);
                    actor.setItemInHand(InteractionHand.MAIN_HAND,held);
                    ItemStack unrelated=new ItemStack(Items.IRON_INGOT,7);unrelated.getOrCreateTag().putString("fixture","其他欄位");actor.getInventory().setItem(9,unrelated);
                    actor.connection.teleport(x+.5,81,1029.5,180,28.4f);
                    if(command.has("chest") && command.get("chest").getAsBoolean())level.setBlock(new BlockPos(x,81,1026),Blocks.CHEST.defaultBlockState(),3);
                    actor.inventoryMenu.broadcastChanges();
                }
                case "cancel-next" -> {require(!cancelNext,"one armed protection cancellation");cancelNext=true;}
                case "inspect" -> { }
                default -> throw new IllegalArgumentException("Unknown fixture action "+action);
            }
            handled=id;receipt.put("after",state());Files.writeString(out.resolve(name+".json"),JSON.toJson(receipt),StandardOpenOption.CREATE_NEW);
        } catch(Throwable failure){fail(failure);}
    }
    private void placed(BlockEvent.EntityPlaceEvent event) {
        if(cancelNext && actor()!=null && event.getEntity()==actor()) {cancelNext=false;event.setCanceled(true);}
    }
    private Map<String,Object> state()throws Exception {
        Map<String,Object> result=new LinkedHashMap<>();ServerPlayer actor=actor();result.put("handled",handled);result.put("connected",actor!=null);result.put("cancelNext",cancelNext);
        if(actor!=null) {result.put("actor",actor.getUUID().toString());result.put("heldCount",actor.getMainHandItem().getCount());result.put("inventory",actor.getInventory().save(new ListTag()).toString());result.put("menu",actor.containerMenu.getClass().getSimpleName());result.put("position",List.of(actor.getX(),actor.getY(),actor.getZ()));}
        result.put("revision",call(call(call(manager,"gate"),"current"),"value"));result.put("order",call(metadata,"order"));result.put("ownedCells",call(metadata,"ownedCells"));
        Map<String,String> cells=new LinkedHashMap<>();for(int x=1026;x<=1038;x++)cells.put(String.valueOf(x),NbtUtils.writeBlockState(level.getBlockState(new BlockPos(x,81,1026))).toString());result.put("cells",cells);
        Map<String,String> files=new TreeMap<>();try(var stream=Files.list((Path)field(journal,"directory"))) {for(Path path:stream.filter(Files::isRegularFile).toList())files.put(path.getFileName().toString(),HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(path))));}result.put("journal",files);
        return result;
    }
    private static Object field(Object target,String name)throws Exception {Class<?> type=target instanceof Class<?> c?c:target.getClass();Field field=type.getDeclaredField(name);field.setAccessible(true);return field.get(target instanceof Class<?>?null:target);}
    private static Object call(Object target,String name,Object...args)throws Exception {
        Class<?> type=target instanceof Class<?> c?c:target.getClass();for(Method method:type.getDeclaredMethods()) {
            if(!method.getName().equals(name) || method.getParameterCount()!=args.length)continue;
            boolean match=true;for(int i=0;i<args.length;i++)if(args[i]!=null && !method.getParameterTypes()[i].isInstance(args[i]))match=false;
            if(!match)continue;method.setAccessible(true);try{return method.invoke(target instanceof Class<?>?null:target,args);}catch(InvocationTargetException failure){throw new RuntimeException(failure.getCause());}
        }throw new NoSuchMethodException(type.getName()+"."+name);
    }
    private static void require(boolean condition,String label) {if(!condition)throw new AssertionError(label);}
    private void fail(Throwable failure) {finished=true;failure.printStackTrace();try{if(out!=null){var writer=new java.io.StringWriter();failure.printStackTrace(new java.io.PrintWriter(writer));Files.writeString(out.resolve("fatal.txt"),writer.toString(),StandardOpenOption.CREATE_NEW);}}catch(Exception secondary){secondary.printStackTrace();}server.halt(false);}
}
