package com.blockreality.testplacementprobe;

import com.google.gson.*;
import com.mojang.authlib.GameProfile;
import net.minecraft.core.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.*;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.*;
import net.minecraft.world.*;
import net.minecraft.world.item.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.*;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.util.FakePlayerFactory;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.fml.common.Mod;
import io.netty.buffer.Unpooled;
import java.io.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

/** Real installed Forge, synthetic players, ordinary production jar and unmodified service admission. */
@Mod("br_placement_probe")
public final class PlacementProbe {
    private static final Gson JSON=new GsonBuilder().setPrettyPrinting().create();
    private static final UUID ACTOR=UUID.fromString("a5e13344-b530-4238-9878-e107c84f17b4");
    private final List<String> checks=new ArrayList<>();
    private final Map<String,Object> result=new LinkedHashMap<>();
    private final List<Map<String,Object>> barriers=new ArrayList<>();
    private final List<Map<String,Object>> replayClocks=new ArrayList<>();
    private Path output,serverRoot;
    private MinecraftServer server;
    private ServerLevel level;
    private ServerPlayer actor,other;
    private Class<?> serviceClass,managerClass;
    private Object service,manager,journal,metadata,originalFaults,firstRequest,firstOutcome;
    private Object committedOffer;
    private BlockPos target=new BlockPos(1026,81,1026);
    private AtomicLong sequence;
    private boolean cancellingPlace,cancellingClick,running,finished,observing;
    private boolean changeSupportOnNotification;
    private int stage,replays,nextTick;
    private long base,order,seq;
    private byte[] inventoryBefore,replayInventory;
    private Map<String,String> replayJournal;
    private long replayRevision,replayOrder,replaySequence;
    private String mode;
    public PlacementProbe() {
        MinecraftForge.EVENT_BUS.addListener(this::started);
        MinecraftForge.EVENT_BUS.addListener(this::tick);
        MinecraftForge.EVENT_BUS.addListener(EventPriority.LOWEST,this::placed);
        MinecraftForge.EVENT_BUS.addListener(EventPriority.HIGHEST,this::clicked);
        MinecraftForge.EVENT_BUS.addListener(EventPriority.HIGH,this::neighbor);
    }
    private void started(ServerStartedEvent event) {
        server=event.getServer();
        try {
            output=Path.of(System.getProperty("br.placementOutput"));serverRoot=Path.of(System.getProperty("br.placementServer"));mode=System.getProperty("br.placementMode");
            require(Files.readString(output.resolve("OWNER")).strip().equals("block-reality-placement-runtime-v1"),"owned output");
            level=server.overworld();serviceClass=Class.forName("com.blockreality.impl.server.construction.ConstructionService");managerClass=Class.forName("com.blockreality.impl.server.StructureManager");
            for(String name:List.of("com.blockreality.impl.server.construction.ConstructionService","com.blockreality.impl.server.construction.PlayerInventoryParticipant",
                    "com.blockreality.impl.net.ConstructionProtocol","com.blockreality.impl.item.StructuralBlockItem")) {
                Class<?> type=Class.forName(name);String origin=type.getResource(type.getSimpleName()+".class").toString();
                require(origin.contains("blockreality-0.4.0-dev.jar") && !origin.contains("br-placement-probe"),"ordinary jar origin "+type.getSimpleName());
            }
            require((boolean)call(serviceClass,"available",server),"construction recovered before players");
            service=((Map<?,?>)field(serviceClass,"SERVERS")).get(server);journal=field(service,"journal");metadata=field(service,"metadata");manager=call(managerClass,"of",level);
            sequence=(AtomicLong)field(Class.forName("com.blockreality.impl.net.BRNetwork"),"SEQUENCE");
            level.setChunkForced(64,64,true);level.getChunk(64,64);
            actor=FakePlayerFactory.get(level,new GameProfile(ACTOR,"PlacementFixture"));
            other=FakePlayerFactory.get(level,new GameProfile(UUID.fromString("b5e13344-b530-4238-9878-e107c84f17b4"),"OtherFixture"));
            if(mode.equals("restart")) {
                JsonObject saved=JsonParser.parseString(Files.readString(serverRoot.resolve("REPLAY.json"))).getAsJsonObject();
                var bytes=Base64.getDecoder().decode(saved.get("request").getAsString());var buffer=new FriendlyByteBuf(Unpooled.wrappedBuffer(bytes));
                try {firstRequest=call(Class.forName("com.blockreality.impl.net.ConstructionProtocol"),"decodeConfirmation",buffer);}finally{buffer.release();}
                actor.load(savedPlayer(ACTOR));
                firstOutcome=call(serviceClass,"confirm",actor,firstRequest);require(status(firstOutcome).equals("COMMITTED"),"old-session receipt found after restart");
                require(call(firstOutcome,"request").equals(firstRequest),"restarted receipt retains complete original binding");
                require((int)call(metadata,"ownedCells")==saved.get("ownedCells").getAsInt(),"manufactured ownership restored");
                beginReplays();stage=7;
            } else {
                require(!Files.exists(playerFile(ACTOR)),"first player has never been saved");
                actor.gameMode.changeGameModeForPlayer(GameType.SURVIVAL);other.gameMode.changeGameModeForPlayer(GameType.SURVIVAL);
                ItemStack untouched=new ItemStack(Items.IRON_INGOT,7);untouched.getOrCreateTag().putString("fixture","完整保留");
                untouched.getOrCreateTag().putDouble("typed",-0.0d);actor.getInventory().setItem(9,untouched);
                installObserver();
            }
            running=true;nextTick=server.getTickCount()+20;
        } catch(Throwable problem){finish(problem);}
    }
    private void tick(TickEvent.ServerTickEvent event) {
        if(event.phase!=TickEvent.Phase.END || !running || finished || server.getTickCount()<nextTick)return;
        try {
            nextTick=server.getTickCount()+20;
            switch(stage++) {
                case 0->survival();
                case 1->cancelPlacement();
                case 2->cancelClick();
                case 3->creative();
                case 4->competingActors();
                case 5->nestedSupportChange();
                case 6->{beginReplays();stage=7;}
                case 7->{replay();stage=7;nextTick=server.getTickCount()+3;}
                default->throw new AssertionError("Unexpected fixture stage");
            }
        } catch(Throwable problem){finish(problem);}
    }
    private void prepare(int x,GameType type)throws Exception {
        target=new BlockPos(x,81,1026);level.setBlock(target.below(),Blocks.STONE.defaultBlockState(),3);
        require(level.getBlockState(target).isAir(),"fresh replacement target "+x);
        actor.gameMode.changeGameModeForPlayer(type);actor.moveTo(x+.5,81,1028.5,0,0);actor.setShiftKeyDown(false);actor.getInventory().selected=0;
        ItemStack held=new ItemStack(BuiltInRegistries.ITEM.get(new ResourceLocation("blockreality:steel_beam")),4);
        held.getOrCreateTag().putString("construction_material","保持標記");held.getOrCreateTag().putFloat("type",3.5f);actor.setItemInHand(InteractionHand.MAIN_HAND,held);
        base=revision();order=(long)call(metadata,"order");seq=sequence.get();inventoryBefore=inventory(actor);
    }
    private Object preview(ServerPlayer player)throws Exception {
        Class<?> type=Class.forName("com.blockreality.impl.net.ConstructionProtocol$Preview");
        Object request=type.getConstructor(UUID.class,String.class,BlockPos.class,Direction.class,Vec3.class,InteractionHand.class,String.class,int.class)
                .newInstance(UUID.randomUUID(),level.dimension().location().toString(),target.below(),Direction.UP,
                        new Vec3(target.getX()+.5,target.getY(),target.getZ()+.5),InteractionHand.MAIN_HAND,"blockreality:steel_beam",1);
        Object reply=call(serviceClass,"preview",player,request);
        require(status(reply).equals("READY"),"production preview READY: "+status(reply));
        Object offer=call(reply,"offer");require(call(offer,"target").equals(target),"server authors exact target");return offer;
    }
    private void survival()throws Exception {
        prepare(1026,GameType.SURVIVAL);
        Map<String,String> initial=journalImages();
        var result=actor.gameMode.useItemOn(actor,level,actor.getMainHandItem(),InteractionHand.MAIN_HAND,
                new BlockHitResult(new Vec3(1026.5,81,1026.5),Direction.UP,target.below(),false));
        require(result==InteractionResult.PASS,"ordinary server item use performs no construction");
        require(level.getBlockState(target).isAir() && Arrays.equals(inventoryBefore,inventory(actor)),"ordinary entry preserves world and all inventory bytes");
        Object offer=preview(actor);committedOffer=offer;
        require(initial.equals(journalImages()) && !Files.exists(playerFile(ACTOR)),"preview allocates no journal or player file");
        require(revision()==base && (long)call(metadata,"order")==order,"preview allocates no revision or permanent identity");
        firstRequest=call(offer,"confirm",UUID.randomUUID());observing=true;
        firstOutcome=call(serviceClass,"confirm",actor,firstRequest);observing=false;
        require(status(firstOutcome).equals("COMMITTED"),"survival confirmation COMMITTED: "+status(firstOutcome));
        require(actor.getMainHandItem().getCount()==3,"survival debits exactly one item");
        require(NbtUtils.writeBlockState(level.getBlockState(target)).getCompound("Properties").getString("axis").equals("y"),"placed cell retains explicit Y declaration");
        this.result.put("survivalPublication",Map.of("baseRevision",base,"actualRevision",revision(),"baseOrder",order,
                "actualOrder",call(metadata,"order"),"baseSequence",seq,"actualSequence",sequence.get()));
        require(revision()==base+1 && (long)call(metadata,"order")==order+1 && sequence.get()==seq+1,"one public revision metadata order and envelope");
        verifyExactDebit(false);require((int)call(metadata,"ownedCells")==1,"one manufactured cell born");
        require(PlayerInventoryTag(savedPlayer(ACTOR)).equals(PlayerInventoryTag(actor.saveWithoutId(new CompoundTag()))),"complete live and durable inventory agree");
    }
    private void cancelPlacement()throws Exception {
        prepare(1028,GameType.SURVIVAL);Object offer=preview(actor);cancellingPlace=true;
        Object result=call(serviceClass,"confirm",actor,call(offer,"confirm",UUID.randomUUID()));cancellingPlace=false;
        require(status(result).equals("ABORTED"),"EntityPlace cancellation produces durable ABORTED: "+status(result));
        unchanged("cancelled EntityPlace");
        require(PlayerInventoryTag(savedPlayer(ACTOR)).equals(PlayerInventoryTag(actor.saveWithoutId(new CompoundTag()))),"cancelled material fully flushed back");
        require((boolean)call(serviceClass,"available",server),"cancelled placement leaves service available");
    }
    private void cancelClick()throws Exception {
        prepare(1030,GameType.SURVIVAL);Object offer=preview(actor);cancellingClick=true;
        Object result=call(serviceClass,"confirm",actor,call(offer,"confirm",UUID.randomUUID()));cancellingClick=false;
        require(status(result).equals("REJECTED"),"RightClickBlock cancellation rejected before apply");unchanged("cancelled right click");
    }
    private void creative()throws Exception {
        prepare(1032,GameType.CREATIVE);Object offer=preview(actor);
        Object result=call(serviceClass,"confirm",actor,call(offer,"confirm",UUID.randomUUID()));
        require(status(result).equals("COMMITTED"),"creative confirmation COMMITTED: "+status(result));
        verifyExactDebit(true);require(revision()==base+1 && (long)call(metadata,"order")==order+1,"creative publishes one revision and identity");
    }
    private void competingActors()throws Exception {
        prepare(1034,GameType.SURVIVAL);other.moveTo(1034.5,81,1028.5,0,0);other.setItemInHand(InteractionHand.MAIN_HAND,actor.getMainHandItem().copy());
        Object a=preview(actor),b=preview(other);byte[] otherBefore=inventory(other);
        Object first=call(serviceClass,"confirm",actor,call(a,"confirm",UUID.randomUUID()));
        Object second=call(serviceClass,"confirm",other,call(b,"confirm",UUID.randomUUID()));
        require(status(first).equals("COMMITTED") && status(second).equals("STALE"),"two actors resolve to one committed build and one stale refusal");
        require(Arrays.equals(otherBefore,inventory(other)) && !Files.exists(playerFile(other.getUUID())),"losing actor has no debit or checkpoint");
        require(revision()==base+1 && (long)call(metadata,"order")==order+1,"competing requests create one identity and revision");
        require((int)call(metadata,"ownedCells")==3,"three committed cells only");
    }
    private void placed(BlockEvent.EntityPlaceEvent event) {
        if(actor==null || event.getEntity()!=actor || !event.getPos().equals(target))return;
        try {
            require(Arrays.equals(inventoryBefore,inventory(actor)),"EntityPlace sees exact before inventory");
            require((boolean)call(serviceClass,"busy",server) && revision()==base && (long)call(metadata,"order")==order,"EntityPlace sees private candidate without public revision or identity");
            if(cancellingPlace)event.setCanceled(true);
        } catch(Exception problem){throw new RuntimeException(problem);}
    }
    private void nestedSupportChange()throws Exception {
        prepare(1036,GameType.SURVIVAL);Object offer=preview(actor);changeSupportOnNotification=true;
        Object reply=call(serviceClass,"confirm",actor,call(offer,"confirm",UUID.randomUUID()));
        require(status(reply).equals("COMMITTED") && !changeSupportOnNotification,"normal post-commit neighbor notification was dispatched");
        require(level.getBlockState(target.below()).isAir() && !level.getBlockState(target).isAir(),"foreign neighbor callback made the intended real support change");
        require(revision()==base+2 && (long)call(metadata,"order")==order+1,"one construction revision plus one real support-change revision");
        require((int)call(metadata,"ownedCells")==4,"neighbor notifications do not manufacture extra pieces");
    }
    private void neighbor(BlockEvent.NeighborNotifyEvent event) {
        if(!changeSupportOnNotification || event.getLevel()!=level || !event.getPos().equals(target))return;
        changeSupportOnNotification=false;
        try {
            require(!(boolean)call(serviceClass,"busy",server) && revision()==base+1,"neighbor callback runs after private ownership and publication");
            level.setBlock(target.below(),Blocks.AIR.defaultBlockState(),3);
            require(revision()==base+2,"nested support notification remains observed");
        } catch(Exception failure){throw new RuntimeException(failure);}
    }
    private void clicked(PlayerInteractEvent.RightClickBlock event) {if(cancellingClick && event.getEntity()==actor)event.setCanceled(true);}
    private void unchanged(String name)throws Exception {
        require(level.getBlockState(target).isAir() && Arrays.equals(inventoryBefore,inventory(actor)),name+" restores world and full inventory");
        require(revision()==base && (long)call(metadata,"order")==order && sequence.get()==seq,name+" publishes no identity revision or envelope");
    }
    private void verifyExactDebit(boolean creative)throws Exception {
        CompoundTag before=(CompoundTag)call(Class.forName("com.blockreality.impl.server.construction.CanonicalNbt"),"decode",inventoryBefore,16<<20);
        if(!creative) {
            Class<?> images=Class.forName("com.blockreality.impl.server.construction.PlayerInventoryImage");Object old=call(images,"read",before,0);
            Object next=call(Class.forName("com.blockreality.impl.server.construction.LivePlayerInventory"),"debitOne",old);
            before=(CompoundTag)call(images,"replace",before,Map.of(0,next));
        }
        require(Arrays.equals(encode(before),inventory(actor)),"all inventory fields preserved around "+(creative?"creative no-debit":"one-item debit"));
    }
    private void installObserver()throws Exception {
        Field field=journal.getClass().getDeclaredField("faults");field.setAccessible(true);originalFaults=field.get(journal);Class<?> type=field.getType();
        field.set(journal,Proxy.newProxyInstance(type.getClassLoader(),new Class<?>[]{type},(proxy,method,args)-> {
            if(method.getName().equals("at")){
                try {barrier(args[0].toString(),args[1]);}
                catch(Throwable failure) {
                    var trace=new StringWriter();failure.printStackTrace(new PrintWriter(trace));
                    Files.writeString(output.resolve("observer-failure.txt"),trace.toString(),StandardOpenOption.CREATE_NEW);throw failure;
                }
                return null;
            }
            return method.getName().equals("toString")?"PlacementObserver":method.getName().equals("hashCode")?System.identityHashCode(proxy):proxy==args[0];
        }));
    }
    private void barrier(String point,Object entry)throws Exception {
        if(!observing)return;String phase=call(entry,"phase").toString();
        if(!(phase.equals("PREPARED")&&point.equals("DIRECTORY_FORCED") || phase.equals("COMMITTED")&&point.equals("TEMP_FORCED")))return;
        require(revision()==base && (long)call(metadata,"order")==order && sequence.get()==seq,phase+" has no public provisional state");
        boolean prepared=phase.equals("PREPARED");
        require(level.getBlockState(target).isAir()==prepared && actor.getMainHandItem().getCount()==(prepared?4:3),phase+" world and material at correct barrier");
        require(savedPlayer(ACTOR).getList("Inventory",Tag.TAG_COMPOUND).getCompound(0).getByte("Count")== (prepared?4:3),phase+" full player file already durable");
        Files.write(output.resolve(phase+"-player.nbt"),encode(savedPlayer(ACTOR)),StandardOpenOption.CREATE_NEW);
        barriers.add(Map.of("phase",phase,"point",point,"worldAir",level.getBlockState(target).isAir(),"heldCount",actor.getMainHandItem().getCount()));
    }
    private void beginReplays()throws Exception {
        replayInventory=inventory(actor);replayJournal=journalImages();replayRevision=revision();replayOrder=(long)call(metadata,"order");replaySequence=sequence.get();
        Files.write(output.resolve("before-100-replays.nbt"),replayInventory,StandardOpenOption.CREATE_NEW);
    }
    private void replay()throws Exception {
        long beforeRevision=revision(),beforeSequence=sequence.get();
        Object reply=call(serviceClass,"confirm",actor,firstRequest);
        require(reply.equals(firstOutcome),"admitted exact replay "+(replays+1)+" retains original receipt");
        require(Arrays.equals(replayInventory,inventory(actor)) && replayJournal.equals(journalImages()) && beforeRevision==revision()
                && replayOrder==(long)call(metadata,"order") && beforeSequence==sequence.get(),"replay "+(replays+1)+" changes no items journal identity revision or publication");
        replayClocks.add(Map.of("tick",server.getTickCount(),"revision",beforeRevision,"sequence",beforeSequence));
        if(++replays==100) {
            if(!mode.equals("restart")) {
                var buffer=new FriendlyByteBuf(Unpooled.buffer());byte[] wire;
                try{call(Class.forName("com.blockreality.impl.net.ConstructionProtocol"),"encodeConfirmation",firstRequest,buffer);wire=new byte[buffer.readableBytes()];buffer.readBytes(wire);}finally{buffer.release();}
                Files.writeString(serverRoot.resolve("REPLAY.json"),JSON.toJson(Map.of("request",Base64.getEncoder().encodeToString(wire),"ownedCells",call(metadata,"ownedCells"))),StandardOpenOption.CREATE_NEW);
            }
            finish(null);
        }
    }
    private Map<String,String> journalImages()throws Exception {
        Map<String,String> images=new TreeMap<>();Path directory=(Path)field(journal,"directory");
        try(var files=Files.list(directory)){for(Path path:files.filter(Files::isRegularFile).toList())images.put(path.getFileName().toString(),Base64.getEncoder().encodeToString(Files.readAllBytes(path)));}
        return images;
    }
    private Path playerFile(UUID id){return server.getWorldPath(net.minecraft.world.level.storage.LevelResource.PLAYER_DATA_DIR).resolve(id+".dat");}
    private CompoundTag savedPlayer(UUID id)throws Exception {
        Constructor<?> constructor=Class.forName("com.blockreality.impl.server.construction.PlayerFileParticipant").getDeclaredConstructor(Path.class);
        constructor.setAccessible(true);Object adapter=constructor.newInstance(playerFile(id).getParent());
        return (CompoundTag)call(call(adapter,"capture",id),"data");
    }
    private static CompoundTag PlayerInventoryTag(CompoundTag player){CompoundTag result=new CompoundTag();result.put("Inventory",player.get("Inventory").copy());result.putInt("SelectedItemSlot",player.getInt("SelectedItemSlot"));return result;}
    private byte[] inventory(ServerPlayer player)throws Exception{return encode(PlayerInventoryTag(player.saveWithoutId(new CompoundTag())));}
    private static byte[] encode(CompoundTag tag)throws Exception{return (byte[])call(Class.forName("com.blockreality.impl.server.construction.CanonicalNbt"),"encode",tag,16<<20);}
    private static String status(Object value)throws Exception{return call(value,"status").toString();}
    private long revision()throws Exception{return ((Number)call(call(call(manager,"gate"),"current"),"value")).longValue();}
    private void require(boolean condition,String label){if(!condition)throw new AssertionError(label);checks.add(label);}
    private void finish(Throwable problem) {
        if(finished)return;finished=true;running=false;result.put("status",problem==null?"PASS":"FAIL");result.put("mode",mode);result.put("checks",checks);result.put("barriers",barriers);result.put("syntheticPlayers",true);result.put("replayClocks",replayClocks);
        if(problem!=null){var trace=new StringWriter();problem.printStackTrace(new PrintWriter(trace));result.put("trace",trace.toString());}
        try{if(journal!=null && originalFaults!=null){Field field=journal.getClass().getDeclaredField("faults");field.setAccessible(true);field.set(journal,originalFaults);}if(output!=null)Files.writeString(output.resolve("result.json"),JSON.toJson(result),StandardOpenOption.CREATE_NEW);}catch(Exception failure){failure.printStackTrace();}
        System.out.println("BR_PLACEMENT_PROBE "+result.get("status")+" checks="+checks.size());if(server!=null)server.halt(false);
    }
    private static Object field(Object target,String name)throws Exception{Class<?> type=target instanceof Class<?> c?c:target.getClass();Field field=type.getDeclaredField(name);field.setAccessible(true);return field.get(target instanceof Class<?>?null:target);}
    private static Object call(Object target,String name,Object...args)throws Exception {
        Class<?> type=target instanceof Class<?> c?c:target.getClass();
        for(Method method:type.getDeclaredMethods()) {
            if(!method.getName().equals(name) || method.getParameterCount()!=args.length)continue;
            boolean match=true;Class<?>[] parameters=method.getParameterTypes();
            for(int i=0;i<args.length;i++){Class<?> p=parameters[i];if(p==int.class)p=Integer.class;else if(p==long.class)p=Long.class;else if(p==boolean.class)p=Boolean.class;if(args[i]!=null&&!p.isInstance(args[i]))match=false;}
            if(!match)continue;method.setAccessible(true);
            try{return method.invoke(target instanceof Class<?>?null:target,args);}catch(InvocationTargetException failure){if(failure.getCause() instanceof Exception exception)throw exception;if(failure.getCause() instanceof Error error)throw error;throw new AssertionError(failure.getCause());}
        }
        throw new NoSuchMethodException(type.getName()+"."+name);
    }
}
