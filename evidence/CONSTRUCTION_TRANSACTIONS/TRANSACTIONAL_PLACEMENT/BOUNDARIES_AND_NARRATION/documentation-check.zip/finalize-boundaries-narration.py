from pathlib import Path
import hashlib,json,os,subprocess,sys,zipfile
root=Path('C:/Users/wmc02/Desktop/block-reality');build=root/'build/transactional-placement';parent=root/'evidence/CONSTRUCTION_TRANSACTIONS/TRANSACTIONAL_PLACEMENT';out=parent/'BOUNDARIES_AND_NARRATION'
command=[sys.executable,'-X','utf8','scripts/check_docs.py','dist/br-sidecar.exe']
with (build/'docs-boundaries.log').open('xb') as log:r=subprocess.run(command,cwd=root,env=dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8'),stdout=log,stderr=subprocess.STDOUT)
(build/'docs-boundaries-exit.json').write_text(json.dumps({'exit':r.returncode,'command':command,'existing_legacy_executable_only':True,'engine_built':False}));print('Documentation gate',r.returncode,flush=True)
if r.returncode:sys.exit(r.returncode)
(out/'upstream-latest-readonly.json').write_bytes(subprocess.check_output(['gh','release','view','--repo','rocky59487/tectonic2','--json','tagName,publishedAt,targetCommitish,url'],cwd=root))
with zipfile.ZipFile(out/'documentation-check.zip','x',compression=zipfile.ZIP_DEFLATED) as archive:
    for name in ['docs-boundaries.log','docs-boundaries-exit.json','finalize-boundaries-narration.py']:archive.write(build/name,name)
prior=json.loads((parent/'receipts-progress.json').read_text())
for name,expected in prior.items():
    data=(parent/name).read_bytes();assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256'],name
for path in out.glob('*.zip'):
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None,path
        if '__sha256.json' in archive.namelist():
            for name,expected in json.loads(archive.read('__sha256.json')).items():
                assert hashlib.sha256(archive.read(name)).hexdigest()==expected['sha256'],(path,name)
manifest={p.relative_to(out).as_posix():{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in out.rglob('*') if p.is_file()}
(out/'receipts.json').write_text(json.dumps(manifest,indent=2));print('Preserved',len(prior),'prior evidence files; verified',len(manifest),'new evidence files',flush=True)
