from pathlib import Path
import hashlib, json, subprocess, zipfile

root=Path('C:/Users/wmc02/Desktop/block-reality');build=root/'build/transactional-placement';out=root/'evidence/CONSTRUCTION_TRANSACTIONS/TRANSACTIONAL_PLACEMENT'
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert commit.startswith('a5900cd')
with zipfile.ZipFile(build/'source-candidate-fourth.zip') as archive:
    manifest=json.loads(archive.read('__sha256.json'));names=list(manifest)
    batch=subprocess.run(['git','cat-file','--batch'],input=''.join(commit+':'+name+'\n' for name in names).encode(),cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True).stdout
    offset=0;normalized=[]
    for name in names:
        end=batch.index(b'\n',offset);header=batch[offset:end].split();assert len(header)==3 and header[1]==b'blob',(name,header)
        size=int(header[2]);blob=batch[end+1:end+1+size];assert batch[end+1+size:end+2+size]==b'\n';offset=end+2+size
        data=archive.read(name);assert hashlib.sha256(data).hexdigest()==manifest[name]
        if data!=blob:
            data.decode('utf-8');blob.decode('utf-8');assert data.replace(b'\r\n',b'\n')==blob.replace(b'\r\n',b'\n'),name
            normalized.append(name)
    assert offset==len(batch)
(out/'source-identity.json').write_text(json.dumps({'source_commit':commit,'source_archive':'source-candidate-fourth.zip in source-attempts.zip','source_archive_sha256':hashlib.sha256((build/'source-candidate-fourth.zip').read_bytes()).hexdigest(),'all_snapshot_files_compared':len(names),'text_line_ending_normalization':normalized,'code_changes_after_fourth_build':False},indent=2))
upstream=subprocess.check_output(['gh','release','view','--repo','rocky59487/tectonic2','--json','tagName,publishedAt,targetCommitish,url'],cwd=root)
(out/'upstream-latest-readonly.json').write_bytes(upstream)
with zipfile.ZipFile(out/'documentation-supplement-first.zip','x',compression=zipfile.ZIP_DEFLATED) as archive:
    for name in ['update-progress-docs.py','docs-progress-first.log','docs-progress-first-exit.json','finalize-progress-first.py']:
        archive.write(build/name,name)
assert json.loads((build/'docs-progress-first-exit.json').read_text())['exit']==0
for path in out.glob('*.zip'):
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None,path
        if '__sha256.json' in archive.namelist():
            manifest=json.loads(archive.read('__sha256.json'))
            for name,identity in manifest.items():assert hashlib.sha256(archive.read(name)).hexdigest()==(identity if isinstance(identity,str) else identity['sha256'])
records={path.relative_to(out).as_posix():{'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()} for path in out.rglob('*') if path.is_file() and path.name!='receipts-progress.json'}
(out/'receipts-progress.json').write_text(json.dumps(records,indent=2));print('Source and archive validation',len(names),'source files;',len(records),'evidence files',flush=True)
