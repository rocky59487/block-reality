from pathlib import Path
import shutil,subprocess,json,os,sys,hashlib,zipfile
root=Path('/home/rocky/br-transactional-placement');assert not root.exists();root.mkdir()
(root/'OWNER').write_text('block-reality-transactional-placement-qualification-v1\n')
out=root/'qualification';out.mkdir()
source=Path('/mnt/c/Users/wmc02/Desktop/block-reality/build/transactional-placement/harness');dest=root/'harness-build';shutil.copytree(source,dest)
forge=Path('/mnt/c/Users/wmc02/Desktop/block-reality/forge')
for name in ['settings.gradle','gradlew','gradlew.bat']:shutil.copy2(forge/name,dest/name)
shutil.copytree(forge/'gradle',dest/'gradle')
command=['bash','gradlew','--no-daemon','--console=plain','jar','reobfJar'];env=dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8')
env.pop('BR_ENGINE',None);env.pop('BR_SIDECAR',None)
with (out/'harness-first.log').open('xb') as log:result=subprocess.run(command,cwd=dest,env=env,stdout=log,stderr=subprocess.STDOUT)
(out/'harness-first-exit.json').write_text(json.dumps({'exit':result.returncode,'command':command}));print('harness first',result.returncode,flush=True)
if result.returncode:sys.exit(result.returncode)
jar=dest/'build/libs/br-placement-probe-1.0.jar'
with zipfile.ZipFile(jar) as z:
    names=z.namelist();assert 'META-INF/accesstransformer.cfg' not in names
    assert all(n.startswith('com/blockreality/testplacementprobe/') for n in names if n.endswith('.class'))
(out/'harness-first-identity.json').write_text(json.dumps({'sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),'bytes':jar.stat().st_size,'entries':names},indent=2))
shutil.copy2(jar,out/'br-placement-probe-first.jar')
