from pathlib import Path

root=Path(__file__).resolve().parent
previous=(root/'run-ui-second.py').read_text(encoding='utf-8')
prefix=previous[:previous.index('try:\n    server_process = launch')]
suffix=previous[previous.index('except BaseException:\n'):]
prefix=prefix.replace("'ui-run-second'","'ui-run-third'").replace("'installed-ui-second'","'installed-ui-third'").replace("'forge/run-placement-ui-second'","'forge/run-placement-ui-third'")
prefix=prefix.replace('ui-client-build-second-exit.json','ui-client-build-third-exit.json').replace('br-placement-ui-probe-first.jar','br-placement-ui-probe-third.jar')
body='''try:
    server_process = launch(['bash', 'run.sh', 'nogui'], server, server_output, env)
    wait_state(server_output, timeout=180)
    client, client_process = start_client('client-first')
    prepare(client, 1026)
    ready = capture(client, 'ready-zh-large', 'zh_tw', small=False)
    require(ready['session']['status'] == 'READY' and ready['session']['ghost'], 'large Chinese ready preview and ghost')
    translations = json.loads((win.parent.parent/'forge/src/main/resources/assets/blockreality/lang/zh_tw.json').read_text())
    narration = command(client, 'narration', 'ready-narration')['collectedNarration']
    for text in [translations['block.blockreality.steel_beam'], '軸向：Y', '材料用量：1 個', '1026, 81, 1026', ready['session']['message'], '確認放置']:
        require(text in narration, 'native narration includes ready detail: ' + text)
    button(client, 1, 'refresh-y-before-loss')
    wait_state(client, lambda s: s.get('session', {}).get('status') == 'READY' and not s['session']['waiting'])
    baseline = server_state(); offered_tick = baseline['serverTick']
    require(baseline['order'] == 0 and baseline['heldCount'] == 8 and 'minecraft:air' in baseline['cells']['1026'], 'preview has no durable construction')
    command(client, 'drop-confirmation', 'arm-unsent-confirmation'); button(client, 3, 'confirm-dropped-before-server')
    pending = wait_state(client, lambda s: s.get('session', {}).get('localError') == 'br.build.unresolved' and not s['session']['waiting'])
    pending_id = pending['session']['request']; wire = confirmation_frames(pending)[-1]
    require(sum(f['dropped'] and f['direction']=='C2S' and f['discriminator']==1 for f in pending['frames']) == 1, 'exactly one real outgoing confirmation intercepted')
    require(pending_count() == 1 and pending['heldCount'] == 8, 'timeout retains durable request without material debit')
    original_pending = (profile/'blockreality/construction/pending.bin').read_bytes()
    (run/'pending-after-timeout.bin').write_bytes(original_pending)
    narrow = command(client, 'capture', 'pending-en-narrow-top', language='en_us', width=960, height=720, scale=3)['actual']
    require(narrow['guiWidth'] == 320 and narrow['guiHeight'] == 240, 'actual minimum supported 320 by 240 GUI')
    require(narrow['maximumScroll'] > 0 and narrow['scroll'] == 0 and narrow['bodyBottom'] > narrow['bodyTop'], 'real unresolved English text exceeds positive body viewport')
    command(client, 'key', 'overflow-page-down', key=267)
    scrolled = command(client, 'capture', 'pending-en-narrow-down', language='en_us', width=960, height=720, scale=3)['actual']
    require(scrolled['scroll'] == min(48, scrolled['maximumScroll']) and scrolled['scroll'] > 0, 'native PageDown moves actual bounded text scroll')
    require(narrow['buttons'] == scrolled['buttons'], 'scroll leaves all native controls and focus fixed')
    command(client, 'key', 'overflow-page-up', key=266)
    require(command(client, 'inspect', 'after-page-up')['after']['scroll'] == 0, 'native PageUp returns to text origin')
    pending_narration = command(client, 'narration', 'pending-narration')['collectedNarration']
    english = json.loads((win.parent.parent/'forge/src/main/resources/assets/blockreality/lang/en_us.json').read_text())
    require(english['br.build.unresolved'] in pending_narration and english['br.build.close_notice'] in pending_narration, 'native narration includes clipped pending status and retained-request notice')
    closed(client, 'close-unresolved')
    require((profile/'blockreality/construction/pending.bin').read_bytes() == original_pending, 'closing does not release or rewrite pending binding')
    command(client, 'interact', 'reopen-unresolved')
    restored = wait_state(client, lambda s: s.get('session', {}).get('request') == pending_id and s['screen'] == 'PlacementScreen')
    require(not restored['session']['ghost'], 'reopened unresolved request has no active placement ghost')
    expired_clock = wait_state(server_output, lambda s: s['serverTick'] >= offered_tick + 200)
    (run/'expiry-server-clock.json').write_text(json.dumps({'offer_already_received_by_tick':offered_tick, 'retry_after_tick':expired_clock['serverTick']}, indent=2))
    untouched = server_state()
    require(all(untouched[k] == baseline[k] for k in ['inventory','order','ownedCells','journal','cells']), 'unsent confirmation and timeout produced no server construction')
    button(client, 3, 'retry-expired-original')
    expired = wait_state(client, lambda s: s.get('session', {}).get('status') == 'EXPIRED' and not s['session']['waiting'])
    require(confirmation_frames(expired) == [wire, wire], 'explicit retry uses byte-identical original C2S binding')
    require(not expired['session']['terminal'] and pending_count() == 1, 'server EXPIRED alone retains original pending record')
    require((profile/'blockreality/construction/pending.bin').read_bytes() == original_pending, 'EXPIRED reply does not silently discard pending request')
    shutil.copy2(profile/'blockreality/construction/pending.bin', run/'pending-after-server-expired.bin')
    expired_zh = capture(client, 'expired-zh-small', 'zh_tw')
    require(expired_zh['buttons'][3]['label'] == '重新預覽' and expired_zh['buttons'][3]['active'], 'expired screen explicitly labels separate new preview action')
    expired_narration = command(client, 'narration', 'expired-narration')['collectedNarration']
    require(translations['br.build.status.expired'] in expired_narration and '重新預覽' in expired_narration, 'native narration announces server expiry and focused new-preview action')
    before_new = server_state(); button(client, 3, 'explicit-new-preview')
    fresh = wait_state(client, lambda s: s.get('session', {}).get('status') == 'READY' and s['session']['request'] == 'none' and not s['session']['waiting'])
    require(pending_count() == 0 and fresh['session']['ghost'], 'explicit action clears only expired record and obtains new preview')
    require(confirmation_frames(fresh) == [wire, wire], 'new preview does not send a new confirmation')
    after_new = server_state()
    require(all(before_new[k] == after_new[k] for k in ['inventory','order','ownedCells','journal','cells']), 'new preview requires another confirmation before any construction')
    button(client, 3, 'confirm-new-preview')
    committed = wait_state(client, lambda s: s.get('session', {}).get('terminal') and s['session']['status'] == 'COMMITTED' and s['heldCount'] == 7)
    require(committed['session']['request'] != pending_id and confirmation_frames(committed)[-1] != wire, 'separate confirmation uses a fresh transaction UUID and binding')
    final_server = server_state()
    require(final_server['order'] == 1 and final_server['ownedCells'] == 1 and final_server['heldCount'] == 7 and 'steel_beam' in final_server['cells']['1026'], 'only separate final confirmation creates one component and one debit')
    require(pending_count() == 0 and not committed['session']['ghost'], 'durable success clears exact new pending request and ghost')
    require(not committed['buttons'][3]['visible'] and committed['buttons'][4]['focused'], 'terminal native Done focus remains intact')
    capture(client, 'committed-zh-large', 'zh_tw', small=False)
    terminal_narration = command(client, 'narration', 'committed-narration')['collectedNarration']
    require(translations['br.build.status.committed'] in terminal_narration and '完成' in terminal_narration, 'native terminal narration contains saved decision and Done control')
    command(client, 'exit', 'exit-client-first'); require(client_process.wait(timeout=120) == 0, 'actual client exits normally')
    command(server_output, 'exit', 'exit-server'); require(server_process.wait(timeout=120) == 0, 'installed ordinary server exits normally')
    (run/'result.json').write_text(json.dumps({'status':'PASS','checks':checks,'receipts':receipts,'elapsed_seconds':time.monotonic()-start,'client_scope':'Linux development client from fifth shipping sources plus test-only probe; native narration text collected, audio/TTS not qualified; owned synthetic account and llvmpipe','server_jar_sha256':hashlib.sha256(ordinary.read_bytes()).hexdigest()},indent=2))
    print('Actual placement expiry/overflow/narration PASS',len(checks),flush=True)
'''
with (root/'run-ui-third.py').open('x',encoding='utf-8',newline='\n') as f:f.write(prefix+body+suffix)
print('Created third actual-client workflow without replaying unchanged earlier workflows')
