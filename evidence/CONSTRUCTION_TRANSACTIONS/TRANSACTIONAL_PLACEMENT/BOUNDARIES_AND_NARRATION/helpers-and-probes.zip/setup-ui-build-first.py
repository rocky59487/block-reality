from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys, zipfile

root = Path('/home/rocky/br-transactional-placement'); out = root / 'qualification'
win = Path('/mnt/c/Users/wmc02/Desktop/block-reality/build/transactional-placement')
assert (root / 'OWNER').read_text().strip() == 'block-reality-transactional-placement-qualification-v1'
server = root / 'ui-server-build-first'; client = root / 'ui-client-build-first'
assert not server.exists() and not client.exists()
shutil.copytree(win / 'ui-server', server)
for name in ['settings.gradle', 'gradlew', 'gradlew.bat']:
    shutil.copy2(root / 'harness-build' / name, server / name)
shutil.copytree(root / 'harness-build/gradle', server / 'gradle')
(server / 'build.gradle').write_text((win / 'harness/build.gradle').read_text().replace('br-placement-probe', 'br-placement-ui-probe').replace('com.blockreality.testplacementprobe', 'com.blockreality.testplacementuiprobe'))
client.mkdir()
with zipfile.ZipFile(win / 'source-candidate-second.zip') as source:
    manifest = json.loads(source.read('__sha256.json'))
    for name, digest in manifest.items():
        data = source.read(name); assert hashlib.sha256(data).hexdigest() == digest
        path = client / name; path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(data)
(out / 'ui-client-shipping-source-identity.json').write_text(json.dumps(manifest, indent=2))
probe = client / 'placement-probe/java/com/blockreality/impl/client'; probe.mkdir(parents=True)
shutil.copy2(win / 'ui-client/PlacementUiProbe.java', probe / 'PlacementUiProbe.java')
(client / 'placement-probe.gradle').write_text('''allprojects { afterEvaluate { p ->
    if (p.plugins.hasPlugin('net.minecraftforge.gradle')) {
        def output = System.getProperty('br.placementUiOutput')
        if (!output) throw new GradleException('Explicit owned UI output required')
        p.sourceSets.main.java.srcDir('../placement-probe/java')
        p.minecraft.runs.client {
            workingDirectory p.file('run-placement-ui')
            property 'br.placementUiProbe', 'true'
            property 'br.placementUiOutput', output
            jvmArgs '-Xms512m', '-Xmx2g'
            args '--username', 'BRPlacementProbe', '--uuid', '00000000-0000-0000-0000-000000000043', '--width', '1280', '--height', '720'
        }
    }
} }
''')
profile = client / 'forge/run-placement-ui'; profile.mkdir()
(profile / 'OWNER').write_text('block-reality-placement-ui-v1\n')
(profile / 'options.txt').write_text('version:3465\nonboardAccessibility:false\npauseOnLostFocus:false\nguiScale:3\nrenderDistance:4\nsimulationDistance:3\nmaxFps:30\nenableVsync:false\nlang:en_us\nautoJump:false\n')
shutil.copytree(win / 'ui-client', out / 'ui-client-source-first')
shutil.copytree(win / 'ui-server', out / 'ui-server-source-first')
env = dict(os.environ, PYTHONUTF8='1', PYTHONIOENCODING='utf-8'); env.pop('BR_ENGINE', None); env.pop('BR_SIDECAR', None)
for label, cwd, tasks in [
    ('server', server, ['jar', 'reobfJar']),
    ('client', client / 'forge', ['-I', '../placement-probe.gradle', '-Dbr.placementUiOutput=' + str(out / 'ui-client-first'), '-PbrNativesDir=/home/rocky/br-native-v15-consumer/staged', 'classes']),
]:
    command = ['bash', 'gradlew', '--no-daemon', '--console=plain', *tasks]
    with (out / ('ui-' + label + '-build-first.log')).open('xb') as log:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=log, stderr=subprocess.STDOUT)
    (out / ('ui-' + label + '-build-first-exit.json')).write_text(json.dumps({'exit': result.returncode, 'command': command}))
    print('UI', label, 'compile', result.returncode, flush=True)
    if result.returncode: sys.exit(result.returncode)
jar = server / 'build/libs/br-placement-ui-probe-1.0.jar'
shutil.copy2(jar, out / 'br-placement-ui-probe-first.jar')
with zipfile.ZipFile(jar) as archive:
    names = archive.namelist(); assert 'META-INF/accesstransformer.cfg' not in names
    assert all(name.startswith('com/blockreality/testplacementuiprobe/') for name in names if name.endswith('.class'))
(out / 'ui-server-harness-first-identity.json').write_text(json.dumps({'sha256': hashlib.sha256(jar.read_bytes()).hexdigest(), 'bytes': jar.stat().st_size, 'entries': names}, indent=2))
