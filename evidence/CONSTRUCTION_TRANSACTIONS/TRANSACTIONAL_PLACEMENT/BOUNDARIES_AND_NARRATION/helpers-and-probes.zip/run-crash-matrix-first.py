from pathlib import Path
import subprocess,json,sys
root=Path('/home/rocky/br-transactional-placement');win=Path('/mnt/c/Users/wmc02/Desktop/block-reality/build/transactional-placement');out=root/'qualification'
assert (root/'OWNER').read_text().strip()=='block-reality-transactional-placement-qualification-v1'
assert not (out/'crash-matrix-first.json').exists()
results=[]
for point in ['prepared','player-applied','world-durable','player-durable','committed-temp','committed','published']:
    setup=(win/'setup-runtime-fixed.py').read_text().replace('installed-fixed','installed-crash-'+point+'-first').replace('br-placement-probe-fifth.jar','br-placement-probe-sixth.jar').replace('harness-fifth-identity.json','harness-sixth-identity.json')
    script=out/('setup-crash-'+point+'-first.py');assert not script.exists();script.write_text(setup)
    commands=[['python3',str(script)],['python3',str(win/'launch-crash-first.py'),point],
              ['python3',str(win/'launch-recovery.py'),point,'first'],['python3',str(win/'launch-recovery.py'),point,'second']]
    for index,command in enumerate(commands):
        log=out/('matrix-first-'+point+'-'+str(index)+'.log')
        with log.open('xb') as output:r=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT)
        results.append({'point':point,'step':index,'command':command,'exit':r.returncode,'log':str(log)})
        (out/'crash-matrix-first.json').write_text(json.dumps(results,indent=2));print(point,index,'exit',r.returncode,flush=True)
        if r.returncode:
            print(log.read_text(errors='replace')[-5000:],flush=True);sys.exit(r.returncode)
print('Seven remaining crash points and fourteen fresh recoveries finished',flush=True)
