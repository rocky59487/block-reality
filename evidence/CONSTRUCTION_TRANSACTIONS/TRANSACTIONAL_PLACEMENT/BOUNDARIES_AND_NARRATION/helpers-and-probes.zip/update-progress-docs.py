from pathlib import Path
import json, os, subprocess, sys

root=Path('C:/Users/wmc02/Desktop/block-reality');out=root/'build/transactional-placement'
counts=json.loads((out/'dual-platform-tests-fourth.json').read_text());assert counts['windows']['registered']==639 and counts['linux']['passed']==638

def edit(name,changes):
    path=root/name;text=path.read_text(encoding='utf-8')
    for before,after in changes:
        assert before in text,(name,before);text=text.replace(before,after)
    path.write_text(text,encoding='utf-8')

edit('README.md',[('330_engine_%2B_622_Java','330_engine_%2B_639_Java'),('622 tests registered (477 core, 145 Forge-side)','639 tests registered (487 core, 152 Forge-side)'),('622 項測試已登錄（core 477、Forge 側 145）','639 項測試已登錄（core 487、Forge 側 152）')])
edit('QUICKSTART.md',[('資料層另外被 622 個測試釘住','資料層另外被 639 個測試釘住')])
edit('docs/RESEARCH_BRIEF.md',[('622/622 registered (Windows coverage: 610 pass','639/639 registered (Windows coverage: 627 pass')])
edit('docs/outreach/LISTING.md',[('622 Java tests (477 core, 145 Forge-side; Windows: 610 pass','639 Java tests (487 core, 152 Forge-side; Windows: 627 pass')])
edit('CLAUDE.md',[
('CONSTRUCTION_TRANSACTIONS 已凍 CT-1..9/D-048，核心日誌/復原已接首個軸向入口；一般施工仍未完成。','CONSTRUCTION_TRANSACTIONS 已凍 CT-1..9/D-048，核心日誌/復原已接軸向EDIT與單格BUILD；一般施工驗收仍未完成。'),
('目前開發jar15,355,886B/SHA828d24b47b23…','目前開發jar15,439,737B/SHA7cda56e40cc0…'),
('BUILD/undo仍無Forge呼叫者；metadata資格不單獨授權世界修改或退款','單格BUILD已接Forge，undo仍無呼叫者；metadata資格不單獨授權世界修改或退款'),
('  一般放置/庫存消耗/blueprint/undo/C2S確認與真socket/UI仍開放，不能稱完整CT或高性能。','  這批軸向證據不包含一般放置/庫存消耗/blueprint/undo/C2S確認或真socket/UI；一般放置進度如下。'),
('- Windows core477/Forge145：622登錄、610PASS、12平台SKIP；Linux621PASS、1平台SKIP。','- Windows core487/Forge152：639登錄、627PASS、12平台SKIP；Linux638PASS、1平台SKIP。'),
('- NATIVE_VERDICT_API 已刪除只看數字的未使用影線API，公開利用率配色必須收原生overload旗標。',
 '- CT_TRANSACTIONAL_PLACEMENT 已實作單格材料預覽、獨立C2S確認、完整玩家/區塊checkpoint、\n'
 '  PREPARED私有寫入、COMMITTED後單次身分/revision發布，以及送出前持久保存的精確重試。\n'
 '  普通jar隔離實裝控制277項、重啟209項通過，各含100次admitted重送；玩家為synthetic。\n'
 '  8個真Minecraft SIGKILL中斷點、16次重啟及原始region/完整玩家檔解析通過；5個編譯反例被抓到。\n'
 '  真Linux開發client對普通jar專服的首輪48項/修正版52項通過，每輪2個client JVM與8張原始圖；\n'
 '  含三軸、取消、材料同步、箱子優先、保護取消、遺失回覆後跨client重啟的逐位相同確認重送。\n'
 '  面板隨內容收合，終態移除重試並把鍵盤焦點交給完成；原始大視窗空白與翻譯守門首敗照存。\n'
 '  詳 `evidence/CONSTRUCTION_TRANSACTIONS/TRANSACTIONAL_PLACEMENT/RESULTS.md`；領域/actor/slot/\n'
 '  容量/expiry等額外實裝案例、Recorded成本及exact-head CI仍待補，尚未完成本單元全部判準。\n'
 '  blueprint/undo/一般拆除所有權整理、高性能與v1保持開放；沒有Java物理補做。\n'
 '- NATIVE_VERDICT_API 已刪除只看數字的未使用影線API，公開利用率配色必須收原生overload旗標.')])
path=root/'docs/V1_MODULE_PROGRAM.md';text=path.read_text(encoding='utf-8');start=text.index('目前模組來源338c490');end=text.index('\n原v1.5換裝單元',start)
text=text[:start]+'''目前模組候選FOURTH為15,439,737B、SHA7cda56e40cc0…，保留同一v1.5雙平台庫。
核心487項、Forge152項：639登錄，Windows627PASS/12平台SKIP，Linux638PASS/1平台SKIP。
`codex/transactional-placement`接續PR134，已實作單格BUILD與材料消耗、伺服器預覽/C2S確認、
送出前持久保存的client重試、完整玩家/區塊barrier、提交後單次metadata/revision。
普通jar隔離實裝277項與重啟209項通過，各含100次admitted精確重送；8個Minecraft SIGKILL
中斷點、16次重啟，以及原始region與完整玩家檔解析通過。5個編譯行為反例都被預定断言抓到。
真Linux開發client對普通jar專服首輪48項/修正版52項，每輪2個client JVM與8張原始圖；
驗證三軸、取消、鍵盤、材料同步、箱子優先、保護取消和丟失回覆後跨client重啟的精確重送。
面板高度依內容收合，終態隱藏重試並移交完成焦點。來源、首敗與原始證據見
`../evidence/CONSTRUCTION_TRANSACTIONS/TRANSACTIONAL_PLACEMENT/RESULTS.md`。
這是單格呼叫者的進行中驗收；額外領域/actor/slot/capacity/expiry案例、Recorded成本及
exact-head CI仍待補。完整CT-1..9/#12/#17、blueprint/undo/一般拆除所有權整理、高性能、
Windows CM/N25、引擎權威動態消費與正式v1都保持開放。
''' + text[end:];path.write_text(text,encoding='utf-8')
command=[sys.executable,'-X','utf8','scripts/check_docs.py','dist/br-sidecar.exe']
with (out/'docs-progress-first.log').open('xb') as log:result=subprocess.run(command,cwd=root,env=dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8'),stdout=log,stderr=subprocess.STDOUT)
(out/'docs-progress-first-exit.json').write_text(json.dumps({'command':command,'exit':result.returncode,'legacy_existing_executable_only':True,'engine_built':False}));print('Documentation quoted counts exit',result.returncode,flush=True);sys.exit(result.returncode)
