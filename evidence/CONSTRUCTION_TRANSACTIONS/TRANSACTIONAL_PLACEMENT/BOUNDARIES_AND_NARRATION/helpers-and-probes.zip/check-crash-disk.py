"""Independent, read-only decoding of the frozen placement fixture's crash files.

This is evidence tooling, never shipped. It retains NBT scalar types and float bits,
reads the real region sector table and padded block palette, and compares the full
player document against the separately saved before/after fixture images.
"""
from pathlib import Path
import base64, gzip, hashlib, json, struct, sys, zlib


class Nbt:
    def __init__(self, data):
        assert len(data) <= 16 * 1024 * 1024
        self.data, self.pos, self.tags = data, 0, 0

    def take(self, count):
        assert 0 <= count <= len(self.data) - self.pos
        value = self.data[self.pos:self.pos + count]
        self.pos += count
        return value

    def number(self, code):
        return struct.unpack('>' + code, self.take(struct.calcsize('>' + code)))[0]

    def string(self):
        # Decode Java's modified UTF-8 through UTF-16 code units (including NUL).
        raw = self.take(self.number('H'))
        units, offset = [], 0
        while offset < len(raw):
            first = raw[offset]; offset += 1
            if first < 128:
                assert first != 0
                units.append(first)
            elif first & 224 == 192:
                second = raw[offset]; offset += 1
                assert second & 192 == 128
                units.append(((first & 31) << 6) | (second & 63))
            else:
                assert first & 240 == 224
                second, third = raw[offset:offset + 2]; offset += 2
                assert second & 192 == 128 and third & 192 == 128
                units.append(((first & 15) << 12) | ((second & 63) << 6) | (third & 63))
        return b''.join(struct.pack('>H', unit) for unit in units).decode('utf-16-be', 'surrogatepass')

    def tag(self, kind, depth=0):
        self.tags += 1
        assert depth < 64 and self.tags <= 262144
        if kind in (1, 2, 3, 4):
            value = self.number({1: 'b', 2: 'h', 3: 'i', 4: 'q'}[kind])
        elif kind in (5, 6):
            value = self.take(4 if kind == 5 else 8).hex()
        elif kind == 8:
            value = self.string()
        elif kind in (7, 11, 12):
            count = self.number('i'); width = {7: 1, 11: 4, 12: 8}[kind]
            assert 0 <= count <= (len(self.data) - self.pos) // width
            value = tuple(self.number({7: 'b', 11: 'i', 12: 'q'}[kind]) for _ in range(count))
        elif kind == 9:
            child, count = self.number('B'), self.number('i')
            assert 0 <= count <= 262144 and (child != 0 or count == 0)
            # Vanilla may encode an empty list with its declared type; canonical
            # NBT normalizes it to END. Empty lists have no element type in memory.
            value = tuple(self.tag(child, depth + 1) for _ in range(count))
        elif kind == 10:
            value = {}
            while True:
                child = self.number('B')
                if child == 0: break
                key = self.string()
                assert key not in value
                value[key] = self.tag(child, depth + 1)
        else:
            raise AssertionError('NBT type ' + str(kind))
        return kind, value

    def root(self):
        assert self.number('B') == 10 and self.string() == ''
        result = self.tag(10)
        assert self.pos == len(self.data)
        return result


def field(tag, key, kind):
    assert tag[0] == 10 and tag[1][key][0] == kind
    return tag[1][key][1]


def region_cell(path, x, y, z):
    # RegionFile.flush forces bytes without padding; only close pads the last
    # sector. A forcibly interrupted, fully flushed open file can end mid-sector.
    data = path.read_bytes(); assert len(data) >= 8192
    index = ((x // 16) % 32 + (z // 16) % 32 * 32) * 4
    offset, sectors = int.from_bytes(data[index:index + 3], 'big'), data[index + 3]
    assert offset >= 2 and sectors > 0 and offset * 4096 + 5 <= len(data)
    start = offset * 4096; length = int.from_bytes(data[start:start + 4], 'big')
    assert 1 < length <= sectors * 4096 - 4 and start + 4 + length <= len(data)
    compression, payload = data[start + 4], data[start + 5:start + 4 + length]
    assert compression in (1, 2, 3), 'fixture must use inline, supported region compression'
    unpacked = gzip.decompress(payload) if compression == 1 else zlib.decompress(payload) if compression == 2 else payload
    root = Nbt(unpacked).root()
    assert field(root, 'xPos', 3) == x // 16 and field(root, 'zPos', 3) == z // 16
    section = [section for section in field(root, 'sections', 9) if field(section, 'Y', 1) == y // 16]
    assert len(section) == 1
    states = section[0][1]['block_states']; palette = field(states, 'palette', 9)
    assert palette
    if len(palette) == 1:
        selected, bits = 0, 0
    else:
        bits = max(4, (len(palette) - 1).bit_length()); per_word = 64 // bits
        storage = field(states, 'data', 12)
        assert len(storage) == (4096 + per_word - 1) // per_word
        slot = (y % 16) * 256 + (z % 16) * 16 + x % 16
        selected = ((storage[slot // per_word] & ((1 << 64) - 1)) >> ((slot % per_word) * bits)) & ((1 << bits) - 1)
        assert selected < len(palette)
    return palette[selected], {'region_sha256': hashlib.sha256(data).hexdigest(),
                              'chunk_nbt_sha256': hashlib.sha256(unpacked).hexdigest(),
                              'sector_offset': offset, 'sectors': sectors, 'compression': compression,
                              'palette_size': len(palette), 'palette_index': selected, 'bits': bits}


def main():
    root = Path('/home/rocky/br-transactional-placement'); output = root / 'qualification/crash-disk-second.json'
    assert (root / 'OWNER').read_text().strip() == 'block-reality-transactional-placement-qualification-v1'
    assert not output.exists()
    results = []
    for point in ['prepared', 'world-applied', 'player-applied', 'world-durable', 'player-durable', 'committed-temp', 'committed', 'published']:
        captured = root / ('qualification/crash-' + point + '-first')
        expected = json.loads((root / ('installed-crash-' + point + '-first/CRASH_EXPECTED.json')).read_text())
        world_after = point in ['world-durable', 'player-durable', 'committed-temp', 'committed', 'published']
        player_after = point in ['player-durable', 'committed-temp', 'committed', 'published']
        actual, record = region_cell(captured / 'crash-region.mca', 1026, 81, 1026)
        assert actual == Nbt(base64.b64decode(expected['afterCell' if world_after else 'beforeCell'])).root(), point + ' disk cell'
        raw_player = (captured / 'crash-player.dat').read_bytes()
        player = Nbt(gzip.decompress(raw_player)).root()
        assert player == Nbt(base64.b64decode(expected['afterPlayer' if player_after else 'beforePlayer'])).root(), point + ' full disk player'
        assert player == Nbt((captured / 'crash-disk-player.nbt').read_bytes()).root(), point + ' captured player matches raw file'
        record.update(point=point, world_after=world_after, player_after=player_after, disk_cell=actual,
                      player_file_sha256=hashlib.sha256(raw_player).hexdigest(), status='PASS')
        results.append(record); print(point, 'disk cell + entire player PASS', flush=True)
    output.write_text(json.dumps({'status': 'PASS', 'production_jar_unchanged': True, 'cases': results}, indent=2))


if __name__ == '__main__': main()
