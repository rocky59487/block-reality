from pathlib import Path
import json, subprocess, sys

root = Path('/home/rocky/br-transactional-placement')
win = Path('/mnt/c/Users/wmc02/Desktop/block-reality/build/transactional-placement')
out = root / 'qualification'
setup = (win / 'setup-runtime-fixed.py').read_text().replace('installed-fixed', 'installed-strengthened').replace('br-placement-probe-fifth.jar', 'br-placement-probe-sixth.jar').replace('harness-fifth-identity.json', 'harness-sixth-identity.json')
launch = (win / 'launch-runtime-fixed.py').read_text().replace('installed-fixed', 'installed-strengthened').replace('runtime-fixed-', 'runtime-strengthened-')
for name, content in [('setup-strengthened.py', setup), ('launch-strengthened.py', launch)]:
    path = out / name; assert not path.exists(); path.write_text(content)
for command in [['python3', str(out / 'setup-strengthened.py')], ['python3', str(out / 'launch-strengthened.py'), 'control'], ['python3', str(out / 'launch-strengthened.py'), 'restart']]:
    result = subprocess.run(command)
    if result.returncode: sys.exit(result.returncode)
