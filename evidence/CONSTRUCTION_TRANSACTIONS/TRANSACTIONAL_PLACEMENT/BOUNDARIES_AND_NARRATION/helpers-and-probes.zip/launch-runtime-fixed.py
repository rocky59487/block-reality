from pathlib import Path
import subprocess,os,sys,json,signal,socket
root=Path('/home/rocky/br-transactional-placement');mode=sys.argv[1];assert mode in ['control','restart']
server=root/'installed-fixed';assert (server/'OWNER').read_text().strip()=='block-reality-placement-runtime-v1'
out=root/('qualification/runtime-fixed-'+mode);assert not out.exists();out.mkdir();(out/'OWNER').write_text('block-reality-placement-runtime-v1\n')
with socket.socket() as socket_:socket_.bind(('127.0.0.1',25602))
(server/'user_jvm_args.txt').write_text('-Xms512m\n-Xmx2g\n-Dbr.placementOutput='+str(out)+'\n-Dbr.placementServer='+str(server)+'\n-Dbr.placementMode='+mode+'\n-Xlog:class+load=info:file='+str(out/'classload.log')+'\n')
env=dict(os.environ,OPENBLAS_CORETYPE='Haswell',OPENBLAS_NUM_THREADS='1');env.pop('BR_ENGINE',None);env.pop('BR_SIDECAR',None)
with (out/'server.log').open('xb') as log:
    process=subprocess.Popen(['bash','run.sh','nogui'],cwd=server,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    (out/'process-owner.json').write_text(json.dumps({'pid':process.pid,'process_group':process.pid,'cwd':str(server),'timeout_seconds':300}));print('Owned placement server PID',process.pid,flush=True)
    try:code=process.wait(timeout=300)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid,signal.SIGTERM)
        try:process.wait(timeout=20)
        except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
        (out/'exit.json').write_text(json.dumps({'exit':process.returncode,'timeout':True}));raise
(out/'exit.json').write_text(json.dumps({'exit':code,'timeout':False}))
result=json.loads((out/'result.json').read_text()) if (out/'result.json').exists() else {'status':'MISSING'}
print('Placement',mode,'exit',code,'probe',result.get('status'),'checks',len(result.get('checks',[])),flush=True)
if result.get('status')!='PASS':print(result.get('trace','No probe trace'),flush=True)
sys.exit(0 if code==0 and result.get('status')=='PASS' else 1)
