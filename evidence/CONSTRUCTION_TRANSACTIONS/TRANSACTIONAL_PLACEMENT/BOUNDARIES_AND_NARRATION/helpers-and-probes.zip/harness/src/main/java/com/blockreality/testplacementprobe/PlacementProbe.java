package com.blockreality.testplacementprobe;

import com.google.gson.*;
import com.mojang.authlib.GameProfile;
import net.minecraft.core.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.*;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.*;
import net.minecraft.world.*;
import net.minecraft.world.item.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.*;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.util.FakePlayerFactory;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.fml.common.Mod;
import io.netty.buffer.Unpooled;
import java.io.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

/** Real installed Forge, synthetic players, ordinary production jar and unmodified service admission. */
@Mod("br_placement_probe")
public final class PlacementProbe {
    private static PlacementProbe instance;
    private static final Gson JSON=new GsonBuilder().setPrettyPrinting().create();
    private static final UUID ACTOR=UUID.fromString("a5e13344-b530-4238-9878-e107c84f17b4");
    private final List<String> checks=new ArrayList<>();
    private final Map<String,Object> result=new LinkedHashMap<>();
    private final List<Map<String,Object>> barriers=new ArrayList<>();
    private final List<Map<String,Object>> replayClocks=new ArrayList<>();
    private Path output,serverRoot;
    private MinecraftServer server;
    private ServerLevel level;
    private ServerPlayer actor,other;
    private Class<?> serviceClass,managerClass;
    private Object service,manager,journal,metadata,originalFaults,firstRequest,firstOutcome;
    private Object committedOffer;
    private BlockPos target=new BlockPos(1026,81,1026);
    private AtomicLong sequence;
    private boolean cancellingPlace,cancellingClick,running,finished,observing;
    private boolean changeSupportOnNotification;
    private int stage,replays,nextTick;
    private long base,order,seq;
    private byte[] inventoryBefore,replayInventory;
    private CompoundTag fullPlayerBefore;
    private Map<String,String> replayJournal;
    private long replayRevision,replayOrder,replaySequence;
    private String mode;
    private Object boundaryOffer,expiryRequest;
    private int expiryTick;
    private final List<Map<String,Object>> boundaryReceipts=new ArrayList<>(),callCosts=new ArrayList<>();
    private final List<ServerPlayer> capacityActors=new ArrayList<>();
    private final List<Object> capacityOffers=new ArrayList<>();
    public PlacementProbe() {
        instance=this;
        MinecraftForge.EVENT_BUS.addListener(this::started);
        MinecraftForge.EVENT_BUS.addListener(this::tick);
        MinecraftForge.EVENT_BUS.addListener(EventPriority.LOWEST,this::placed);
        MinecraftForge.EVENT_BUS.addListener(EventPriority.HIGHEST,this::clicked);
        MinecraftForge.EVENT_BUS.addListener(EventPriority.HIGH,this::neighbor);
    }
    private void started(ServerStartedEvent event) {
        server=event.getServer();
        try {
            output=Path.of(System.getProperty("br.placementOutput"));serverRoot=Path.of(System.getProperty("br.placementServer"));mode=System.getProperty("br.placementMode");
            require(Files.readString(output.resolve("OWNER")).strip().equals("block-reality-placement-runtime-v1"),"owned output");
            level=server.overworld();serviceClass=Class.forName("com.blockreality.impl.server.construction.ConstructionService");managerClass=Class.forName("com.blockreality.impl.server.StructureManager");
            for(String name:List.of("com.blockreality.impl.server.construction.ConstructionService","com.blockreality.impl.server.construction.PlayerInventoryParticipant",
                    "com.blockreality.impl.net.ConstructionProtocol","com.blockreality.impl.item.StructuralBlockItem")) {
                Class<?> type=Class.forName(name);String origin=type.getResource(type.getSimpleName()+".class").toString();
                require(origin.contains("blockreality-0.4.0-dev.jar") && !origin.contains("br-placement-probe"),"ordinary jar origin "+type.getSimpleName());
            }
            require((boolean)call(serviceClass,"available",server),"construction recovered before players");
            service=((Map<?,?>)field(serviceClass,"SERVERS")).get(server);journal=field(service,"journal");metadata=field(service,"metadata");manager=call(managerClass,"of",level);
            sequence=(AtomicLong)field(Class.forName("com.blockreality.impl.net.BRNetwork"),"SEQUENCE");
            if(mode.startsWith("recover-")) {recoverCrash();finish(null);return;}
            level.setChunkForced(64,64,true);level.getChunk(64,64);
            actor=FakePlayerFactory.get(level,new GameProfile(ACTOR,"PlacementFixture"));
            other=FakePlayerFactory.get(level,new GameProfile(UUID.fromString("b5e13344-b530-4238-9878-e107c84f17b4"),"OtherFixture"));
            if(mode.equals("restart")) {
                JsonObject saved=JsonParser.parseString(Files.readString(serverRoot.resolve("REPLAY.json"))).getAsJsonObject();
                var bytes=Base64.getDecoder().decode(saved.get("request").getAsString());var buffer=new FriendlyByteBuf(Unpooled.wrappedBuffer(bytes));
                try {firstRequest=call(Class.forName("com.blockreality.impl.net.ConstructionProtocol"),"decodeConfirmation",buffer);}finally{buffer.release();}
                actor.load(savedPlayer(ACTOR));
                firstOutcome=call(serviceClass,"confirm",actor,firstRequest);require(status(firstOutcome).equals("COMMITTED"),"old-session receipt found after restart");
                require(call(firstOutcome,"request").equals(firstRequest),"restarted receipt retains complete original binding");
                require((int)call(metadata,"ownedCells")==saved.get("ownedCells").getAsInt(),"manufactured ownership restored");
                beginReplays();stage=7;
            } else {
                require(!Files.exists(playerFile(ACTOR)),"first player has never been saved");
                actor.gameMode.changeGameModeForPlayer(GameType.SURVIVAL);other.gameMode.changeGameModeForPlayer(GameType.SURVIVAL);
                ItemStack untouched=new ItemStack(Items.IRON_INGOT,7);untouched.getOrCreateTag().putString("fixture","完整保留");
                untouched.getOrCreateTag().putDouble("typed",-0.0d);actor.getInventory().setItem(9,untouched);
                installObserver();
            }
            running=true;nextTick=server.getTickCount()+20;
        } catch(Throwable problem){finish(problem);}
    }
    private void tick(TickEvent.ServerTickEvent event) {
        if(event.phase!=TickEvent.Phase.END || !running || finished || server.getTickCount()<nextTick)return;
        try {
            nextTick=server.getTickCount()+20;
            if(mode.equals("boundaries")){boundaryStep(stage++);return;}
            switch(stage++) {
                case 0->{survival();if(mode.equals("crash"))throw new AssertionError("Requested crash barrier was not reached");}
                case 1->cancelPlacement();
                case 2->cancelClick();
                case 3->creative();
                case 4->competingActors();
                case 5->nestedSupportChange();
                case 6->{beginReplays();stage=7;}
                case 7->{replay();stage=7;nextTick=server.getTickCount()+3;}
                default->throw new AssertionError("Unexpected fixture stage");
            }
        } catch(Throwable problem){finish(problem);}
    }
    private void prepare(int x,GameType type)throws Exception {
        target=new BlockPos(x,81,1026);level.setBlock(target.below(),Blocks.STONE.defaultBlockState(),3);
        require(level.getBlockState(target).isAir(),"fresh replacement target "+x);
        actor.gameMode.changeGameModeForPlayer(type);actor.moveTo(x+.5,81,1028.5,0,0);actor.setShiftKeyDown(false);actor.getInventory().selected=0;
        ItemStack held=new ItemStack(BuiltInRegistries.ITEM.get(new ResourceLocation("blockreality:steel_beam")),4);
        held.getOrCreateTag().putString("construction_material","保持標記");held.getOrCreateTag().putFloat("type",3.5f);actor.setItemInHand(InteractionHand.MAIN_HAND,held);
        base=revision();order=(long)call(metadata,"order");seq=sequence.get();inventoryBefore=inventory(actor);
        fullPlayerBefore=(CompoundTag)call(Class.forName("com.blockreality.impl.server.construction.LivePlayerInventory"),"player",actor);
    }
    private Object preview(ServerPlayer player)throws Exception {
        return preview(player,InteractionHand.MAIN_HAND);
    }
    private Object preview(ServerPlayer player,InteractionHand hand)throws Exception {
        Object reply=measured("preview",player,previewRequest(hand,level.dimension().location().toString()));
        require(status(reply).equals("READY"),"production preview READY: "+status(reply));
        Object offer=call(reply,"offer");require(call(offer,"target").equals(target),"server authors exact target");return offer;
    }
    private Object previewRequest(InteractionHand hand,String dimension)throws Exception {
        Class<?> type=Class.forName("com.blockreality.impl.net.ConstructionProtocol$Preview");
        return type.getConstructor(UUID.class,String.class,BlockPos.class,Direction.class,Vec3.class,InteractionHand.class,String.class,int.class)
                .newInstance(UUID.randomUUID(),dimension,target.below(),Direction.UP,
                        new Vec3(target.getX()+.5,target.getY(),target.getZ()+.5),hand,"blockreality:steel_beam",1);
    }
    private Object measured(String operation,ServerPlayer player,Object request)throws Exception {
        var bean=java.lang.management.ManagementFactory.getThreadMXBean();
        com.sun.management.ThreadMXBean allocations=bean instanceof com.sun.management.ThreadMXBean b && b.isThreadAllocatedMemorySupported()?b:null;
        if(allocations!=null && !allocations.isThreadAllocatedMemoryEnabled())allocations.setThreadAllocatedMemoryEnabled(true);
        long thread=Thread.currentThread().getId(),beforeBytes=allocations==null?-1:allocations.getThreadAllocatedBytes(thread),start=System.nanoTime();
        Object reply=call(serviceClass,operation,player,request);long elapsed=System.nanoTime()-start;
        long bytes=allocations==null?-1:allocations.getThreadAllocatedBytes(thread)-beforeBytes;
        callCosts.add(Map.of("operation",operation,"tick",server.getTickCount(),"request",request.toString(),"actor",player.getUUID().toString(),
                "status",status(reply),"elapsedNanoseconds",elapsed,"callingThreadAllocatedBytes",bytes));return reply;
    }
    private Object altered(Object request,String key)throws Exception {
        UUID id=(UUID)call(request,"id"),offer=(UUID)call(request,"offer"),domain=(UUID)call(request,"domain"),session=(UUID)call(request,"session");
        long revision=(long)call(request,"baseRevision");String hash=(String)call(request,"planHash");
        switch(key){case "id"->id=UUID.randomUUID();case "offer"->offer=UUID.randomUUID();case "domain"->domain=UUID.randomUUID();
            case "session"->session=UUID.randomUUID();case "baseRevision"->revision++;case "planHash"->hash=(hash.charAt(0)=='0'?"1":"0")+hash.substring(1);default->throw new AssertionError(key);}
        return request.getClass().getConstructor(UUID.class,UUID.class,UUID.class,UUID.class,long.class,String.class).newInstance(id,offer,domain,session,revision,hash);
    }
    private Map<String,String> playerFiles()throws Exception {
        Map<String,String> images=new TreeMap<>();Path directory=playerFile(ACTOR).getParent();
        if(Files.exists(directory))try(var files=Files.list(directory)){for(Path path:files.filter(Files::isRegularFile).toList())images.put(path.getFileName().toString(),Base64.getEncoder().encodeToString(Files.readAllBytes(path)));}
        return images;
    }
    private Map<String,Object> boundarySnapshot()throws Exception {
        Map<String,Object> image=new LinkedHashMap<>();
        image.put("target",target.toString());image.put("cell",Base64.getEncoder().encodeToString(encode(NbtUtils.writeBlockState(level.getBlockState(target)))));
        image.put("actor",Base64.getEncoder().encodeToString(encode(actor.saveWithoutId(new CompoundTag()))));
        image.put("other",Base64.getEncoder().encodeToString(encode(other.saveWithoutId(new CompoundTag()))));
        image.put("playerFiles",playerFiles());image.put("journal",journalImages());image.put("revision",revision());
        image.put("order",call(metadata,"order"));image.put("ownedCells",call(metadata,"ownedCells"));image.put("sequence",sequence.get());return image;
    }
    private void refused(String label,ServerPlayer player,Object request,String expected,boolean terminal)throws Exception {
        Map<String,Object> before=boundarySnapshot();Object reply=measured("confirm",player,request);Map<String,Object> after=boundarySnapshot();
        boundaryReceipts.add(Map.of("case",label,"request",request.toString(),"expected",expected,"actual",status(reply),"before",before,"after",after));
        require(status(reply).equals(expected),label+" expected "+expected+" actual "+status(reply));
        require(call(reply,"request").equals(request),label+" response retains exact request binding");
        if(terminal){
            Map<String,String> original=new TreeMap<>((Map<String,String>)before.get("journal"));Map<String,String> actual=new TreeMap<>((Map<String,String>)after.get("journal"));
            String name="txn-"+call(request,"id")+".brtx";require(!original.containsKey(name) && actual.remove(name)!=null && actual.equals(original),label+" adds only its durable rejection");
            before=new LinkedHashMap<>(before);after=new LinkedHashMap<>(after);before.remove("journal");after.remove("journal");
        }
        require(before.equals(after),label+" changes no world player files inventory identity clocks or old journal");
        require((boolean)call(serviceClass,"available",server),label+" leaves service available");
    }
    private void refusedPreview(String label,String dimension,String expected)throws Exception {
        Map<String,Object> before=boundarySnapshot();Object reply=measured("preview",actor,previewRequest(InteractionHand.MAIN_HAND,dimension));Map<String,Object> after=boundarySnapshot();
        boundaryReceipts.add(Map.of("case",label,"expected",expected,"actual",status(reply),"before",before,"after",after));
        require(status(reply).equals(expected),label+" expected "+expected+" actual "+status(reply));
        require(before.equals(after),label+" preview changes no durable or live state");
    }
    private void boundaryCommit(int x,InteractionHand hand,int count)throws Exception {
        prepare(x,GameType.SURVIVAL);actor.getInventory().selected=3;
        ItemStack material=actor.getInventory().getItem(0).copy();material.setCount(count);actor.setItemInHand(hand,material);
        inventoryBefore=inventory(actor);base=revision();order=(long)call(metadata,"order");seq=sequence.get();
        CompoundTag expected=(CompoundTag)call(Class.forName("com.blockreality.impl.server.construction.CanonicalNbt"),"decode",inventoryBefore,16<<20);
        ListTag entries=expected.getList("Inventory",Tag.TAG_COMPOUND);int savedSlot=hand==InteractionHand.OFF_HAND?150:3;boolean found=false;
        for(int i=0;i<entries.size();i++){CompoundTag item=entries.getCompound(i);if((item.getByte("Slot")&255)!=savedSlot)continue;
            require(!found && item.getByte("Count")==count,"independent boundary debit source exists");found=true;
            if(count==1)entries.remove(i);else item.putByte("Count",(byte)(count-1));break;}
        require(found,"independent boundary debit targets exact saved slot "+savedSlot);
        Object offer=preview(actor,hand),request=call(offer,"confirm",UUID.randomUUID());Object reply=measured("confirm",actor,request);
        boundaryReceipts.add(Map.of("case","commit-"+hand+"-"+count,"request",request.toString(),"actual",status(reply),"expectedInventory",Base64.getEncoder().encodeToString(encode(expected)),"after",boundarySnapshot()));
        require(status(reply).equals("COMMITTED"),"boundary "+hand+" Count="+count+" commits");
        require(Arrays.equals(encode(expected),inventory(actor)),"boundary "+hand+" Count="+count+" exact full inventory debit");
        require(PlayerInventoryTag(savedPlayer(ACTOR)).equals(expected),"boundary exact saved inventory including offhand slot encoding");
        require(revision()==base+1 && (long)call(metadata,"order")==order+1 && sequence.get()==seq+1,"boundary commit publishes exactly once");
    }
    private void boundaryStep(int step)throws Exception {
        String dimension=level.dimension().location().toString();
        if(step>=1 && step<=5){String key=List.of("offer","domain","session","baseRevision","planHash").get(step-1);refused("terminal changed "+key,actor,altered(firstRequest,key),"CONFLICT",false);return;}
        switch(step){
            case 0->survival();
            case 6->refused("terminal different authenticated actor",other,firstRequest,"CONFLICT",false);
            case 7->refused("new UUID cannot reuse consumed offer",actor,altered(firstRequest,"id"),"EXPIRED",false);
            case 8->refused("exact terminal receipt",actor,firstRequest,"COMMITTED",false);
            case 9->{prepare(1034,GameType.SURVIVAL);boundaryOffer=preview(actor);Object request=call(boundaryOffer,"confirm",UUID.randomUUID());
                for(String key:List.of("offer","domain","session","baseRevision","planHash"))refused("unexecuted changed "+key,actor,altered(request,key),List.of("offer","session").contains(key)?"EXPIRED":"CONFLICT",false);}
            case 10->refused("unexecuted different actor",other,call(boundaryOffer,"confirm",UUID.randomUUID()),"EXPIRED",false);
            case 11->{prepare(1034,GameType.SURVIVAL);Object offer=preview(actor);actor.getInventory().setItem(1,actor.getMainHandItem().copy());actor.getInventory().selected=1;refused("changed selected slot",actor,call(offer,"confirm",UUID.randomUUID()),"REJECTED",true);}
            case 12->{prepare(1034,GameType.SURVIVAL);Object offer=preview(actor);actor.getMainHandItem().getOrCreateTag().putString("construction_material","合法新標記");refused("changed held typed NBT",actor,call(offer,"confirm",UUID.randomUUID()),"REJECTED",true);}
            case 13->{prepare(1034,GameType.SURVIVAL);Object offer=preview(actor);actor.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(Items.STONE,4));refused("changed held product",actor,call(offer,"confirm",UUID.randomUUID()),"REJECTED",true);}
            case 14->{prepare(1034,GameType.SURVIVAL);Object offer=preview(actor);level.setBlock(target,Blocks.STONE.defaultBlockState(),3);refused("changed replacement state",actor,call(offer,"confirm",UUID.randomUUID()),"REJECTED",true);level.setBlock(target,Blocks.AIR.defaultBlockState(),3);}
            case 15->{prepare(1034,GameType.SURVIVAL);Object offer=preview(actor);actor.gameMode.changeGameModeForPlayer(GameType.ADVENTURE);refused("changed game mode",actor,call(offer,"confirm",UUID.randomUUID()),"REJECTED",true);}
            case 16->{prepare(1034,GameType.SURVIVAL);Object offer=preview(actor);actor.moveTo(1050,81,1028,0,0);refused("moved out of reach",actor,call(offer,"confirm",UUID.randomUUID()),"REJECTED",true);}
            case 17->{prepare(1034,GameType.ADVENTURE);refusedPreview("adventure",dimension,"PERMISSION");}
            case 18->{prepare(1034,GameType.SURVIVAL);actor.moveTo(1050,81,1028,0,0);refusedPreview("out of reach",dimension,"OUT_OF_REACH");}
            case 19->{prepare(1034,GameType.SURVIVAL);actor.containerMenu.setCarried(new ItemStack(Items.DIAMOND));refusedPreview("nonempty cursor",dimension,"PERMISSION");actor.containerMenu.setCarried(ItemStack.EMPTY);}
            case 20->{prepare(1034,GameType.SURVIVAL);refusedPreview("foreign dimension","minecraft:the_nether","CONFLICT");}
            case 21->boundaryCommit(1028,InteractionHand.MAIN_HAND,1);
            case 22->boundaryCommit(1030,InteractionHand.OFF_HAND,1);
            case 23->boundaryCommit(1032,InteractionHand.OFF_HAND,4);
            case 24->{prepare(1034,GameType.SURVIVAL);for(int i=0;i<8;i++)refusedPreview("invalid request admission "+i,"minecraft:the_nether","CONFLICT");refusedPreview("ninth invalid request rate limit","minecraft:the_nether","RATE_LIMITED");}
            case 25->{for(int i=0;i<8;i++)refused("exact replay admission "+i,actor,firstRequest,"COMMITTED",false);refused("ninth replay rate limit",actor,firstRequest,"RATE_LIMITED",false);}
            case 26->{prepare(1034,GameType.SURVIVAL);Object old=preview(actor),current=preview(actor);refused("replacement invalidates prior offer",actor,call(old,"confirm",UUID.randomUUID()),"EXPIRED",false);require(!call(old,"token").equals(call(current,"token")),"replacement has distinct token");}
            case 27->{prepare(1034,GameType.SURVIVAL);Object offer=preview(actor);expiryRequest=call(offer,"confirm",UUID.randomUUID());expiryTick=server.getTickCount();nextTick=expiryTick+200;}
            case 28->{require(server.getTickCount()-expiryTick==200,"expiry observed at exactly 200 real server ticks");refused("offer expired at lifetime",actor,expiryRequest,"EXPIRED",false);}
            case 29->{prepare(1034,GameType.SURVIVAL);Map<String,Object> before=boundarySnapshot();
                for(int i=0;i<65;i++){ServerPlayer player=FakePlayerFactory.get(level,new GameProfile(UUID.nameUUIDFromBytes(("placement-capacity-"+i).getBytes(java.nio.charset.StandardCharsets.UTF_8)),"Capacity"+i));
                    player.gameMode.changeGameModeForPlayer(GameType.SURVIVAL);player.moveTo(1034.5,81,1028.5,0,0);player.setItemInHand(InteractionHand.MAIN_HAND,actor.getMainHandItem().copy());capacityActors.add(player);
                    Object reply=measured("preview",player,previewRequest(InteractionHand.MAIN_HAND,dimension));require(status(reply).equals(i<64?"READY":"CAPACITY"),"offer capacity actor "+i+" status "+status(reply));
                    if(i<64)capacityOffers.add(call(reply,"offer"));
                    if(i==0)boundaryOffer=call(reply,"offer");}
                require(before.equals(boundarySnapshot()),"64 offers and capacity refusal allocate no world player files journals identities or publications");}
            case 30->{Object offers=field(service,"offers");
                for(int i=0;i<64;i++)require(((Optional<?>)call(offers,"get",capacityActors.get(i),call(capacityOffers.get(i),"token"),server.getTickCount())).isPresent(),"capacity refusal retains actor "+i+" exact live offer");
                MinecraftForge.EVENT_BUS.post(new net.minecraftforge.event.entity.player.PlayerEvent.PlayerLoggedOutEvent(capacityActors.get(1)));
                require((int)call(offers,"size",server.getTickCount())==63,"logout releases only one offer");
                for(int i=0;i<64;i++)require(((Optional<?>)call(offers,"get",capacityActors.get(i),call(capacityOffers.get(i),"token"),server.getTickCount())).isPresent()==(i!=1),"logout preserves exact offer membership for actor "+i);
                preview(capacityActors.get(64));require((int)call(offers,"size",server.getTickCount())==64,"released capacity admits waiting actor");finish(null);}
            default->throw new AssertionError("Unknown boundary stage "+step);
        }
    }
    private void survival()throws Exception {
        prepare(1026,GameType.SURVIVAL);
        Map<String,String> initial=journalImages();
        var result=actor.gameMode.useItemOn(actor,level,actor.getMainHandItem(),InteractionHand.MAIN_HAND,
                new BlockHitResult(new Vec3(1026.5,81,1026.5),Direction.UP,target.below(),false));
        require(result==InteractionResult.PASS,"ordinary server item use performs no construction");
        require(level.getBlockState(target).isAir() && Arrays.equals(inventoryBefore,inventory(actor)),"ordinary entry preserves world and all inventory bytes");
        Object offer=preview(actor);committedOffer=offer;
        require(initial.equals(journalImages()) && !Files.exists(playerFile(ACTOR)),"preview allocates no journal or player file");
        require(revision()==base && (long)call(metadata,"order")==order,"preview allocates no revision or permanent identity");
        firstRequest=call(offer,"confirm",UUID.randomUUID());observing=true;
        firstOutcome=call(serviceClass,"confirm",actor,firstRequest);observing=false;
        require(status(firstOutcome).equals("COMMITTED"),"survival confirmation COMMITTED: "+status(firstOutcome));
        require(actor.getMainHandItem().getCount()==3,"survival debits exactly one item");
        require(NbtUtils.writeBlockState(level.getBlockState(target)).getCompound("Properties").getString("axis").equals("y"),"placed cell retains explicit Y declaration");
        this.result.put("survivalPublication",Map.of("baseRevision",base,"actualRevision",revision(),"baseOrder",order,
                "actualOrder",call(metadata,"order"),"baseSequence",seq,"actualSequence",sequence.get()));
        require(revision()==base+1 && (long)call(metadata,"order")==order+1 && sequence.get()==seq+1,"one public revision metadata order and envelope");
        verifyExactDebit(false);require((int)call(metadata,"ownedCells")==1,"one manufactured cell born");
        require(PlayerInventoryTag(savedPlayer(ACTOR)).equals(PlayerInventoryTag(actor.saveWithoutId(new CompoundTag()))),"complete live and durable inventory agree");
    }
    private void cancelPlacement()throws Exception {
        prepare(1028,GameType.SURVIVAL);Object offer=preview(actor);cancellingPlace=true;
        Object result=call(serviceClass,"confirm",actor,call(offer,"confirm",UUID.randomUUID()));cancellingPlace=false;
        require(status(result).equals("ABORTED"),"EntityPlace cancellation produces durable ABORTED: "+status(result));
        unchanged("cancelled EntityPlace");
        require(PlayerInventoryTag(savedPlayer(ACTOR)).equals(PlayerInventoryTag(actor.saveWithoutId(new CompoundTag()))),"cancelled material fully flushed back");
        require((boolean)call(serviceClass,"available",server),"cancelled placement leaves service available");
    }
    private void cancelClick()throws Exception {
        prepare(1030,GameType.SURVIVAL);Object offer=preview(actor);cancellingClick=true;
        Object result=call(serviceClass,"confirm",actor,call(offer,"confirm",UUID.randomUUID()));cancellingClick=false;
        require(status(result).equals("REJECTED"),"RightClickBlock cancellation rejected before apply");unchanged("cancelled right click");
    }
    private void creative()throws Exception {
        prepare(1032,GameType.CREATIVE);Object offer=preview(actor);
        Object result=call(serviceClass,"confirm",actor,call(offer,"confirm",UUID.randomUUID()));
        require(status(result).equals("COMMITTED"),"creative confirmation COMMITTED: "+status(result));
        verifyExactDebit(true);require(revision()==base+1 && (long)call(metadata,"order")==order+1,"creative publishes one revision and identity");
    }
    private void competingActors()throws Exception {
        prepare(1034,GameType.SURVIVAL);other.moveTo(1034.5,81,1028.5,0,0);other.setItemInHand(InteractionHand.MAIN_HAND,actor.getMainHandItem().copy());
        Object a=preview(actor),b=preview(other);byte[] otherBefore=inventory(other);
        Object first=call(serviceClass,"confirm",actor,call(a,"confirm",UUID.randomUUID()));
        Object second=call(serviceClass,"confirm",other,call(b,"confirm",UUID.randomUUID()));
        require(status(first).equals("COMMITTED") && status(second).equals("STALE"),"two actors resolve to one committed build and one stale refusal");
        require(Arrays.equals(otherBefore,inventory(other)) && !Files.exists(playerFile(other.getUUID())),"losing actor has no debit or checkpoint");
        require(revision()==base+1 && (long)call(metadata,"order")==order+1,"competing requests create one identity and revision");
        require((int)call(metadata,"ownedCells")==3,"three committed cells only");
    }
    private void placed(BlockEvent.EntityPlaceEvent event) {
        if(actor==null || event.getEntity()!=actor || !event.getPos().equals(target))return;
        try {
            require(Arrays.equals(inventoryBefore,inventory(actor)),"EntityPlace sees exact before inventory");
            require((boolean)call(serviceClass,"busy",server) && revision()==base && (long)call(metadata,"order")==order,"EntityPlace sees private candidate without public revision or identity");
            if(cancellingPlace)event.setCanceled(true);
        } catch(Exception problem){throw new RuntimeException(problem);}
    }
    private void nestedSupportChange()throws Exception {
        prepare(1036,GameType.SURVIVAL);Object offer=preview(actor);changeSupportOnNotification=true;
        Object reply=call(serviceClass,"confirm",actor,call(offer,"confirm",UUID.randomUUID()));
        require(status(reply).equals("COMMITTED") && !changeSupportOnNotification,"normal post-commit neighbor notification was dispatched");
        require(level.getBlockState(target.below()).isAir() && !level.getBlockState(target).isAir(),"foreign neighbor callback made the intended real support change");
        require(revision()==base+2 && (long)call(metadata,"order")==order+1,"one construction revision plus one real support-change revision");
        require((int)call(metadata,"ownedCells")==4,"neighbor notifications do not manufacture extra pieces");
    }
    private void neighbor(BlockEvent.NeighborNotifyEvent event) {
        if(!changeSupportOnNotification || event.getLevel()!=level || !event.getPos().equals(target))return;
        changeSupportOnNotification=false;
        try {
            require(!(boolean)call(serviceClass,"busy",server) && revision()==base+1,"neighbor callback runs after private ownership and publication");
            level.setBlock(target.below(),Blocks.AIR.defaultBlockState(),3);
            require(revision()==base+2,"nested support notification remains observed");
        } catch(Exception failure){throw new RuntimeException(failure);}
    }
    private void clicked(PlayerInteractEvent.RightClickBlock event) {if(cancellingClick && event.getEntity()==actor)event.setCanceled(true);}
    private void unchanged(String name)throws Exception {
        require(level.getBlockState(target).isAir() && Arrays.equals(inventoryBefore,inventory(actor)),name+" restores world and full inventory");
        require(revision()==base && (long)call(metadata,"order")==order && sequence.get()==seq,name+" publishes no identity revision or envelope");
    }
    private void verifyExactDebit(boolean creative)throws Exception {
        CompoundTag before=(CompoundTag)call(Class.forName("com.blockreality.impl.server.construction.CanonicalNbt"),"decode",inventoryBefore,16<<20);
        if(!creative) {
            ListTag entries=before.getList("Inventory",Tag.TAG_COMPOUND);boolean changed=false;
            for(int i=0;i<entries.size();i++) {
                CompoundTag entry=entries.getCompound(i);
                if(entry.getByte("Slot")!=0)continue;
                require(!changed && entry.getByte("Count")==4,"independent expected material starts at four");
                entry.putByte("Count",(byte)3);changed=true;
            }
            require(changed,"independent expected material slot exists");
        }
        require(Arrays.equals(encode(before),inventory(actor)),"all inventory fields preserved around "+(creative?"creative no-debit":"one-item debit"));
    }
    private void installObserver()throws Exception {
        Field field=journal.getClass().getDeclaredField("faults");field.setAccessible(true);originalFaults=field.get(journal);Class<?> type=field.getType();
        field.set(journal,Proxy.newProxyInstance(type.getClassLoader(),new Class<?>[]{type},(proxy,method,args)-> {
            if(method.getName().equals("at")){
                try {barrier(args[0].toString(),args[1]);}
                catch(Throwable failure) {
                    var trace=new StringWriter();failure.printStackTrace(new PrintWriter(trace));
                    Files.writeString(output.resolve("observer-failure.txt"),trace.toString(),StandardOpenOption.CREATE_NEW);throw failure;
                }
                return null;
            }
            return method.getName().equals("toString")?"PlacementObserver":method.getName().equals("hashCode")?System.identityHashCode(proxy):proxy==args[0];
        }));
    }
    private void barrier(String point,Object entry)throws Exception {
        if(!observing)return;String phase=call(entry,"phase").toString();
        if(!(phase.equals("PREPARED")&&point.equals("DIRECTORY_FORCED") || phase.equals("COMMITTED")&&point.equals("TEMP_FORCED")))return;
        require(revision()==base && (long)call(metadata,"order")==order && sequence.get()==seq,phase+" has no public provisional state");
        boolean prepared=phase.equals("PREPARED");
        require(level.getBlockState(target).isAir()==prepared && actor.getMainHandItem().getCount()==(prepared?4:3),phase+" world and material at correct barrier");
        require(savedPlayer(ACTOR).getList("Inventory",Tag.TAG_COMPOUND).getCompound(0).getByte("Count")== (prepared?4:3),phase+" full player file already durable");
        Files.write(output.resolve(phase+"-player.nbt"),encode(savedPlayer(ACTOR)),StandardOpenOption.CREATE_NEW);
        barriers.add(Map.of("phase",phase,"point",point,"worldAir",level.getBlockState(target).isAir(),"heldCount",actor.getMainHandItem().getCount()));
    }
    private void beginReplays()throws Exception {
        replayInventory=inventory(actor);replayJournal=journalImages();replayRevision=revision();replayOrder=(long)call(metadata,"order");replaySequence=sequence.get();
        Files.write(output.resolve("before-100-replays.nbt"),replayInventory,StandardOpenOption.CREATE_NEW);
    }
    /** Invoked by the test debugger on the suspended Server thread. No task pumping or participant writes. */
    private void captureCrash(String point)throws Exception {
        require(mode.equals("crash") && server.isSameThread() && firstRequest!=null,"debugger reached owned live construction");
        Object request=firstRequest;UUID id=(UUID)call(request,"id");
        Object entry=((Optional<?>)call(journal,"verify",id)).orElseThrow();String phase=call(entry,"phase").toString();
        boolean committed=Set.of("committed","published").contains(point);
        require(phase.equals(committed?"COMMITTED":"PREPARED"),"actual durable journal phase at "+point);
        int liveExpected=Set.of("prepared","world-applied").contains(point)?4:3;
        require(actor.getMainHandItem().getCount()==liveExpected,"actual live material at "+point);
        require(level.getBlockState(target).isAir()==point.equals("prepared"),"actual live world at "+point);
        CompoundTag disk=savedPlayer(ACTOR);
        int diskExpected=Set.of("player-durable","committed-temp","committed","published").contains(point)?3:4;
        require(savedCount(disk)==diskExpected,"actual durable player material at "+point);
        CompoundTag fullAfter=fullPlayerBefore.copy();
        for(Tag tag:fullAfter.getList("Inventory",Tag.TAG_COMPOUND)) {
            CompoundTag item=(CompoundTag)tag;if(item.getByte("Slot")==0)item.putByte("Count",(byte)3);
        }
        byte[] wire;var buffer=new FriendlyByteBuf(Unpooled.buffer());
        try{call(Class.forName("com.blockreality.impl.net.ConstructionProtocol"),"encodeConfirmation",request,buffer);wire=new byte[buffer.readableBytes()];buffer.readBytes(wire);}finally{buffer.release();}
        CompoundTag afterState=new CompoundTag();afterState.putString("Name","blockreality:steel_beam");CompoundTag properties=new CompoundTag();properties.putString("axis","y");afterState.put("Properties",properties);
        Map<String,Object> expected=new LinkedHashMap<>();expected.put("point",point);expected.put("committed",committed);expected.put("request",Base64.getEncoder().encodeToString(wire));
        expected.put("baseRevision",base);expected.put("beforePlayer",Base64.getEncoder().encodeToString(encode(fullPlayerBefore)));expected.put("afterPlayer",Base64.getEncoder().encodeToString(encode(fullAfter)));
        expected.put("beforeCell",Base64.getEncoder().encodeToString(encode(NbtUtils.writeBlockState(Blocks.AIR.defaultBlockState()))));expected.put("afterCell",Base64.getEncoder().encodeToString(encode(afterState)));
        Files.writeString(serverRoot.resolve("CRASH_EXPECTED.json"),JSON.toJson(expected),StandardOpenOption.CREATE_NEW);
        Files.write(output.resolve("crash-live-player.nbt"),encode((CompoundTag)call(Class.forName("com.blockreality.impl.server.construction.LivePlayerInventory"),"player",actor)),StandardOpenOption.CREATE_NEW);
        Files.write(output.resolve("crash-disk-player.nbt"),encode(disk),StandardOpenOption.CREATE_NEW);
        Files.write(output.resolve("crash-live-cell.nbt"),encode(NbtUtils.writeBlockState(level.getBlockState(target))),StandardOpenOption.CREATE_NEW);
        Path snapshot=Files.createDirectory(output.resolve("crash-journal"));
        try(var files=Files.list((Path)field(journal,"directory"))){for(Path file:files.filter(Files::isRegularFile).toList())Files.copy(file,snapshot.resolve(file.getFileName()));}
        Path region=server.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("region/r.2.2.mca");
        Files.copy(region,output.resolve("crash-region.mca"));Files.copy(playerFile(ACTOR),output.resolve("crash-player.dat"));
        Files.writeString(output.resolve("crash-observation.json"),JSON.toJson(Map.of("point",point,"phase",phase,"liveCount",liveExpected,"diskCount",diskExpected,
                "publicRevision",revision(),"metadataOrder",call(metadata,"order"),"checks",checks,"syntheticPlayers",true)),StandardOpenOption.CREATE_NEW);
        System.out.println("BR_PLACEMENT_CRASH_CAPTURE "+point);
    }
    private void recoverCrash()throws Exception {
        JsonObject expected=JsonParser.parseString(Files.readString(serverRoot.resolve("CRASH_EXPECTED.json"))).getAsJsonObject();boolean committed=expected.get("committed").getAsBoolean();
        long floor=expected.get("baseRevision").getAsLong()+(committed?1:0);
        require(revision()>=floor,"offline recovery restores revision floor before test chunk load");
        require((int)call(metadata,"ownedCells")== (committed?1:0),"offline recovery publishes only durable manufactured ownership");
        var buffer=new FriendlyByteBuf(Unpooled.wrappedBuffer(Base64.getDecoder().decode(expected.get("request").getAsString())));
        Object request;try{request=call(Class.forName("com.blockreality.impl.net.ConstructionProtocol"),"decodeConfirmation",buffer);}finally{buffer.release();}
        UUID id=(UUID)call(request,"id");Object entry=((Optional<?>)call(journal,"verify",id)).orElseThrow();
        require(call(entry,"phase").toString().equals(committed?"COMMITTED":"ABORTED"),"actual terminal decision matches interrupted durability");
        byte[] playerExpected=Base64.getDecoder().decode(expected.get(committed?"afterPlayer":"beforePlayer").getAsString());
        require(Arrays.equals(playerExpected,encode(savedPlayer(ACTOR))),"entire offline player document restored exactly before login");
        level.getChunk(64,64);
        byte[] cellExpected=Base64.getDecoder().decode(expected.get(committed?"afterCell":"beforeCell").getAsString());
        require(Arrays.equals(cellExpected,encode(NbtUtils.writeBlockState(level.getBlockState(target)))),"entire declared world cell matches durable decision");
        Path journalFile=((Path)field(journal,"directory")).resolve("txn-"+id+".brtx");
        byte[] actual=Files.readAllBytes(journalFile);Path original=serverRoot.resolve("RECOVERED-JOURNAL.bin");
        if(mode.equals("recover-second"))require(Arrays.equals(Files.readAllBytes(original),actual),"second restart leaves terminal journal bytes identical");
        else Files.write(original,actual,StandardOpenOption.CREATE_NEW);
        Files.write(output.resolve("recovered-player.nbt"),encode(savedPlayer(ACTOR)),StandardOpenOption.CREATE_NEW);
        Files.write(output.resolve("recovered-cell.nbt"),encode(NbtUtils.writeBlockState(level.getBlockState(target))),StandardOpenOption.CREATE_NEW);
        Files.copy(journalFile,output.resolve("recovered-transaction.brtx"));
    }
    private static int savedCount(CompoundTag root) {
        for(Tag tag:root.getList("Inventory",Tag.TAG_COMPOUND)){CompoundTag item=(CompoundTag)tag;if(item.getByte("Slot")==0)return item.getByte("Count");}
        return 0;
    }
    private void replay()throws Exception {
        long beforeRevision=revision(),beforeSequence=sequence.get();
        Object reply=call(serviceClass,"confirm",actor,firstRequest);
        require(reply.equals(firstOutcome),"admitted exact replay "+(replays+1)+" retains original receipt");
        require(Arrays.equals(replayInventory,inventory(actor)) && replayJournal.equals(journalImages()) && beforeRevision==revision()
                && replayOrder==(long)call(metadata,"order") && beforeSequence==sequence.get(),"replay "+(replays+1)+" changes no items journal identity revision or publication");
        replayClocks.add(Map.of("tick",server.getTickCount(),"revision",beforeRevision,"sequence",beforeSequence));
        if(++replays==100) {
            if(!mode.equals("restart")) {
                var buffer=new FriendlyByteBuf(Unpooled.buffer());byte[] wire;
                try{call(Class.forName("com.blockreality.impl.net.ConstructionProtocol"),"encodeConfirmation",firstRequest,buffer);wire=new byte[buffer.readableBytes()];buffer.readBytes(wire);}finally{buffer.release();}
                Files.writeString(serverRoot.resolve("REPLAY.json"),JSON.toJson(Map.of("request",Base64.getEncoder().encodeToString(wire),"ownedCells",call(metadata,"ownedCells"))),StandardOpenOption.CREATE_NEW);
            }
            finish(null);
        }
    }
    private Map<String,String> journalImages()throws Exception {
        Map<String,String> images=new TreeMap<>();Path directory=(Path)field(journal,"directory");
        try(var files=Files.list(directory)){for(Path path:files.filter(Files::isRegularFile).toList())images.put(path.getFileName().toString(),Base64.getEncoder().encodeToString(Files.readAllBytes(path)));}
        return images;
    }
    private Path playerFile(UUID id){return server.getWorldPath(net.minecraft.world.level.storage.LevelResource.PLAYER_DATA_DIR).resolve(id+".dat");}
    private CompoundTag savedPlayer(UUID id)throws Exception {
        Constructor<?> constructor=Class.forName("com.blockreality.impl.server.construction.PlayerFileParticipant").getDeclaredConstructor(Path.class);
        constructor.setAccessible(true);Object adapter=constructor.newInstance(playerFile(id).getParent());
        return (CompoundTag)call(call(adapter,"capture",id),"data");
    }
    private static CompoundTag PlayerInventoryTag(CompoundTag player){CompoundTag result=new CompoundTag();result.put("Inventory",player.get("Inventory").copy());result.putInt("SelectedItemSlot",player.getInt("SelectedItemSlot"));return result;}
    private byte[] inventory(ServerPlayer player)throws Exception{return encode(PlayerInventoryTag(player.saveWithoutId(new CompoundTag())));}
    private static byte[] encode(CompoundTag tag)throws Exception{return (byte[])call(Class.forName("com.blockreality.impl.server.construction.CanonicalNbt"),"encode",tag,16<<20);}
    private static String status(Object value)throws Exception{return call(value,"status").toString();}
    private long revision()throws Exception{return ((Number)call(call(call(manager,"gate"),"current"),"value")).longValue();}
    private void require(boolean condition,String label){if(!condition)throw new AssertionError(label);checks.add(label);}
    private void finish(Throwable problem) {
        if(finished)return;finished=true;running=false;result.put("status",problem==null?"PASS":"FAIL");result.put("mode",mode);result.put("checks",checks);result.put("barriers",barriers);result.put("syntheticPlayers",true);result.put("replayClocks",replayClocks);
        result.put("boundaryReceipts",boundaryReceipts);result.put("callCostsRecorded",callCosts);
        if(problem!=null){var trace=new StringWriter();problem.printStackTrace(new PrintWriter(trace));result.put("trace",trace.toString());}
        try{if(journal!=null && originalFaults!=null){Field field=journal.getClass().getDeclaredField("faults");field.setAccessible(true);field.set(journal,originalFaults);}if(output!=null)Files.writeString(output.resolve("result.json"),JSON.toJson(result),StandardOpenOption.CREATE_NEW);}catch(Exception failure){failure.printStackTrace();}
        System.out.println("BR_PLACEMENT_PROBE "+result.get("status")+" checks="+checks.size());if(server!=null)server.halt(false);
    }
    private static Object field(Object target,String name)throws Exception{Class<?> type=target instanceof Class<?> c?c:target.getClass();Field field=type.getDeclaredField(name);field.setAccessible(true);return field.get(target instanceof Class<?>?null:target);}
    private static Object call(Object target,String name,Object...args)throws Exception {
        Class<?> type=target instanceof Class<?> c?c:target.getClass();
        for(Method method:type.getDeclaredMethods()) {
            if(!method.getName().equals(name) || method.getParameterCount()!=args.length)continue;
            boolean match=true;Class<?>[] parameters=method.getParameterTypes();
            for(int i=0;i<args.length;i++){Class<?> p=parameters[i];if(p==int.class)p=Integer.class;else if(p==long.class)p=Long.class;else if(p==boolean.class)p=Boolean.class;if(args[i]!=null&&!p.isInstance(args[i]))match=false;}
            if(!match)continue;method.setAccessible(true);
            try{return method.invoke(target instanceof Class<?>?null:target,args);}catch(InvocationTargetException failure){if(failure.getCause() instanceof Exception exception)throw exception;if(failure.getCause() instanceof Error error)throw error;throw new AssertionError(failure.getCause());}
        }
        throw new NoSuchMethodException(type.getName()+"."+name);
    }
}
