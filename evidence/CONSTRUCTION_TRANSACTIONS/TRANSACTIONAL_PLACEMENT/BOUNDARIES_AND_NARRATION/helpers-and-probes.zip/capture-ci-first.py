from pathlib import Path
import json, subprocess

root=Path('C:/Users/wmc02/Desktop/block-reality');out=root/'build/transactional-placement'
expected='587786b96ba522fb4b6f54f6d125039b7ab5f2de';run='34476235037'
raw=subprocess.check_output(['gh','run','view',run,'--repo','rocky59487/block-reality','--json','databaseId,headSha,status,conclusion,jobs,url'],cwd=root)
data=json.loads(raw);assert data['headSha']==expected and data['status']=='completed' and data['conclusion']=='success'
assert len(data['jobs'])==4 and all(job['conclusion']=='success' for job in data['jobs'])
path=out/'ci-587786b-first.json';assert not path.exists();path.write_bytes(raw)
skips=[{'job':job['name'],'step':step['name']} for job in data['jobs'] for step in job['steps'] if step['conclusion']=='skipped']
summary={'head':expected,'run_id':run,'successful_jobs':4,'skipped_steps':skips,'url':data['url']}
(out/'ci-587786b-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2),flush=True)
