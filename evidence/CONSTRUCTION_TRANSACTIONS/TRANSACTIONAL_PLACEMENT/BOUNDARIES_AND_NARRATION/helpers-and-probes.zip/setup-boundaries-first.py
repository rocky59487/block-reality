from pathlib import Path
import shutil,socket,json,hashlib,zipfile
root=Path('/home/rocky/br-transactional-placement');assert (root/'OWNER').read_text().strip()=='block-reality-transactional-placement-qualification-v1'
server=root/'installed-boundaries-first';assert not server.exists()
with socket.socket() as socket_:socket_.bind(('127.0.0.1',25602))
source=Path('/home/rocky/br-native-v15-consumer/installed-server');server.mkdir();shutil.copytree(source/'libraries',server/'libraries')
for name in ['run.sh','run.bat','eula.txt']:shutil.copy2(source/name,server/name)
(server/'OWNER').write_text('block-reality-placement-runtime-v1\n');(server/'mods').mkdir()
win=Path('/mnt/c/Users/wmc02/Desktop/block-reality/build/transactional-placement');candidate=win/'blockreality-candidate-fourth.jar'
identity=json.loads((win/'candidate-fourth-identity.json').read_text());assert hashlib.sha256(candidate.read_bytes()).hexdigest()==identity['sha256']
assert json.loads((win/'forge-full-fourth-exit.json').read_text())['exit']==0
shutil.copy2(candidate,server/'mods/blockreality-0.4.0-dev.jar')
harness=root/'qualification/br-placement-probe-seventh.jar';harness_identity=json.loads((root/'qualification/harness-seventh-identity.json').read_text())
assert hashlib.sha256(harness.read_bytes()).hexdigest()==harness_identity['sha256']
shutil.copy2(harness,server/'mods/br-placement-probe.jar')
(server/'server.properties').write_text('server-ip=127.0.0.1\nserver-port=25602\nonline-mode=false\nenable-rcon=false\nenable-query=false\nlevel-name=placement-runtime\nlevel-type=minecraft:flat\ngenerate-structures=false\nspawn-protection=0\nview-distance=3\nsimulation-distance=3\nmax-players=2\nmax-tick-time=180000\n')
(root/'qualification/installed-boundaries-first-identity.json').write_text(json.dumps({'jar_sha256':identity['sha256'],'harness_sha256':harness_identity['sha256'],'server':str(server),'fresh_world':True,'port':25602,'only_libraries_and_launcher_copied':True},indent=2))
print('Prepared owned placement server',flush=True)
