from pathlib import Path
import os,subprocess,sys,json,zipfile,hashlib,shutil
root=Path('C:/Users/wmc02/Desktop/block-reality');out=root/'build/transactional-placement';out.mkdir(exist_ok=True)
files=subprocess.check_output(['git','ls-files','-co','--exclude-standard'],cwd=root,text=True).splitlines()
manifest={}
with zipfile.ZipFile(out/'source-initial.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
    for name in files:
        if name.startswith(('forge/','mod/','gradle/','contract/','scripts/','third_party/')) or name in ['LICENSE','NOTICE','docs/CT_TRANSACTIONAL_PLACEMENT.md']:
            p=root/name;data=p.read_bytes();z.writestr(name,data);manifest[name]=hashlib.sha256(data).hexdigest()
    z.writestr('__sha256.json',json.dumps(manifest,indent=2))
env=dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8');env['JAVA_HOME']='C:/Program Files/Eclipse Adoptium/jdk-17.0.18.8-hotspot';env['PATH']=env['JAVA_HOME']+'/bin;'+env['PATH']
for phase,folder,tasks in [('core','mod',[':core:test','--tests','*TransientOffersTest','--tests','*ManufacturedRegistryTest']),('forge','forge',['test','--tests','*PlacementPlanTest','--tests','*ConstructionProtocolTest'])]:
    command=['cmd','/c','gradlew.bat','--no-daemon','--console=plain',*tasks]
    with (out/(phase+'-initial.log')).open('xb') as log:r=subprocess.run(command,cwd=root/folder,env=env,stdout=log,stderr=subprocess.STDOUT)
    (out/(phase+'-initial-exit.json')).write_text(json.dumps({'command':command,'exit':r.returncode,'source_snapshot':'source-initial.zip'}))
    xml=root/('mod/core/build/test-results/test' if phase=='core' else 'forge/build/test-results/test')
    if xml.exists():shutil.copytree(xml,out/(phase+'-initial-xml'))
    print(phase,'initial',r.returncode,flush=True)
    if r.returncode:sys.exit(r.returncode)
