from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile

root=Path('C:/Users/wmc02/Desktop/block-reality');build=root/'build/transactional-placement'
linux=Path('//wsl.localhost/Ubuntu-22.04/home/rocky/br-transactional-placement');logs=linux/'qualification'
parent=root/'evidence/CONSTRUCTION_TRANSACTIONS/TRANSACTIONAL_PLACEMENT';out=parent/'BOUNDARIES_AND_NARRATION';out.mkdir()
def tree(folder):return [(p.relative_to(folder).as_posix(),p) for p in folder.rglob('*') if p.is_file()]
def pack(path,files):
    manifest={}
    with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for name,source in files:
            assert name not in manifest;data=source.read_bytes();archive.writestr(name,data);manifest[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
        archive.writestr('__sha256.json',json.dumps(manifest,indent=2))
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        for name,identity in manifest.items():assert hashlib.sha256(archive.read(name)).hexdigest()==identity['sha256']
    print(path.name,len(manifest),'files verified',flush=True)

for label,count in [('first',328),('second',455)]:
    runtime=logs/('runtime-boundaries-'+label+'-boundaries');report=json.loads((runtime/'result.json').read_text(encoding='utf-8'))
    assert report['status']=='PASS' and len(report['checks'])==count and json.loads((runtime/'exit.json').read_text())=={'exit':0,'timeout':False}
    pack(out/(runtime.name+'.zip'),tree(runtime))
    server=linux/('installed-boundaries-'+label)
    selected=['OWNER','server.properties','placement-runtime/region/r.2.2.mca','placement-runtime/playerdata/a5e13344-b530-4238-9878-e107c84f17b4.dat']
    pack(out/('boundary-'+label+'-final-world-after-stop.zip'),[(name,server/name) for name in selected])
    shutil.copy2(build/('boundary-costs-'+label+'-separated.json'),out/('boundary-costs-'+label+'-separated.json'))
ui=logs/'ui-run-third';assert json.loads((ui/'result.json').read_text())['status']=='PASS'
for label in ['client-first','server']:assert json.loads((ui/label/'exit.json').read_text())=={'exit':0,'cleanup_terminated_owned_group':False}
pack(out/'ui-run-third.zip',tree(ui));shutil.copytree(build/'ui-preview-third',out/'screenshots')

for platform,folder,stem in [('windows',build,'forge-full-fifth'),('linux',logs,'linux-forge-full-fifth')]:
    pack(out/(platform+'-forge-full-fifth.zip'),[(stem+'.log',folder/(stem+'.log')),(stem+'-exit.json',folder/(stem+'-exit.json'))]+[(stem+'-xml/'+name,path) for name,path in tree(folder/(stem+'-xml'))])
pack(out/'source-candidate-fifth.zip',[('source-candidate-fifth.zip',build/'source-candidate-fifth.zip')])
helpers=[]
for name,path in tree(build):
    if path.suffix in ['.py','.java','.gradle','.toml'] and not name.startswith(('debugger/classes/','ui-preview-')):helpers.append((name,path))
pack(out/'helpers-and-probes.zip',helpers)
history=[]
for name in ['br-placement-probe-seventh.jar','br-placement-probe-eighth.jar','harness-seventh.log','harness-seventh-exit.json','harness-seventh-identity.json','harness-eighth.log','harness-eighth-exit.json','harness-eighth-identity.json',
             'ui-client-probe-third.java','ui-client-probe-third-retry.java','ui-server-probe-third.java','ui-client-build-third.log','ui-client-build-third-exit.json','ui-client-build-third-retry.log','ui-client-build-third-retry-exit.json',
             'ui-server-build-third.log','ui-server-build-third-exit.json','br-placement-ui-probe-third.jar','ui-server-harness-third-identity.json','ui-client-shipping-source-fifth-identity.json','screen-narration-bytecode.txt']:
    history.append((name,logs/name))
for folder in logs.glob('harness-source-*'):
    if folder.name in ['harness-source-sixth','harness-source-seventh']:history.extend([(folder.name+'/'+name,path) for name,path in tree(folder)])
pack(out/'probe-build-history.zip',history)
for name in ['candidate-fifth-identity.json','dual-platform-tests-fifth.json','shipping-shape-fifth.json','core-full-fifth-reused.json','ci-587786b-first.json','ci-587786b-summary.json']:
    shutil.copy2(build/name,out/name)
pack(out/'shipping-gates-fifth.zip',[(name,build/name) for name in ['class-guard-fifth.log','class-guard-fifth-exit.json','bundle-fifth.log','bundle-fifth-exit.json']])
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert commit.startswith('56541f4')
with zipfile.ZipFile(build/'source-candidate-fifth.zip') as archive:
    manifest=json.loads(archive.read('__sha256.json'));names=list(manifest)
    batch=subprocess.run(['git','cat-file','--batch'],input=''.join(commit+':'+name+'\n' for name in names).encode(),cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True).stdout
    offset=0;normalized=[]
    for name in names:
        end=batch.index(b'\n',offset);header=batch[offset:end].split();assert len(header)==3 and header[1]==b'blob'
        size=int(header[2]);blob=batch[end+1:end+1+size];offset=end+2+size;data=archive.read(name)
        assert hashlib.sha256(data).hexdigest()==manifest[name]
        if data!=blob:
            data.decode('utf-8');blob.decode('utf-8');assert data.replace(b'\r\n',b'\n')==blob.replace(b'\r\n',b'\n'),name;normalized.append(name)
    assert offset==len(batch)
(out/'source-identity.json').write_text(json.dumps({'source_commit':commit,'source_archive_sha256':hashlib.sha256((build/'source-candidate-fifth.zip').read_bytes()).hexdigest(),'all_snapshot_files_compared':len(names),'text_line_ending_normalization':normalized,'production_changes_after_fifth_build':False},indent=2))
print('Archived boundary and narration evidence; add report before final hash manifest',flush=True)
