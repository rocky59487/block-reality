from pathlib import Path
from collections import defaultdict
import json, math, sys
root=Path('//wsl.localhost/Ubuntu-22.04/home/rocky/br-transactional-placement/qualification')
label=sys.argv[1];source=root/('runtime-boundaries-'+label+'-boundaries/result.json')
report=json.loads(source.read_text(encoding='utf-8'));assert report['status']=='PASS'
groups=defaultdict(list)
for call in report['callCostsRecorded']:groups[(call['operation'],call['status'])].append(call)
summary=[]
for (operation,status),calls in groups.items():
    result={'operation':operation,'status':status,'samples':len(calls)}
    for key in ['elapsedNanoseconds','callingThreadAllocatedBytes']:
        values=sorted(call[key] for call in calls)
        result[key]={'minimum':values[0],'median':values[len(values)//2],'p95_nearest_rank':values[math.ceil(len(values)*.95)-1],'maximum':values[-1]}
    summary.append(result)
result={'qualification':'Recorded only; no warmup, isolation, threshold, FPS or soak claim. Synthetic fixture includes test EntityPlace observer work and ordinary background analysis. Allocations are only the calling server thread.','source':str(source),'checks':len(report['checks']),'calls':len(report['callCostsRecorded']),'groups':summary}
target=Path(__file__).resolve().parent/('boundary-costs-'+label+'.json')
with target.open('x',encoding='utf-8') as f:json.dump(result,f,indent=2)
print(json.dumps({'checks':result['checks'],'calls':result['calls'],'commits':[v for v in summary if v['status']=='COMMITTED']},indent=2))
