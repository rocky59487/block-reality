from pathlib import Path
import base64, hashlib, json, os, shutil, signal, socket, struct, subprocess, time, traceback

root = Path('/home/rocky/br-transactional-placement'); qualification = root / 'qualification'
win = Path('/mnt/c/Users/wmc02/Desktop/block-reality/build/transactional-placement')
run = qualification / 'ui-run-third'; server = root / 'installed-ui-third'
client_build = root / 'ui-client-build-first'; profile = client_build / 'forge/run-placement-ui-third'
assert (root / 'OWNER').read_text().strip() == 'block-reality-transactional-placement-qualification-v1'
assert not run.exists() and not server.exists()
assert json.loads((qualification / 'ui-client-build-third-retry-exit.json').read_text())['exit'] == 0
with socket.socket() as check: check.bind(('127.0.0.1', 25630))
run.mkdir(); server.mkdir(); server_output = run / 'server'; server_output.mkdir()
for directory in [run, server, server_output]: (directory / 'OWNER').write_text('block-reality-placement-ui-v1\n')
source = Path('/home/rocky/br-native-v15-consumer/installed-server')
shutil.copytree(source / 'libraries', server / 'libraries')
for name in ['run.sh', 'run.bat', 'eula.txt']: shutil.copy2(source / name, server / name)
(server / 'mods').mkdir()
ordinary = win / 'blockreality-candidate-fourth.jar'
assert hashlib.sha256(ordinary.read_bytes()).hexdigest() == json.loads((win / 'candidate-fourth-identity.json').read_text())['sha256']
shutil.copy2(ordinary, server / 'mods/blockreality-0.4.0-dev.jar')
shutil.copy2(qualification / 'br-placement-ui-probe-third.jar', server / 'mods/br-placement-ui-probe.jar')
(server / 'server.properties').write_text('server-ip=127.0.0.1\nserver-port=25630\nonline-mode=false\nenable-rcon=false\nenable-query=false\nlevel-name=placement-ui\nlevel-type=minecraft:flat\ngenerate-structures=false\nspawn-protection=0\nview-distance=3\nsimulation-distance=3\nmax-players=1\nmax-tick-time=180000\n')
(server / 'user_jvm_args.txt').write_text('-Xms512m\n-Xmx2g\n-Dbr.placementUiOutput=' + str(server_output) + '\n')
env = dict(os.environ, OPENBLAS_CORETYPE='Haswell', OPENBLAS_NUM_THREADS='1'); env.pop('BR_ENGINE', None); env.pop('BR_SIDECAR', None)
processes = []; checks = []; ids = {}; receipts = []; start = time.monotonic()


def require(condition, label):
    if not condition: raise AssertionError(label)
    checks.append(label)


def launch(command, cwd, output, environment):
    log = (output / 'process.log').open('xb')
    process = subprocess.Popen(command, cwd=cwd, env=environment, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    processes.append((process, log, output))
    (output / 'process-owner.json').write_text(json.dumps({'pid': process.pid, 'process_group': process.pid, 'cwd': str(cwd), 'command': command}))
    return process


def wait_state(output, predicate=lambda value: True, timeout=35):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if (output / 'fatal.txt').exists(): raise AssertionError((output / 'fatal.txt').read_text())
        file = output / 'state.json'
        if file.exists():
            value = json.loads(file.read_text())
            if predicate(value): return value
        time.sleep(.1)
    raise TimeoutError(str(output) + ' last state: ' + ((output / 'state.json').read_text()[-6000:] if (output / 'state.json').exists() else 'missing'))


def command(output, action, name, **values):
    key = str(output); ids[key] = ids.get(key, 0) + 1
    payload = dict(id=ids[key], action=action, name=name, **values)
    (output / 'control.next').write_text(json.dumps(payload)); (output / 'control.next').replace(output / 'control.json')
    deadline = time.monotonic() + 75
    while not (output / (name + '.json')).exists():
        if (output / 'fatal.txt').exists(): raise AssertionError((output / 'fatal.txt').read_text())
        if time.monotonic() > deadline: raise TimeoutError('Command ' + name)
        time.sleep(.1)
    receipt = json.loads((output / (name + '.json')).read_text()); receipts.append(str(output / (name + '.json')))
    return receipt


def server_state(): return command(server_output, 'inspect', 'inspect-' + str(ids.get(str(server_output), 0) + 1))['after']


def start_client(label):
    output = run / label; output.mkdir(); (output / 'OWNER').write_text('block-reality-placement-ui-v1\n')
    tools = Path('/home/rocky/br-render-tools'); environment = dict(env)
    environment.update(PATH=str(tools / 'root/usr/bin') + ':' + env['PATH'], LD_LIBRARY_PATH=str(tools / 'root/usr/lib/x86_64-linux-gnu'), LIBGL_ALWAYS_SOFTWARE='1', LP_NUM_THREADS='4')
    cmd = [str(tools / 'root/usr/bin/xvfb-run'), '-a', '-e', str(output / 'xvfb.log'), '-s', '-screen 0 1920x1080x24 -nolisten tcp -fp ' + str(tools / 'root/usr/share/fonts/X11/misc'),
           'bash', 'gradlew', '--no-daemon', '--console=plain', '-I', '../placement-probe.gradle', '-Dbr.placementUiOutput=' + str(output), '-PbrNativesDir=/home/rocky/br-native-v15-consumer/staged', 'runClient']
    process = launch(cmd, client_build / 'forge', output, environment)
    wait_state(output, lambda s: s['connected'] and s['screen'] == 'none', 240)
    wait_state(server_output, lambda s: s['connected'])
    return output, process


def prepare(client, x, **settings):
    command(server_output, 'prepare', 'prepare-' + str(x), x=x, **settings)
    wait_state(client, lambda s: s.get('heldCount') == 8 and abs(s.get('position', [0])[0] - x - .5) < .01 and s['screen'] == 'none')
    command(client, 'aim', 'aim-' + str(x), x=x, y=81.5 if settings.get('chest') else 81)
    command(client, 'interact', 'interact-' + str(x))
    if not settings.get('chest'):
        state = wait_state(client, lambda s: s.get('session', {}).get('status') == 'READY' and not s['session']['waiting'])
        require(state['session']['target'] == [x, 81, 1026], 'real crosshair preview authors target ' + str(x))
        return state


def button(client, index, name): command(client, 'button', name, index=index)


def capture(client, name, language='en_us', small=True):
    image = command(client, 'capture', name, language=language, width=1280 if small else 1920, height=720 if small else 1080, scale=3 if small else 1)
    require(image['actual']['language'] == language, 'actual screenshot language ' + name)
    return image['actual']


def closed(client, name):
    command(client, 'key', name, key=256); wait_state(client, lambda s: s['screen'] == 'none')


def confirmation_frames(state): return [f['base64'] for f in state['frames'] if f['direction'] == 'C2S' and f['discriminator'] == 1]


def pending_count():
    data = (profile / 'blockreality/construction/pending.bin').read_bytes()
    require(len(data) >= 40 and hashlib.sha256(data[:-32]).digest() == data[-32:], 'outbox raw digest valid')
    require(data[:4] == b'BRP1', 'outbox raw schema')
    return struct.unpack('>I', data[4:8])[0]


try:
    server_process = launch(['bash', 'run.sh', 'nogui'], server, server_output, env)
    wait_state(server_output, timeout=180)
    client, client_process = start_client('client-first')
    prepare(client, 1026)
    ready = capture(client, 'ready-zh-large', 'zh_tw', small=False)
    require(ready['session']['status'] == 'READY' and ready['session']['ghost'], 'large Chinese ready preview and ghost')
    translations = json.loads((win.parent.parent/'forge/src/main/resources/assets/blockreality/lang/zh_tw.json').read_text())
    narration = command(client, 'narration', 'ready-narration')['collectedNarration']
    for text in [translations['block.blockreality.steel_beam'], '軸向：Y', '材料用量：1 個', '1026, 81, 1026', ready['session']['message'], '確認放置']:
        require(text in narration, 'native narration includes ready detail: ' + text)
    button(client, 1, 'refresh-y-before-loss')
    wait_state(client, lambda s: s.get('session', {}).get('status') == 'READY' and not s['session']['waiting'])
    baseline = server_state(); offered_tick = baseline['serverTick']
    require(baseline['order'] == 0 and baseline['heldCount'] == 8 and 'minecraft:air' in baseline['cells']['1026'], 'preview has no durable construction')
    command(client, 'drop-confirmation', 'arm-unsent-confirmation'); button(client, 3, 'confirm-dropped-before-server')
    pending = wait_state(client, lambda s: s.get('session', {}).get('localError') == 'br.build.unresolved' and not s['session']['waiting'])
    pending_id = pending['session']['request']; wire = confirmation_frames(pending)[-1]
    require(sum(f['dropped'] and f['direction']=='C2S' and f['discriminator']==1 for f in pending['frames']) == 1, 'exactly one real outgoing confirmation intercepted')
    require(pending_count() == 1 and pending['heldCount'] == 8, 'timeout retains durable request without material debit')
    original_pending = (profile/'blockreality/construction/pending.bin').read_bytes()
    (run/'pending-after-timeout.bin').write_bytes(original_pending)
    narrow = command(client, 'capture', 'pending-en-narrow-top', language='en_us', width=960, height=720, scale=3)['actual']
    require(narrow['guiWidth'] == 320 and narrow['guiHeight'] == 240, 'actual minimum supported 320 by 240 GUI')
    require(narrow['maximumScroll'] > 0 and narrow['scroll'] == 0 and narrow['bodyBottom'] > narrow['bodyTop'], 'real unresolved English text exceeds positive body viewport')
    command(client, 'key', 'overflow-page-down', key=267)
    scrolled = command(client, 'capture', 'pending-en-narrow-down', language='en_us', width=960, height=720, scale=3)['actual']
    require(scrolled['scroll'] == min(48, scrolled['maximumScroll']) and scrolled['scroll'] > 0, 'native PageDown moves actual bounded text scroll')
    require(narrow['buttons'] == scrolled['buttons'], 'scroll leaves all native controls and focus fixed')
    command(client, 'key', 'overflow-page-up', key=266)
    require(command(client, 'inspect', 'after-page-up')['after']['scroll'] == 0, 'native PageUp returns to text origin')
    pending_narration = command(client, 'narration', 'pending-narration')['collectedNarration']
    english = json.loads((win.parent.parent/'forge/src/main/resources/assets/blockreality/lang/en_us.json').read_text())
    require(english['br.build.unresolved'] in pending_narration and english['br.build.close_notice'] in pending_narration, 'native narration includes clipped pending status and retained-request notice')
    closed(client, 'close-unresolved')
    require((profile/'blockreality/construction/pending.bin').read_bytes() == original_pending, 'closing does not release or rewrite pending binding')
    command(client, 'interact', 'reopen-unresolved')
    restored = wait_state(client, lambda s: s.get('session', {}).get('request') == pending_id and s['screen'] == 'PlacementScreen')
    require(not restored['session']['ghost'], 'reopened unresolved request has no active placement ghost')
    expired_clock = wait_state(server_output, lambda s: s['serverTick'] >= offered_tick + 200)
    (run/'expiry-server-clock.json').write_text(json.dumps({'offer_already_received_by_tick':offered_tick, 'retry_after_tick':expired_clock['serverTick']}, indent=2))
    untouched = server_state()
    require(all(untouched[k] == baseline[k] for k in ['inventory','order','ownedCells','journal','cells']), 'unsent confirmation and timeout produced no server construction')
    button(client, 3, 'retry-expired-original')
    expired = wait_state(client, lambda s: s.get('session', {}).get('status') == 'EXPIRED' and not s['session']['waiting'])
    require(confirmation_frames(expired) == [wire, wire], 'explicit retry uses byte-identical original C2S binding')
    require(not expired['session']['terminal'] and pending_count() == 1, 'server EXPIRED alone retains original pending record')
    require((profile/'blockreality/construction/pending.bin').read_bytes() == original_pending, 'EXPIRED reply does not silently discard pending request')
    shutil.copy2(profile/'blockreality/construction/pending.bin', run/'pending-after-server-expired.bin')
    expired_zh = capture(client, 'expired-zh-small', 'zh_tw')
    require(expired_zh['buttons'][3]['label'] == '重新預覽' and expired_zh['buttons'][3]['active'], 'expired screen explicitly labels separate new preview action')
    expired_narration = command(client, 'narration', 'expired-narration')['collectedNarration']
    require(translations['br.build.status.expired'] in expired_narration and '重新預覽' in expired_narration, 'native narration announces server expiry and focused new-preview action')
    before_new = server_state(); button(client, 3, 'explicit-new-preview')
    fresh = wait_state(client, lambda s: s.get('session', {}).get('status') == 'READY' and s['session']['request'] == 'none' and not s['session']['waiting'])
    require(pending_count() == 0 and fresh['session']['ghost'], 'explicit action clears only expired record and obtains new preview')
    require(confirmation_frames(fresh) == [wire, wire], 'new preview does not send a new confirmation')
    after_new = server_state()
    require(all(before_new[k] == after_new[k] for k in ['inventory','order','ownedCells','journal','cells']), 'new preview requires another confirmation before any construction')
    button(client, 3, 'confirm-new-preview')
    committed = wait_state(client, lambda s: s.get('session', {}).get('terminal') and s['session']['status'] == 'COMMITTED' and s['heldCount'] == 7)
    require(committed['session']['request'] != pending_id and confirmation_frames(committed)[-1] != wire, 'separate confirmation uses a fresh transaction UUID and binding')
    final_server = server_state()
    require(final_server['order'] == 1 and final_server['ownedCells'] == 1 and final_server['heldCount'] == 7 and 'steel_beam' in final_server['cells']['1026'], 'only separate final confirmation creates one component and one debit')
    require(pending_count() == 0 and not committed['session']['ghost'], 'durable success clears exact new pending request and ghost')
    require(not committed['buttons'][3]['visible'] and committed['buttons'][4]['focused'], 'terminal native Done focus remains intact')
    capture(client, 'committed-zh-large', 'zh_tw', small=False)
    terminal_narration = command(client, 'narration', 'committed-narration')['collectedNarration']
    require(translations['br.build.status.committed'] in terminal_narration and '完成' in terminal_narration, 'native terminal narration contains saved decision and Done control')
    command(client, 'exit', 'exit-client-first'); require(client_process.wait(timeout=120) == 0, 'actual client exits normally')
    command(server_output, 'exit', 'exit-server'); require(server_process.wait(timeout=120) == 0, 'installed ordinary server exits normally')
    (run/'result.json').write_text(json.dumps({'status':'PASS','checks':checks,'receipts':receipts,'elapsed_seconds':time.monotonic()-start,'client_scope':'Linux development client from fifth shipping sources plus test-only probe; native narration text collected, audio/TTS not qualified; owned synthetic account and llvmpipe','server_jar_sha256':hashlib.sha256(ordinary.read_bytes()).hexdigest()},indent=2))
    print('Actual placement expiry/overflow/narration PASS',len(checks),flush=True)
except BaseException:
    (run / 'first-failure.txt').write_text(traceback.format_exc())
    (run / 'result.json').write_text(json.dumps({'status': 'FAIL', 'checks': checks, 'receipts': receipts, 'elapsed_seconds': time.monotonic() - start}, indent=2))
    raise
finally:
    for process, log, output in reversed(processes):
        terminated = process.poll() is None
        if terminated:
            os.killpg(process.pid, signal.SIGTERM)
            try: process.wait(timeout=20)
            except subprocess.TimeoutExpired: os.killpg(process.pid, signal.SIGKILL); process.wait()
        log.close(); (output / 'exit.json').write_text(json.dumps({'exit': process.returncode, 'cleanup_terminated_owned_group': terminated}))
