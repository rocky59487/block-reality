from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,xml.etree.ElementTree as ET,zipfile
root=Path('C:/Users/wmc02/Desktop/block-reality');out=root/'build/transactional-placement';linux=Path('//wsl.localhost/Ubuntu-22.04/home/rocky/br-transactional-placement/qualification')
previous=json.loads((out/'dual-platform-tests-fourth.json').read_text());summary={}
for platform,folder,stem in [('windows',out,'forge-full-fifth'),('linux',linux,'linux-forge-full-fifth')]:
    assert json.loads((folder/(stem+'-exit.json')).read_text())['exit']==0
    suites=[ET.parse(p).getroot() for p in (folder/(stem+'-xml')).glob('TEST-*.xml')]
    counts={key:sum(int(s.get(key,0)) for s in suites) for key in ['tests','failures','errors','skipped']}
    skips=sorted(s.get('name')+'.'+c.get('name') for s in suites for c in s.findall('testcase') if c.find('skipped') is not None)
    assert counts==previous[platform]['forge']['counts'] and skips==sorted(previous[platform]['forge']['skipped_tests'])
    summary[platform]={'forge':{'counts':counts,'skipped_tests':skips,'raw_results':stem+'-xml'},'core_reused_unchanged':previous[platform]['core'],'registered':previous[platform]['registered'],'passed':previous[platform]['passed'],'skipped':previous[platform]['skipped']}
(out/'dual-platform-tests-fifth.json').write_text(json.dumps(summary,indent=2))
jar=out/'blockreality-candidate-fifth.jar';identity=json.loads((out/'candidate-fifth-identity.json').read_text());assert hashlib.sha256(jar.read_bytes()).hexdigest()==identity['sha256']
stage=out/'bundle-fifth';stage.mkdir();shutil.copy2(jar,stage/'blockreality-0.4.0-dev.jar');(stage/'SHA256SUMS.txt').write_text(identity['sha256']+'  blockreality-0.4.0-dev.jar\n')
env=dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8',JAVA_HOME='C:/Program Files/Eclipse Adoptium/jdk-17.0.18.8-hotspot');env['PATH']=env['JAVA_HOME']+'/bin;'+env['PATH']
for label,args in [('class-guard',['scripts/check_native_only_jar.py',str(jar)]),('bundle',['scripts/check_bundle.py',str(stage)])]:
    command=[sys.executable,*args]
    with (out/(label+'-fifth.log')).open('xb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    (out/(label+'-fifth-exit.json')).write_text(json.dumps({'exit':r.returncode,'command':command}));print(label,r.returncode,flush=True)
    if r.returncode:sys.exit(r.returncode)
with zipfile.ZipFile(jar) as archive:
    names=archive.namelist();assert sum(name.endswith('.class') for name in names)==291
    assert not any('testplacement' in name.lower() or 'PlacementUiProbe' in name for name in names)
    libraries={name:hashlib.sha256(archive.read(name)).hexdigest() for name in names if name.endswith(('.dll','.so'))}
    assert libraries==json.loads((out/'shipping-shape-fourth.json').read_text())['native_libraries']
(out/'shipping-shape-fifth.json').write_text(json.dumps({'jar':identity,'classes':291,'native_libraries':libraries,'ordinary_jar_has_no_test_probes':True,'unchanged_guard_mutation_evidence':'fourth class guard 3 compiled arms; bundle 9 injections; scripts byte-identical in source snapshots'},indent=2))
print(json.dumps({p:{k:s[k] for k in ['registered','passed','skipped']} for p,s in summary.items()},indent=2))
