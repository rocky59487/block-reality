from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys, xml.etree.ElementTree as ET, zipfile

root=Path('C:/Users/wmc02/Desktop/block-reality');out=root/'build/transactional-placement'
linux=Path('//wsl.localhost/Ubuntu-22.04/home/rocky/br-transactional-placement/qualification')
baseline=json.loads((root/'evidence/CONSTRUCTION_TRANSACTIONS/FORGE_AXIS_TRANSACTIONS/windows/dual-platform-tests.json').read_text())
summary={}
for platform,folder,versions in [('windows',out,{'core':'core-full-third','forge':'forge-full-fourth'}),('linux',linux,{'core':'linux-core-full-fourth','forge':'linux-forge-full-fourth'})]:
    record={};native=[]
    for phase,version in versions.items():
        assert json.loads((folder/(version+'-exit.json')).read_text())['exit']==0
        suites=[ET.parse(file).getroot() for file in (folder/(version+'-xml')).glob('TEST-*.xml')]
        counts={key:sum(int(suite.get(key,0)) for suite in suites) for key in ['tests','failures','errors','skipped']}
        skipped=[suite.get('name')+'.'+case.get('name') for suite in suites for case in suite.findall('testcase') if case.find('skipped') is not None]
        assert counts['failures']==counts['errors']==0
        assert sorted(skipped)==sorted(baseline[platform][phase]['skipped_tests'])
        for suite in suites:
            if 'Native' in suite.get('name'):
                for case in suite.findall('testcase'):
                    assert case.find('skipped') is None
                    native.append(suite.get('name')+'.'+case.get('name'))
        record[phase]={'counts':counts,'skipped_tests':skipped,'raw_results':version+'-xml'}
    record['registered']=sum(record[phase]['counts']['tests'] for phase in ['core','forge'])
    record['skipped']=sum(record[phase]['counts']['skipped'] for phase in ['core','forge']);record['passed']=record['registered']-record['skipped'];record['native_named_tests_all_executed']=native
    summary[platform]=record
(out/'dual-platform-tests-fourth.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({platform:{key:record[key] for key in ['registered','passed','skipped']} for platform,record in summary.items()},indent=2),flush=True)
jar=out/'blockreality-candidate-fourth.jar';stage=out/'bundle-fourth';assert not stage.exists();stage.mkdir()
shutil.copy2(jar,stage/'blockreality-0.4.0-dev.jar')
(stage/'SHA256SUMS.txt').write_text(hashlib.sha256(jar.read_bytes()).hexdigest()+'  blockreality-0.4.0-dev.jar\n')
env=dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8',JAVA_HOME='C:/Program Files/Eclipse Adoptium/jdk-17.0.18.8-hotspot');env['PATH']=env['JAVA_HOME']+'/bin;'+env['PATH']
for label,args in [('class-guard',['scripts/check_native_only_jar.py',str(jar),'--mutation-checks']),('bundle',['scripts/check_bundle.py',str(stage)]),('bundle-negatives',['scripts/check_bundle_selftest.py',str(stage)]),('contract',['contract/check_contract.py'])]:
    command=[sys.executable,*args]
    with (out/(label+'-fourth.log')).open('xb') as log:result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    (out/(label+'-fourth-exit.json')).write_text(json.dumps({'command':command,'exit':result.returncode}));print(label,result.returncode,flush=True)
    if result.returncode:sys.exit(result.returncode)
with zipfile.ZipFile(jar) as archive:
    names=archive.namelist();assert not any('testplacement' in name.lower() or 'PlacementUiProbe' in name for name in names)
    classes=[name for name in names if name.endswith('.class')];assert len(classes)==291
    libs={name:hashlib.sha256(archive.read(name)).hexdigest() for name in names if name.endswith(('.dll','.so'))}
    assert len(libs)==2
(out/'shipping-shape-fourth.json').write_text(json.dumps({'classes':len(classes),'test_placement_harness_absent':True,'native_libraries':libs,'jar_sha256':hashlib.sha256(jar.read_bytes()).hexdigest()},indent=2))
