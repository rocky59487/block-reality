from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys, zipfile

root=Path('/home/rocky/br-transactional-placement');out=root/'qualification';client=root/'ui-client-build-first'
win=Path('/mnt/c/Users/wmc02/Desktop/block-reality/build/transactional-placement')
assert json.loads((out/'ui-run-first/result.json').read_text())['status']=='PASS'
assert json.loads((out/'ui-run-first/client-first/exit.json').read_text())['exit']==0
assert json.loads((out/'ui-run-first/client-second/exit.json').read_text())['exit']==0
source='forge/src/main/java/com/blockreality/impl/client/PlacementScreen.java'
with zipfile.ZipFile(win/'source-candidate-third.zip') as archive:
    data=archive.read(source);identity=json.loads(archive.read('__sha256.json'));assert hashlib.sha256(data).hexdigest()==identity[source]
    (out/'ui-client-shipping-source-third-identity.json').write_text(json.dumps(identity,indent=2))
before=(client/source).read_bytes();(out/'ui-placement-screen-before-second.java').write_bytes(before);(client/source).write_bytes(data)
probe=client/'placement-probe/java/com/blockreality/impl/client/PlacementUiProbe.java'
(out/'ui-probe-before-second.java').write_bytes(probe.read_bytes());shutil.copy2(win/'ui-client/PlacementUiProbe.java',probe)
(out/'ui-client-source-second.java').write_bytes(probe.read_bytes())
init=client/'placement-probe.gradle';init.write_text(init.read_text().replace("p.file('run-placement-ui')","p.file('run-placement-ui-second')"))
profile=client/'forge/run-placement-ui-second';assert not profile.exists();profile.mkdir();(profile/'OWNER').write_text('block-reality-placement-ui-v1\n')
(profile/'options.txt').write_text('version:3465\nonboardAccessibility:false\npauseOnLostFocus:false\nguiScale:3\nrenderDistance:4\nsimulationDistance:3\nmaxFps:30\nenableVsync:false\nlang:en_us\nautoJump:false\n')
command=['bash','gradlew','--no-daemon','--console=plain','-I','../placement-probe.gradle','-Dbr.placementUiOutput='+str(out/'ui-run-second/client-first'),'-PbrNativesDir=/home/rocky/br-native-v15-consumer/staged','classes']
env=dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8');env.pop('BR_ENGINE',None);env.pop('BR_SIDECAR',None)
with (out/'ui-client-build-second.log').open('xb') as log:result=subprocess.run(command,cwd=client/'forge',env=env,stdout=log,stderr=subprocess.STDOUT)
(out/'ui-client-build-second-exit.json').write_text(json.dumps({'exit':result.returncode,'command':command,'before_screen_sha256':hashlib.sha256(before).hexdigest(),'after_screen_sha256':hashlib.sha256(data).hexdigest()}));print('UI second compile',result.returncode,flush=True)
if result.returncode:sys.exit(result.returncode)
driver=(win/'run-ui-first.py').read_text().replace("'ui-run-first'","'ui-run-second'").replace("'installed-ui-first'","'installed-ui-second'").replace("'forge/run-placement-ui'","'forge/run-placement-ui-second'")
driver=driver.replace('ui-client-build-first-exit.json','ui-client-build-second-exit.json').replace('blockreality-candidate-second.jar','blockreality-candidate-third.jar').replace('candidate-second-identity.json','candidate-third-identity.json')
old="    button(client, 3, 'confirm-survival')"
new="""    command(client, 'key', 'tab-to-cancel', key=258)
    keyboard = command(client, 'inspect', 'inspect-keyboard-cancel')['after']
    require(keyboard['buttons'][-1]['focused'], 'native Tab moves focus to cancel')
    command(client, 'key', 'enter-cancels', key=257); wait_state(client, lambda s: s['screen'] == 'none')
    keyboard_cancel = server_state()
    require(all(keyboard_cancel[k] == after_cancel[k] for k in ['inventory', 'order', 'journal', 'cells']), 'native Enter on cancel leaves construction unchanged')
    command(client, 'interact', 'reopen-keyboard-confirm')
    wait_state(client, lambda s: s.get('session', {}).get('status') == 'READY' and not s['session']['waiting'])
    command(client, 'key', 'enter-confirms', key=257)"""
assert driver.count(old)==1;driver=driver.replace(old,new)
old="    require(large['session']['status'] == 'READY' and large['session']['ghost'], 'large English actual ready ghost')"
driver=driver.replace(old,old+"\n    require(large['buttons'][-1]['y'] + large['buttons'][-1]['height'] < large['guiHeight'] / 2, 'large GUI panel follows its compact content')")
old="    after = server_state()"
assert driver.count(old)==1
driver=driver.replace(old,"    require(not committed['buttons'][-2]['visible'] and committed['buttons'][-1]['focused'], 'terminal receipt hides retry and moves keyboard focus to Done')\n"+old)
(win/'run-ui-second.py').write_text(driver)
