from pathlib import Path
from collections import defaultdict
import json,math,sys
root=Path('//wsl.localhost/Ubuntu-22.04/home/rocky/br-transactional-placement/qualification')
label=sys.argv[1];source=root/('runtime-boundaries-'+label+'-boundaries/result.json')
report=json.loads(source.read_text(encoding='utf-8'));assert report['status']=='PASS'
replays={receipt['request'] for receipt in report['boundaryReceipts'] if receipt['case']=='exact terminal receipt'}
assert len(replays)==1
groups=defaultdict(list)
for call in report['callCostsRecorded']:
    kind='preview' if call['operation']=='preview' else 'existing terminal binding' if call['request'] in replays else 'new confirmation binding'
    groups[(call['operation'],call['status'],kind)].append(call)
summary=[]
for (operation,status,kind),calls in groups.items():
    row={'operation':operation,'status':status,'kind':kind,'samples':len(calls)}
    for key in ['elapsedNanoseconds','callingThreadAllocatedBytes']:
        values=sorted(call[key] for call in calls)
        row[key]={'minimum':values[0],'median':values[len(values)//2],'p95_nearest_rank':values[math.ceil(len(values)*.95)-1],'maximum':values[-1]}
    summary.append(row)
assert sum(row['samples'] for row in summary if row['status']=='COMMITTED' and row['kind']=='new confirmation binding')==3
result={'qualification':'Recorded only; correctness fixture with no warmup, isolation, threshold, FPS or soak claim. Includes test EntityPlace observer work and ordinary background analysis. Allocations are only the calling server thread. Three new successful commits are separated from exact terminal replays.','source':str(source),'checks':len(report['checks']),'calls':len(report['callCostsRecorded']),'groups':summary}
target=Path(__file__).resolve().parent/('boundary-costs-'+label+'-separated.json')
with target.open('x',encoding='utf-8') as f:json.dump(result,f,indent=2)
print(json.dumps([row for row in summary if row['status']=='COMMITTED'],indent=2))
