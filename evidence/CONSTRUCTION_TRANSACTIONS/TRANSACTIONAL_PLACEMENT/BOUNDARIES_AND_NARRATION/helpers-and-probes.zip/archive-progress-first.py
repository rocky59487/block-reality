from pathlib import Path
import hashlib, json, shutil, zipfile

root=Path('C:/Users/wmc02/Desktop/block-reality');build=root/'build/transactional-placement'
linux=Path('//wsl.localhost/Ubuntu-22.04/home/rocky/br-transactional-placement');logs=linux/'qualification'
out=root/'evidence/CONSTRUCTION_TRANSACTIONS/TRANSACTIONAL_PLACEMENT'
assert not out.exists();out.mkdir();(out/'.gitattributes').write_text('** -text\n')
assert json.loads((logs/'ui-run-second/result.json').read_text())['status']=='PASS'
assert all(record['expected_behavioral_failure'] for record in json.loads((logs/'policy-negatives-first.json').read_text()))
assert json.loads((logs/'crash-disk-second.json').read_text())['status']=='PASS'

def tree(folder): return [(path.relative_to(folder).as_posix(),path) for path in folder.rglob('*') if path.is_file()]

def pack(path,files):
    manifest={}
    with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for name,source in files:
            assert name not in manifest
            data=source.read_bytes();archive.writestr(name,data);manifest[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
        archive.writestr('__sha256.json',json.dumps(manifest,indent=2))
    with zipfile.ZipFile(path) as archive:
        for name,identity in manifest.items(): assert hashlib.sha256(archive.read(name)).hexdigest()==identity['sha256']
    print(path.name,len(manifest),'verified files',flush=True)

for platform,folder in [('windows',build),('linux',logs)]:
    files=[(name,path) for name,path in tree(folder) if '/' not in name and path.suffix in ['.json','.log','.txt']]
    pack(out/(platform+'-receipts.zip'),files)
    for folder_ in folder.iterdir():
        if folder_.is_dir() and folder_.name.endswith('-xml'):
            pack(out/(platform+'-'+folder_.name+'.zip'),tree(folder_))

for folder in sorted(logs.iterdir()):
    if folder.is_dir() and folder.name.startswith(('runtime-','crash-','recover-')):
        assert (folder/'exit.json').exists(),folder
        pack(out/(folder.name+'.zip'),tree(folder))
for label in ['ui-run-first','ui-run-second']:
    folder=logs/label
    assert json.loads((folder/'result.json').read_text())['status']=='PASS'
    for phase in ['server','client-first','client-second']:
        assert json.loads((folder/phase/'exit.json').read_text())=={'exit':0,'cleanup_terminated_owned_group':False}
    pack(out/(label+'.zip'),tree(folder))

pack(out/'source-attempts.zip',[(path.name,path) for path in build.glob('source-*.zip')])
helpers=[(name,path) for name,path in tree(build) if path.suffix in ['.py','.java','.gradle','.toml'] and not name.startswith(('debugger/classes/','ui-preview-'))]
pack(out/'helpers-and-current-probes.zip',helpers)
probes=[]
for folder in logs.glob('harness-source-*'):
    probes.extend([(folder.name+'/'+name,path) for name,path in tree(folder)])
probes.extend([(path.name,path) for path in logs.glob('br-placement-probe-*.jar')])
probes.extend([(path.name,path) for path in logs.glob('br-placement-ui-probe-*.jar')])
probes.extend([(path.name,path) for path in logs.glob('policy-*-source.java')])
probes.extend([(path.name,path) for path in logs.glob('ui-*.java')])
for folder in logs.glob('ui-*-source-first'):
    probes.extend([(folder.name+'/'+name,path) for name,path in tree(folder)])
pack(out/'probe-history.zip',probes)

compiled={}
for path in logs.glob('blockreality-policy-*-first.jar'):
    identity=json.loads((logs/(path.name.removeprefix('blockreality-').removesuffix('.jar')+'-identity.json')).read_text())
    with zipfile.ZipFile(path) as archive:compiled[path.stem+'/'+identity['only_changed_entry']]=archive.read(identity['only_changed_entry'])
with zipfile.ZipFile(build/'blockreality-neighbor-guard-omitted-second.jar') as archive:compiled['neighbor-guard-omitted/com/blockreality/impl/server/StructureManager.class']=archive.read('com/blockreality/impl/server/StructureManager.class')
with zipfile.ZipFile(out/'compiled-negative-classes.zip','x',compression=zipfile.ZIP_DEFLATED) as archive:
    for name,data in compiled.items():archive.writestr(name,data)
    archive.writestr('__sha256.json',json.dumps({name:hashlib.sha256(data).hexdigest() for name,data in compiled.items()},indent=2))

final_world=[]
for server in linux.glob('installed-crash-*-first'):
    for relative in ['CRASH_EXPECTED.json','RECOVERED-JOURNAL.bin','placement-runtime/region/r.2.2.mca','placement-runtime/playerdata/a5e13344-b530-4238-9878-e107c84f17b4.dat']:
        path=server/relative;assert path.is_file();final_world.append((server.name+'/'+relative,path))
pack(out/'crash-fixture-final-after-second-recovery.zip',final_world)
for name in ['dual-platform-tests-fourth.json','candidate-fourth-identity.json','shipping-shape-fourth.json']:
    shutil.copy2(build/name,out/name)
for name in ['crash-disk-second.json','policy-negatives-first.json','crash-matrix-first.json']:
    shutil.copy2(logs/name,out/name)
for label in ['first','second']:
    images=out/('screenshots-'+label);images.mkdir()
    for phase in ['client-first','client-second']:
        for path in (logs/('ui-run-'+label)/phase/'screenshots').glob('*.png'):shutil.copy2(path,images/path.name)
manifest={path.relative_to(out).as_posix():{'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()} for path in out.rglob('*') if path.is_file()}
(out/'receipts-first.json').write_text(json.dumps(manifest,indent=2));print('Archived progress',len(manifest),'receipts; ordinary-placement gate still has remaining cases',flush=True)
