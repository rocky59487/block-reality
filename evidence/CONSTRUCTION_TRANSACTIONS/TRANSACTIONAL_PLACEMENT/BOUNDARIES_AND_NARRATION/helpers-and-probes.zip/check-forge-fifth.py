from pathlib import Path
import os, subprocess, sys, json, zipfile, hashlib, shutil

root=Path('C:/Users/wmc02/Desktop/block-reality');out=root/'build/transactional-placement'
staged=root/'build/native-v1.5-consumer/staged'
env=dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8',OPENBLAS_CORETYPE='Haswell',OPENBLAS_NUM_THREADS='1')
env['JAVA_HOME']='C:/Program Files/Eclipse Adoptium/jdk-17.0.18.8-hotspot';env['PATH']=env['JAVA_HOME']+'/bin;'+env['PATH']
env['BR_ENGINE']=str(staged/'windows-x86_64/bsi_tectonic.dll');env['BR_SIDECAR']=str(root/'dist/br-sidecar.exe')
command=['cmd','/c','gradlew.bat','--no-daemon','--console=plain','build','-PbrNativesDir='+str(staged)]
with (out/'forge-full-fifth.log').open('xb') as log:result=subprocess.run(command,cwd=root/'forge',env=env,stdout=log,stderr=subprocess.STDOUT)
(out/'forge-full-fifth-exit.json').write_text(json.dumps({'command':command,'exit':result.returncode,'source_snapshot':'source-candidate-fifth.zip'}))
shutil.copytree(root/'forge/build/test-results/test',out/'forge-full-fifth-xml')
print('Windows Forge full fifth',result.returncode,flush=True)
if result.returncode:sys.exit(result.returncode)
jar=out/'blockreality-candidate-fifth.jar';assert not jar.exists();shutil.copy2(root/'forge/build/libs/blockreality-0.4.0-dev.jar',jar)
with zipfile.ZipFile(out/'blockreality-candidate-fourth.jar') as before,zipfile.ZipFile(jar) as after:
    assert before.namelist()==after.namelist()
    changed=[name for name in before.namelist() if before.read(name)!=after.read(name)]
    assert sorted(changed)==['assets/blockreality/lang/en_us.json','assets/blockreality/lang/zh_tw.json','com/blockreality/impl/client/PlacementScreen.class'],changed
identity={'sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),'bytes':jar.stat().st_size,'only_changed_entries_from_fourth':changed,'native_and_all_other_entries_byte_identical':True}
(out/'candidate-fifth-identity.json').write_text(json.dumps(identity,indent=2));print(json.dumps(identity),flush=True)
