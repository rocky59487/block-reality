from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys, zipfile

root=Path('/home/rocky/br-transactional-placement');out=root/'qualification';build=root/'full-build-fourth'
win=Path('/mnt/c/Users/wmc02/Desktop/block-reality/build/transactional-placement')
assert (root/'OWNER').read_text().strip()=='block-reality-transactional-placement-qualification-v1'
assert not build.exists();build.mkdir()
with zipfile.ZipFile(win/'source-candidate-fourth.zip') as archive:
    manifest=json.loads(archive.read('__sha256.json'))
    for name,digest in manifest.items():
        data=archive.read(name);assert hashlib.sha256(data).hexdigest()==digest
        path=build/name;assert path.resolve().is_relative_to(build.resolve());path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
staged=Path('/home/rocky/br-native-v15-consumer/staged')
env=dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8',OPENBLAS_CORETYPE='Haswell',OPENBLAS_NUM_THREADS='1')
env['BR_ENGINE']=str(staged/'linux-x86_64/libbsi_tectonic.so');env['BR_SIDECAR']='/home/rocky/br-native-candidate-runtime/dist/br-sidecar'
assert Path(env['BR_ENGINE']).is_file() and Path(env['BR_SIDECAR']).is_file()
for phase,folder,tasks in [('core','mod',['check']),('forge','forge',['build','-PbrNativesDir='+str(staged)])]:
    command=['bash','gradlew','--no-daemon','--console=plain',*tasks]
    with (out/('linux-'+phase+'-full-fourth.log')).open('xb') as log:result=subprocess.run(command,cwd=build/folder,env=env,stdout=log,stderr=subprocess.STDOUT)
    (out/('linux-'+phase+'-full-fourth-exit.json')).write_text(json.dumps({'command':command,'exit':result.returncode,'source_snapshot':'source-candidate-fourth.zip'}))
    reports=build/('mod/core/build/test-results/test' if phase=='core' else 'forge/build/test-results/test')
    if reports.exists():shutil.copytree(reports,out/('linux-'+phase+'-full-fourth-xml'))
    print('Linux',phase,'full fourth',result.returncode,flush=True)
    if result.returncode:sys.exit(result.returncode)
jar=out/'blockreality-linux-full-fourth.jar';assert not jar.exists();shutil.copy2(build/'forge/build/libs/blockreality-0.4.0-dev.jar',jar)
(out/'linux-full-fourth-identity.json').write_text(json.dumps({'sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),'bytes':jar.stat().st_size,'source_archive_sha256':hashlib.sha256((win/'source-candidate-fourth.zip').read_bytes()).hexdigest()}))
