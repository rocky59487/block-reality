from pathlib import Path
import subprocess,os,sys,json,signal,socket,time,hashlib
root=Path('/home/rocky/br-transactional-placement');win=Path('/mnt/c/Users/wmc02/Desktop/block-reality/build/transactional-placement')
point=sys.argv[1];assert point in ['prepared','world-applied','player-applied','world-durable','player-durable','committed-temp','committed','published']
debug_port={'world-applied':25603,'prepared':25605,'player-applied':25607,'world-durable':25609,'player-durable':25611,'committed-temp':25613,'committed':25615,'published':25617}[point]
server=root/('installed-crash-'+point+'-first');assert server.resolve().is_relative_to(root.resolve()) and (server/'OWNER').read_text().strip()=='block-reality-placement-runtime-v1'
out=root/('qualification/crash-'+point+'-first');assert not out.exists();out.mkdir();(out/'OWNER').write_text('block-reality-placement-runtime-v1\n')
for port in [25602,debug_port]:
    with socket.socket() as check:check.bind(('127.0.0.1',port))
lines=json.loads((win/'crash-breakpoint-lines.json').read_text());key='journal' if point in ['prepared','committed-temp','committed'] else point
types={'journal':('com.blockreality.core.transaction.FileTransactionJournal','fault'),
       'world-applied':('com.blockreality.impl.server.construction.ConstructionService$Host','write'),
       'player-applied':('com.blockreality.impl.server.construction.LivePlayerInventory','apply'),
       'world-durable':('com.blockreality.impl.server.construction.ConstructionService$Host','persistCurrent'),
       'player-durable':('com.blockreality.impl.server.construction.PlayerInventoryParticipant','persist'),
       'published':('com.blockreality.impl.server.construction.ConstructionService$Host','publish')}
target_class,method=types[key]
(server/'user_jvm_args.txt').write_text('-Xms512m\n-Xmx2g\n-agentlib:jdwp=transport=dt_socket,server=y,suspend=y,address=127.0.0.1:'+str(debug_port)+'\n-Dbr.placementOutput='+str(out)+'\n-Dbr.placementServer='+str(server)+'\n-Dbr.placementMode=crash\n-Xlog:class+load=info:file='+str(out/'classload.log')+'\n')
env=dict(os.environ,OPENBLAS_CORETYPE='Haswell',OPENBLAS_NUM_THREADS='1');env.pop('BR_ENGINE',None);env.pop('BR_SIDECAR',None)
command=['java','--add-modules','jdk.jdi','-cp',str(win/'debugger/classes'),'PlacementCrashDebugger',str(debug_port),str(out),point,target_class,str(lines[key]['line']),method]
target=controller=None;receipt={'point':point,'debugger_command':command,'status':'FAIL'}
try:
    with (out/'server.log').open('xb') as server_log,(out/'debugger.log').open('xb') as debugger_log:
        target=subprocess.Popen(['bash','run.sh','nogui'],cwd=server,env=env,stdout=server_log,stderr=subprocess.STDOUT,start_new_session=True)
        controller=subprocess.Popen(command,env=env,stdout=debugger_log,stderr=subprocess.STDOUT,start_new_session=True)
        receipt.update(target_pid=target.pid,target_group=target.pid,controller_pid=controller.pid,cwd=str(server),timeout_seconds=210)
        (out/'process-owner.json').write_text(json.dumps(receipt,indent=2));print('Owned crash target',point,'PID',target.pid,'debugger',controller.pid,flush=True)
        deadline=time.monotonic()+210
        while time.monotonic()<deadline and not (out/'debugger-ready.json').exists():
            if controller.poll() is not None or target.poll() is not None:raise RuntimeError('Target/debugger exited before a captured suspended barrier')
            time.sleep(.1)
        assert (out/'debugger-ready.json').exists(),'Crash barrier deadline'
        ready=json.loads((out/'debugger-ready.json').read_text());assert ready['stage']==point and ready['class']==target_class and ready['suspendPolicy']==2
        assert target.poll() is None and controller.poll() is None,'Target must still be suspended under the live debugger'
        assert (out/'crash-observation.json').exists() and (server/'CRASH_EXPECTED.json').exists()
        os.killpg(target.pid,signal.SIGKILL);code=target.wait(timeout=20);debugger_code=controller.wait(timeout=20)
        assert code==-signal.SIGKILL and debugger_code==0,(code,debugger_code)
        observation=json.loads((out/'crash-observation.json').read_text())
        receipt.update(status='INTERRUPTED',exit=code,debugger_exit=debugger_code,ready=ready,checks=len(observation['checks']))
except BaseException as failure:
    receipt['failure']=repr(failure);raise
finally:
    for process in [target,controller]:
        if process is not None and process.poll() is None:
            os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=20)
    if target is not None:receipt['exit']=target.returncode
    if controller is not None:receipt['debugger_exit']=controller.returncode
    (out/'exit.json').write_text(json.dumps(receipt,indent=2))
    print('Crash',point,receipt['status'],'exit',receipt.get('exit'),flush=True)
