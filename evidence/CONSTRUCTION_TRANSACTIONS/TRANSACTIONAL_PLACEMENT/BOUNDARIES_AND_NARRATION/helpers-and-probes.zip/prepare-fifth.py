from pathlib import Path
import json, subprocess, zipfile, hashlib

root=Path('C:/Users/wmc02/Desktop/block-reality');out=root/'build/transactional-placement'
files=subprocess.check_output(['git','ls-files','-co','--exclude-standard'],cwd=root,text=True).splitlines();manifest={}
with zipfile.ZipFile(out/'source-candidate-fifth.zip','x',compression=zipfile.ZIP_DEFLATED) as archive:
    for name in files:
        if name.startswith(('forge/','mod/','gradle/','contract/','scripts/','third_party/')) or name in ['LICENSE','NOTICE','docs/CT_TRANSACTIONAL_PLACEMENT.md','.interface-design/system.md']:
            data=(root/name).read_bytes();archive.writestr(name,data);manifest[name]=hashlib.sha256(data).hexdigest()
    archive.writestr('__sha256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(out/'source-candidate-fourth.zip') as archive:
    old=json.loads(archive.read('__sha256.json'))
changed=sorted(name for name in manifest if manifest[name]!=old.get(name))
expected=['forge/src/main/java/com/blockreality/impl/client/PlacementScreen.java','forge/src/main/resources/assets/blockreality/lang/en_us.json','forge/src/main/resources/assets/blockreality/lang/zh_tw.json']
assert changed==expected,changed
(out/'core-full-fifth-reused.json').write_text(json.dumps({'changed_from_fourth':changed,'all_mod_files_byte_identical':True,'windows_core':'core-full-third','linux_core':'linux-core-full-fourth'},indent=2))
script=(out/'check-forge-fourth.py').read_text(encoding='utf-8')
script=script[:script.index('files=subprocess')]+script[script.index("staged=root/"):]
script=script.replace('fourth','fifth').replace('candidate-second.jar','candidate-fourth.jar').replace("assert changed==['com/blockreality/impl/client/PlacementScreen.class'],changed", "assert sorted(changed)==['assets/blockreality/lang/en_us.json','assets/blockreality/lang/zh_tw.json','com/blockreality/impl/client/PlacementScreen.class'],changed").replace('only_changed_entries_from_second','only_changed_entries_from_fourth')
with (out/'check-forge-fifth.py').open('x',encoding='utf-8',newline='\n') as f:f.write(script)
script=(out/'check-linux-full-fourth.py').read_text(encoding='utf-8').replace('fourth','fifth')
script=script.replace("[('core','mod',['check']),('forge','forge',['build','-PbrNativesDir='+str(staged)])]", "[('forge','forge',['build','-PbrNativesDir='+str(staged)])]")
with (out/'check-linux-full-fifth.py').open('x',encoding='utf-8',newline='\n') as f:f.write(script)
print('Fifth source frozen; only PlacementScreen and two translations changed')
