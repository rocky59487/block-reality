from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,zipfile
root=Path('/home/rocky/br-transactional-placement');out=root/'qualification';client=root/'ui-client-build-first';server=root/'ui-server-build-first'
win=Path('/mnt/c/Users/wmc02/Desktop/block-reality/build/transactional-placement')
assert json.loads((out/'ui-client-build-third-exit.json').read_text())['exit']==1
assert json.loads((out/'ui-server-build-third-exit.json').read_text())['exit']==0
probe=client/'placement-probe/java/com/blockreality/impl/client/PlacementUiProbe.java'
assert probe.read_bytes()==(out/'ui-client-probe-third.java').read_bytes()
shutil.copy2(win/'ui-client/PlacementUiProbe.java',probe);shutil.copy2(probe,out/'ui-client-probe-third-retry.java')
command=['bash','gradlew','--no-daemon','--console=plain','-I','../placement-probe.gradle','-Dbr.placementUiOutput='+str(out/'ui-run-third/client-first'),'-PbrNativesDir=/home/rocky/br-native-v15-consumer/staged','classes']
env=dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8');env.pop('BR_ENGINE',None);env.pop('BR_SIDECAR',None)
with (out/'ui-client-build-third-retry.log').open('xb') as log:r=subprocess.run(command,cwd=client/'forge',env=env,stdout=log,stderr=subprocess.STDOUT)
(out/'ui-client-build-third-retry-exit.json').write_text(json.dumps({'exit':r.returncode,'command':command}));print('UI third retry',r.returncode,flush=True)
if r.returncode:sys.exit(r.returncode)
jar=server/'build/libs/br-placement-ui-probe-1.0.jar';shutil.copy2(jar,out/'br-placement-ui-probe-third.jar')
with zipfile.ZipFile(jar) as archive:
    names=archive.namelist();assert 'META-INF/accesstransformer.cfg' not in names and all(n.startswith('com/blockreality/testplacementuiprobe/') for n in names if n.endswith('.class'))
(out/'ui-server-harness-third-identity.json').write_text(json.dumps({'sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),'bytes':jar.stat().st_size,'entries':names},indent=2))
