from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,zipfile

root=Path('/home/rocky/br-transactional-placement');out=root/'qualification'
win=Path('/mnt/c/Users/wmc02/Desktop/block-reality/build/transactional-placement')
client=root/'ui-client-build-first';server=root/'ui-server-build-first'
assert (root/'OWNER').read_text().strip()=='block-reality-transactional-placement-qualification-v1'
for name in ['client-first','client-second','server']:
    assert json.loads((out/'ui-run-second'/name/'exit.json').read_text())=={'exit':0,'cleanup_terminated_owned_group':False}
with zipfile.ZipFile(win/'source-candidate-fifth.zip') as archive:
    manifest=json.loads(archive.read('__sha256.json'));changed=[]
    for name,digest in manifest.items():
        if not name.startswith(('forge/src/main/','mod/')):continue
        data=archive.read(name);assert hashlib.sha256(data).hexdigest()==digest
        path=client/name
        if path.read_bytes()!=data:
            changed.append(name);saved=out/'ui-source-before-third'/name;saved.parent.mkdir(parents=True,exist_ok=True);saved.write_bytes(path.read_bytes());path.write_bytes(data)
    assert sorted(changed)==['forge/src/main/java/com/blockreality/impl/client/PlacementScreen.java','forge/src/main/resources/assets/blockreality/lang/en_us.json','forge/src/main/resources/assets/blockreality/lang/zh_tw.json'],changed
(out/'ui-client-shipping-source-fifth-identity.json').write_text(json.dumps(manifest,indent=2))
for old,new,label in [(client/'placement-probe/java/com/blockreality/impl/client/PlacementUiProbe.java',win/'ui-client/PlacementUiProbe.java','client'),(server/'src/main/java/com/blockreality/testplacementuiprobe/PlacementUiServerProbe.java',win/'ui-server/src/main/java/com/blockreality/testplacementuiprobe/PlacementUiServerProbe.java','server')]:
    (out/('ui-'+label+'-probe-before-third.java')).write_bytes(old.read_bytes());shutil.copy2(new,old);shutil.copy2(new,out/('ui-'+label+'-probe-third.java'))
init=client/'placement-probe.gradle';init.write_text(init.read_text().replace("p.file('run-placement-ui-second')","p.file('run-placement-ui-third')"))
profile=client/'forge/run-placement-ui-third';assert not profile.exists();profile.mkdir();(profile/'OWNER').write_text('block-reality-placement-ui-v1\n')
(profile/'options.txt').write_text('version:3465\nonboardAccessibility:false\npauseOnLostFocus:false\nguiScale:3\nrenderDistance:4\nsimulationDistance:3\nmaxFps:30\nenableVsync:false\nlang:en_us\nautoJump:false\n')
env=dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8');env.pop('BR_ENGINE',None);env.pop('BR_SIDECAR',None)
for label,cwd,tasks in [('server',server,['jar','reobfJar']),('client',client/'forge',['-I','../placement-probe.gradle','-Dbr.placementUiOutput='+str(out/'ui-run-third/client-first'),'-PbrNativesDir=/home/rocky/br-native-v15-consumer/staged','classes'])]:
    command=['bash','gradlew','--no-daemon','--console=plain',*tasks]
    with (out/('ui-'+label+'-build-third.log')).open('xb') as log:r=subprocess.run(command,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
    (out/('ui-'+label+'-build-third-exit.json')).write_text(json.dumps({'exit':r.returncode,'command':command}));print('UI third',label,r.returncode,flush=True)
    if r.returncode:sys.exit(r.returncode)
jar=server/'build/libs/br-placement-ui-probe-1.0.jar';shutil.copy2(jar,out/'br-placement-ui-probe-third.jar')
with zipfile.ZipFile(jar) as archive:
    names=archive.namelist();assert 'META-INF/accesstransformer.cfg' not in names and all(name.startswith('com/blockreality/testplacementuiprobe/') for name in names if name.endswith('.class'))
(out/'ui-server-harness-third-identity.json').write_text(json.dumps({'sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),'bytes':jar.stat().st_size,'entries':names},indent=2))
