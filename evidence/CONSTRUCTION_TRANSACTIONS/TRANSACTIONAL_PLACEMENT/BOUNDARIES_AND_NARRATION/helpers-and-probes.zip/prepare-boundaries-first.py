from pathlib import Path
import subprocess, sys

win = Path(__file__).resolve().parent
build = (win / 'rebuild-harness-sixth.py').read_text(encoding='utf-8')
build = build.replace('harness-source-fifth', 'harness-source-sixth').replace('sixth', 'seventh')
# Preserve the actual preceding source under its correct label.
build = build.replace('harness-source-seventh', 'harness-source-sixth')
setup = (win / 'setup-runtime-fixed.py').read_text(encoding='utf-8')
setup = setup.replace('installed-fixed', 'installed-boundaries-first').replace('candidate-second', 'candidate-fourth')
setup = setup.replace("assert json.loads((win/'forge-candidate-fourth-exit.json').read_text())['exit']==0", "assert json.loads((win/'forge-full-fourth-exit.json').read_text())['exit']==0")
setup = setup.replace('probe-fifth', 'probe-seventh').replace('harness-fifth', 'harness-seventh')
launch = (win / 'launch-runtime-fixed.py').read_text(encoding='utf-8')
launch = launch.replace("['control','restart']", "['boundaries']").replace('installed-fixed', 'installed-boundaries-first').replace('runtime-fixed-', 'runtime-boundaries-first-')
for name, content in [('rebuild-harness-seventh.py', build), ('setup-boundaries-first.py', setup), ('launch-boundaries-first.py', launch)]:
    path = win / name
    with path.open('x', encoding='utf-8', newline='\n') as f:
        f.write(content)
print('Prepared isolated harness seventh and first boundary launch scripts')
