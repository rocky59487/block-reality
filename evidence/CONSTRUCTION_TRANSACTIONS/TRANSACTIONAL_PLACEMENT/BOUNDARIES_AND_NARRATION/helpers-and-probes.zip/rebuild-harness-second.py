from pathlib import Path
import shutil,subprocess,os,json,sys,hashlib,zipfile
root=Path('/home/rocky/br-transactional-placement');out=root/'qualification';build=root/'harness-build'
assert (root/'OWNER').read_text().strip()=='block-reality-transactional-placement-qualification-v1'
before=out/'harness-source-first';assert not before.exists();shutil.copytree(build/'src',before)
shutil.copy2(Path('/mnt/c/Users/wmc02/Desktop/block-reality/build/transactional-placement/harness/src/main/java/com/blockreality/testplacementprobe/PlacementProbe.java'),build/'src/main/java/com/blockreality/testplacementprobe/PlacementProbe.java')
command=['bash','gradlew','--no-daemon','--console=plain','jar','reobfJar'];env=dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8')
with (out/'harness-second.log').open('xb') as log:r=subprocess.run(command,cwd=build,env=env,stdout=log,stderr=subprocess.STDOUT)
(out/'harness-second-exit.json').write_text(json.dumps({'exit':r.returncode,'command':command}));print('harness second',r.returncode,flush=True)
if r.returncode:sys.exit(r.returncode)
jar=build/'build/libs/br-placement-probe-1.0.jar';shutil.copy2(jar,out/'br-placement-probe-second.jar')
with zipfile.ZipFile(jar) as z:
    names=z.namelist();assert 'META-INF/accesstransformer.cfg' not in names and all(n.startswith('com/blockreality/testplacementprobe/') for n in names if n.endswith('.class'))
(out/'harness-second-identity.json').write_text(json.dumps({'sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),'bytes':jar.stat().st_size,'entries':names},indent=2))
