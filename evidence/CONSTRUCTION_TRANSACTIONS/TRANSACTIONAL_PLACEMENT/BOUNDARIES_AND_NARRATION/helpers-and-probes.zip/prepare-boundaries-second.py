from pathlib import Path
win=Path(__file__).resolve().parent
script=(win/'rebuild-harness-seventh.py').read_text(encoding='utf-8').replace('harness-source-sixth','harness-source-seventh').replace('seventh','eighth').replace('harness-source-eighth','harness-source-seventh')
setup=(win/'setup-boundaries-first.py').read_text(encoding='utf-8').replace('boundaries-first','boundaries-second').replace('seventh','eighth')
launch=(win/'launch-boundaries-first.py').read_text(encoding='utf-8').replace('boundaries-first','boundaries-second')
for name,content in [('rebuild-harness-eighth.py',script),('setup-boundaries-second.py',setup),('launch-boundaries-second.py',launch)]:
    with (win/name).open('x',encoding='utf-8',newline='\n') as f:f.write(content)
print('Second boundary run pins every capacity actor offer before and after logout')
