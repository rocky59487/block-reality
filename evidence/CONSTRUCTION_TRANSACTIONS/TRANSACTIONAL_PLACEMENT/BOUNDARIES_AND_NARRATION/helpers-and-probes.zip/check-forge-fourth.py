from pathlib import Path
import os, subprocess, sys, json, zipfile, hashlib, shutil

root=Path('C:/Users/wmc02/Desktop/block-reality');out=root/'build/transactional-placement'
files=subprocess.check_output(['git','ls-files','-co','--exclude-standard'],cwd=root,text=True).splitlines();manifest={}
with zipfile.ZipFile(out/'source-candidate-fourth.zip','x',compression=zipfile.ZIP_DEFLATED) as archive:
    for name in files:
        if name.startswith(('forge/','mod/','gradle/','contract/','scripts/','third_party/')) or name in ['LICENSE','NOTICE','docs/CT_TRANSACTIONAL_PLACEMENT.md','.interface-design/system.md']:
            data=(root/name).read_bytes();archive.writestr(name,data);manifest[name]=hashlib.sha256(data).hexdigest()
    archive.writestr('__sha256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(out/'source-candidate-third.zip') as before:
    prior=json.loads(before.read('__sha256.json'));changed=[name for name in manifest if manifest[name]!=prior.get(name)]
    assert changed==['forge/src/test/java/com/blockreality/impl/LangKeysTest.java'],changed
    assert json.loads((out/'core-full-third-exit.json').read_text())['exit']==0
(out/'core-full-fourth-reused.json').write_text(json.dumps({'exact_source_reused':'source-candidate-third.zip','full_results':'core-full-third-xml','all_mod_files_byte_identical':True,'only_source_change':changed}))
staged=root/'build/native-v1.5-consumer/staged'
env=dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8',OPENBLAS_CORETYPE='Haswell',OPENBLAS_NUM_THREADS='1')
env['JAVA_HOME']='C:/Program Files/Eclipse Adoptium/jdk-17.0.18.8-hotspot';env['PATH']=env['JAVA_HOME']+'/bin;'+env['PATH']
env['BR_ENGINE']=str(staged/'windows-x86_64/bsi_tectonic.dll');env['BR_SIDECAR']=str(root/'dist/br-sidecar.exe')
command=['cmd','/c','gradlew.bat','--no-daemon','--console=plain','build','-PbrNativesDir='+str(staged)]
with (out/'forge-full-fourth.log').open('xb') as log:result=subprocess.run(command,cwd=root/'forge',env=env,stdout=log,stderr=subprocess.STDOUT)
(out/'forge-full-fourth-exit.json').write_text(json.dumps({'command':command,'exit':result.returncode,'source_snapshot':'source-candidate-fourth.zip'}))
shutil.copytree(root/'forge/build/test-results/test',out/'forge-full-fourth-xml')
print('Windows Forge full fourth',result.returncode,flush=True)
if result.returncode:sys.exit(result.returncode)
jar=out/'blockreality-candidate-fourth.jar';assert not jar.exists();shutil.copy2(root/'forge/build/libs/blockreality-0.4.0-dev.jar',jar)
with zipfile.ZipFile(out/'blockreality-candidate-second.jar') as before,zipfile.ZipFile(jar) as after:
    assert before.namelist()==after.namelist()
    changed=[name for name in before.namelist() if before.read(name)!=after.read(name)]
    assert changed==['com/blockreality/impl/client/PlacementScreen.class'],changed
identity={'sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),'bytes':jar.stat().st_size,'only_changed_entries_from_second':changed,'native_and_all_other_entries_byte_identical':True}
(out/'candidate-fourth-identity.json').write_text(json.dumps(identity,indent=2));print(json.dumps(identity),flush=True)
