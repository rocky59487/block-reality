from pathlib import Path
import json, subprocess, sys

root = Path('/home/rocky/br-transactional-placement')
win = Path('/mnt/c/Users/wmc02/Desktop/block-reality/build/transactional-placement')
out = root / 'qualification'; results = []
assert len(json.loads((out / 'policy-mutants-first.json').read_text())) == 4
guards = {
    'debit-two': 'COMMITTED world and material at correct barrier',
    'lose-tag': 'all inventory fields preserved around one-item debit',
    'replay-debit': 'replay 1 changes no items journal identity revision or publication',
    'ignore-protection': 'EntityPlace cancellation produces durable ABORTED: COMMITTED',
}
for label, guard in guards.items():
    stem = 'policy-' + label + '-first'
    setup = (win / 'setup-runtime-fixed.py').read_text().replace('installed-fixed', 'installed-' + stem)
    setup = setup.replace("candidate=win/'blockreality-candidate-second.jar'", "candidate=root/'qualification/blockreality-" + stem + ".jar'")
    setup = setup.replace("win/'candidate-second-identity.json'", "root/'qualification/" + stem + "-identity.json'")
    setup = setup.replace('br-placement-probe-fifth.jar', 'br-placement-probe-sixth.jar').replace('harness-fifth-identity.json', 'harness-sixth-identity.json')
    launch = (win / 'launch-runtime-fixed.py').read_text().replace('installed-fixed', 'installed-' + stem).replace('runtime-fixed-', 'runtime-' + stem + '-')
    # Preserve the probe's FAIL and normal server exit; only the outer driver decides
    # whether the intended behavioral assertion (rather than loading) caught it.
    for kind, content in [('setup', setup), ('launch', launch)]:
        path = out / (kind + '-' + stem + '.py'); assert not path.exists(); path.write_text(content)
    setup_result = subprocess.run(['python3', str(out / ('setup-' + stem + '.py'))])
    if setup_result.returncode: sys.exit(setup_result.returncode)
    command = ['python3', str(out / ('launch-' + stem + '.py')), 'control']
    with (out / ('driver-' + stem + '.log')).open('xb') as log:
        run = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    case = out / ('runtime-' + stem + '-control')
    report = json.loads((case / 'result.json').read_text())
    server_exit = json.loads((case / 'exit.json').read_text())
    observer = (case / 'observer-failure.txt').read_text() if (case / 'observer-failure.txt').exists() else ''
    trace = observer if label == 'debit-two' else report.get('trace', '')
    passed = run.returncode == 1 and server_exit == {'exit': 0, 'timeout': False} and report['status'] == 'FAIL' and guard in trace
    receipt = {'expected_behavioral_failure': passed, 'probe_status': report['status'], 'completed_checks': len(report['checks']),
               'guard': guard, 'driver_exit': run.returncode, 'server_exit': server_exit,
               'ordinary_class_origins': report['checks'][1:5], 'source_jar': 'blockreality-' + stem + '.jar'}
    (case / 'negative-qualified.json').write_text(json.dumps(receipt, indent=2)); results.append(receipt)
    print(label, 'intended behavioral failure qualified', passed, flush=True)
    if not passed:
        print(report.get('trace', '') + '\n' + observer, flush=True); sys.exit(1)
(out / 'policy-negatives-first.json').write_text(json.dumps(results, indent=2))
