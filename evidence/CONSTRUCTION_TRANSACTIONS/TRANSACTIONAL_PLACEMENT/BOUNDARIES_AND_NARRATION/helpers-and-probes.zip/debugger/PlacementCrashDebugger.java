import com.sun.jdi.*;
import com.sun.jdi.connect.*;
import com.sun.jdi.event.*;
import com.sun.jdi.request.*;
import java.nio.file.*;
import java.time.Duration;
import java.util.*;

/** Test controller only: stop an ordinary jar at an observed barrier, capture, then wait for its owner's SIGKILL. */
public final class PlacementCrashDebugger {
    public static void main(String[] args)throws Exception {
        int port=Integer.parseInt(args[0]),line=Integer.parseInt(args[4]);
        Path output=Path.of(args[1]);String stage=args[2],className=args[3],methodName=args[5];
        if(!Set.of("prepared","world-applied","player-applied","world-durable","player-durable","committed-temp","committed","published").contains(stage))throw new IllegalArgumentException("Unknown stage");
        AttachingConnector connector=Bootstrap.virtualMachineManager().attachingConnectors().stream()
                .filter(c->c.name().equals("com.sun.jdi.SocketAttach")).findFirst().orElseThrow();
        VirtualMachine vm=null;long deadline=System.nanoTime()+Duration.ofSeconds(60).toNanos();
        while(vm==null && System.nanoTime()<deadline) {
            var options=connector.defaultArguments();options.get("hostname").setValue("127.0.0.1");options.get("port").setValue(Integer.toString(port));options.get("timeout").setValue("2000");
            try{vm=connector.attach(options);}catch(java.io.IOException waiting){Thread.sleep(200);}
        }
        if(vm==null)throw new IllegalStateException("Owned target did not expose its debugger endpoint");
        System.out.println("Attached to "+vm.name()+" "+vm.version());
        EventRequestManager requests=vm.eventRequestManager();
        ClassPrepareRequest prepare=requests.createClassPrepareRequest();prepare.addClassFilter(className);prepare.setSuspendPolicy(EventRequest.SUSPEND_ALL);prepare.enable();
        for(ReferenceType type:vm.classesByName(className))install(requests,type,line,methodName);
        vm.resume();deadline=System.nanoTime()+Duration.ofSeconds(150).toNanos();
        boolean ready=false;
        while(System.nanoTime()<deadline) {
            EventSet events;
            try{events=vm.eventQueue().remove(1000);}catch(VMDisconnectedException done){if(ready)return;throw done;}
            if(events==null)continue;
            for(Event event:events) {
                if(event instanceof VMDisconnectEvent || event instanceof VMDeathEvent) {
                    if(ready)return;throw new IllegalStateException("Target exited before its observed barrier");
                }
                if(event instanceof ClassPrepareEvent prepared)install(requests,prepared.referenceType(),line,methodName);
                if(event instanceof BreakpointEvent breakpoint && !ready && selected(stage,breakpoint.thread())) {
                    Location location=breakpoint.location();
                    String receipt="{\"stage\":\""+stage+"\",\"class\":\""+location.declaringType().name()+"\",\"method\":\""+location.method().name()
                            +"\",\"line\":"+location.lineNumber()+",\"bci\":"+location.codeIndex()+",\"suspendPolicy\":"+events.suspendPolicy()+"}";
                    System.out.println("Matched "+receipt);
                    requests.deleteEventRequests(new ArrayList<>(requests.breakpointRequests()));
                    requests.deleteEventRequests(new ArrayList<>(requests.classPrepareRequests()));
                    ReferenceType probe=vm.classesByName("com.blockreality.testplacementprobe.PlacementProbe").stream().findFirst().orElseThrow();
                    ObjectReference instance=(ObjectReference)probe.getValue(probe.fieldByName("instance"));
                    Method capture=probe.methodsByName("captureCrash").stream().findFirst().orElseThrow();
                    try {instance.invokeMethod(breakpoint.thread(),capture,List.of(vm.mirrorOf(stage)),ObjectReference.INVOKE_SINGLE_THREADED);}
                    catch(InvocationException failure) {
                        ObjectReference exception=failure.exception();
                        Field detail=exception.referenceType().allFields().stream().filter(f->f.name().equals("detailMessage") && f.declaringType().name().equals("java.lang.Throwable")).findFirst().orElseThrow();
                        System.err.println("Capture threw "+exception.referenceType().name()+": "+exception.getValue(detail));throw failure;
                    }
                    if(!breakpoint.thread().isSuspended() || events.suspendPolicy()!=EventRequest.SUSPEND_ALL)
                        throw new IllegalStateException("Target must remain suspended until its owner kills it");
                    Files.writeString(output.resolve("debugger-ready.json"),receipt,StandardOpenOption.CREATE_NEW);
                    ready=true;deadline=System.nanoTime()+Duration.ofSeconds(30).toNanos();
                }
            }
            if(!ready)events.resume(); // Never resume a captured target or detach before its owner has killed it.
        }
        throw new IllegalStateException(ready?"Owner did not kill the captured target":"Requested crash barrier was not reached");
    }
    private static void install(EventRequestManager requests,ReferenceType type,int line,String method)throws Exception {
        List<Location> locations=type.locationsOfLine(line).stream().filter(l->l.method().name().equals(method)).toList();
        if(locations.size()!=1)throw new IllegalStateException("Expected one exact line location: "+type.name()+" "+line+" "+locations);
        BreakpointRequest request=requests.createBreakpointRequest(locations.get(0));request.setSuspendPolicy(EventRequest.SUSPEND_ALL);request.enable();
        System.out.println("Breakpoint "+locations.get(0)+" bci="+locations.get(0).codeIndex());
    }
    private static boolean selected(String stage,ThreadReference thread)throws Exception {
        if(!thread.name().equals("Server thread"))return false;
        List<StackFrame> frames=thread.frames();
        if(stage.equals("world-durable") && !onStack(frames,"com.blockreality.impl.server.construction.ConstructionService$Host","flush"))return false;
        if(stage.equals("player-durable") && !onStack(frames,"com.blockreality.impl.server.construction.PlayerInventoryParticipant","flush"))return false;
        if(Set.of("prepared","committed-temp","committed").contains(stage)) {
            List<Value> args=frames.get(0).getArgumentValues();
            if(args.get(1)==null)return false;
            String point=enumName((ObjectReference)args.get(0));ObjectReference entry=(ObjectReference)args.get(1);
            String phase=enumName((ObjectReference)entry.getValue(entry.referenceType().fieldByName("phase")));
            return point.equals(stage.equals("committed-temp")?"TEMP_FORCED":"DIRECTORY_FORCED") && phase.equals(stage.equals("prepared")?"PREPARED":"COMMITTED");
        }
        return onStack(frames,"com.blockreality.core.transaction.AtomicConstructionCoordinator","execute");
    }
    private static String enumName(ObjectReference value) {
        Field name=value.referenceType().allFields().stream().filter(f->f.name().equals("name") && f.declaringType().name().equals("java.lang.Enum")).findFirst().orElseThrow();
        return ((StringReference)value.getValue(name)).value();
    }
    private static boolean onStack(List<StackFrame> frames,String type,String method) {
        return frames.stream().anyMatch(f->f.location().declaringType().name().equals(type) && f.location().method().name().equals(method));
    }
}
