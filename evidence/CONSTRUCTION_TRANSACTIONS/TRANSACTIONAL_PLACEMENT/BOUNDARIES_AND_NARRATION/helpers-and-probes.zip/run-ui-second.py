from pathlib import Path
import base64, hashlib, json, os, shutil, signal, socket, struct, subprocess, time, traceback

root = Path('/home/rocky/br-transactional-placement'); qualification = root / 'qualification'
win = Path('/mnt/c/Users/wmc02/Desktop/block-reality/build/transactional-placement')
run = qualification / 'ui-run-second'; server = root / 'installed-ui-second'
client_build = root / 'ui-client-build-first'; profile = client_build / 'forge/run-placement-ui-second'
assert (root / 'OWNER').read_text().strip() == 'block-reality-transactional-placement-qualification-v1'
assert not run.exists() and not server.exists()
assert json.loads((qualification / 'ui-client-build-second-exit.json').read_text())['exit'] == 0
with socket.socket() as check: check.bind(('127.0.0.1', 25630))
run.mkdir(); server.mkdir(); server_output = run / 'server'; server_output.mkdir()
for directory in [run, server, server_output]: (directory / 'OWNER').write_text('block-reality-placement-ui-v1\n')
source = Path('/home/rocky/br-native-v15-consumer/installed-server')
shutil.copytree(source / 'libraries', server / 'libraries')
for name in ['run.sh', 'run.bat', 'eula.txt']: shutil.copy2(source / name, server / name)
(server / 'mods').mkdir()
ordinary = win / 'blockreality-candidate-fourth.jar'
assert hashlib.sha256(ordinary.read_bytes()).hexdigest() == json.loads((win / 'candidate-fourth-identity.json').read_text())['sha256']
shutil.copy2(ordinary, server / 'mods/blockreality-0.4.0-dev.jar')
shutil.copy2(qualification / 'br-placement-ui-probe-first.jar', server / 'mods/br-placement-ui-probe.jar')
(server / 'server.properties').write_text('server-ip=127.0.0.1\nserver-port=25630\nonline-mode=false\nenable-rcon=false\nenable-query=false\nlevel-name=placement-ui\nlevel-type=minecraft:flat\ngenerate-structures=false\nspawn-protection=0\nview-distance=3\nsimulation-distance=3\nmax-players=1\nmax-tick-time=180000\n')
(server / 'user_jvm_args.txt').write_text('-Xms512m\n-Xmx2g\n-Dbr.placementUiOutput=' + str(server_output) + '\n')
env = dict(os.environ, OPENBLAS_CORETYPE='Haswell', OPENBLAS_NUM_THREADS='1'); env.pop('BR_ENGINE', None); env.pop('BR_SIDECAR', None)
processes = []; checks = []; ids = {}; receipts = []; start = time.monotonic()


def require(condition, label):
    if not condition: raise AssertionError(label)
    checks.append(label)


def launch(command, cwd, output, environment):
    log = (output / 'process.log').open('xb')
    process = subprocess.Popen(command, cwd=cwd, env=environment, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    processes.append((process, log, output))
    (output / 'process-owner.json').write_text(json.dumps({'pid': process.pid, 'process_group': process.pid, 'cwd': str(cwd), 'command': command}))
    return process


def wait_state(output, predicate=lambda value: True, timeout=35):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if (output / 'fatal.txt').exists(): raise AssertionError((output / 'fatal.txt').read_text())
        file = output / 'state.json'
        if file.exists():
            value = json.loads(file.read_text())
            if predicate(value): return value
        time.sleep(.1)
    raise TimeoutError(str(output) + ' last state: ' + ((output / 'state.json').read_text()[-6000:] if (output / 'state.json').exists() else 'missing'))


def command(output, action, name, **values):
    key = str(output); ids[key] = ids.get(key, 0) + 1
    payload = dict(id=ids[key], action=action, name=name, **values)
    (output / 'control.next').write_text(json.dumps(payload)); (output / 'control.next').replace(output / 'control.json')
    deadline = time.monotonic() + 75
    while not (output / (name + '.json')).exists():
        if (output / 'fatal.txt').exists(): raise AssertionError((output / 'fatal.txt').read_text())
        if time.monotonic() > deadline: raise TimeoutError('Command ' + name)
        time.sleep(.1)
    receipt = json.loads((output / (name + '.json')).read_text()); receipts.append(str(output / (name + '.json')))
    return receipt


def server_state(): return command(server_output, 'inspect', 'inspect-' + str(ids.get(str(server_output), 0) + 1))['after']


def start_client(label):
    output = run / label; output.mkdir(); (output / 'OWNER').write_text('block-reality-placement-ui-v1\n')
    tools = Path('/home/rocky/br-render-tools'); environment = dict(env)
    environment.update(PATH=str(tools / 'root/usr/bin') + ':' + env['PATH'], LD_LIBRARY_PATH=str(tools / 'root/usr/lib/x86_64-linux-gnu'), LIBGL_ALWAYS_SOFTWARE='1', LP_NUM_THREADS='4')
    cmd = [str(tools / 'root/usr/bin/xvfb-run'), '-a', '-e', str(output / 'xvfb.log'), '-s', '-screen 0 1920x1080x24 -nolisten tcp -fp ' + str(tools / 'root/usr/share/fonts/X11/misc'),
           'bash', 'gradlew', '--no-daemon', '--console=plain', '-I', '../placement-probe.gradle', '-Dbr.placementUiOutput=' + str(output), '-PbrNativesDir=/home/rocky/br-native-v15-consumer/staged', 'runClient']
    process = launch(cmd, client_build / 'forge', output, environment)
    wait_state(output, lambda s: s['connected'] and s['screen'] == 'none', 240)
    wait_state(server_output, lambda s: s['connected'])
    return output, process


def prepare(client, x, **settings):
    command(server_output, 'prepare', 'prepare-' + str(x), x=x, **settings)
    wait_state(client, lambda s: s.get('heldCount') == 8 and abs(s.get('position', [0])[0] - x - .5) < .01 and s['screen'] == 'none')
    command(client, 'aim', 'aim-' + str(x), x=x, y=81.5 if settings.get('chest') else 81)
    command(client, 'interact', 'interact-' + str(x))
    if not settings.get('chest'):
        state = wait_state(client, lambda s: s.get('session', {}).get('status') == 'READY' and not s['session']['waiting'])
        require(state['session']['target'] == [x, 81, 1026], 'real crosshair preview authors target ' + str(x))
        return state


def button(client, index, name): command(client, 'button', name, index=index)


def capture(client, name, language='en_us', small=True):
    image = command(client, 'capture', name, language=language, width=1280 if small else 1920, height=720 if small else 1080, scale=3 if small else 1)
    require(image['actual']['language'] == language, 'actual screenshot language ' + name)
    return image['actual']


def closed(client, name):
    command(client, 'key', name, key=256); wait_state(client, lambda s: s['screen'] == 'none')


def confirmation_frames(state): return [f['base64'] for f in state['frames'] if f['direction'] == 'C2S' and f['discriminator'] == 1]


def pending_count():
    data = (profile / 'blockreality/construction/pending.bin').read_bytes()
    require(len(data) >= 40 and hashlib.sha256(data[:-32]).digest() == data[-32:], 'outbox raw digest valid')
    require(data[:4] == b'BRP1', 'outbox raw schema')
    return struct.unpack('>I', data[4:8])[0]


try:
    server_process = launch(['bash', 'run.sh', 'nogui'], server, server_output, env)
    wait_state(server_output, timeout=180)
    client, client_process = start_client('client-first')
    ready = prepare(client, 1026)
    baseline = server_state()
    require(baseline['order'] == 0 and baseline['heldCount'] == 8 and 'minecraft:air' in baseline['cells']['1026'], 'preview changes no material/world/identity')
    large = capture(client, 'ready-en-large', small=False)
    require(large['session']['status'] == 'READY' and large['session']['ghost'], 'large English actual ready ghost')
    require(large['buttons'][-1]['y'] + large['buttons'][-1]['height'] < large['guiHeight'] / 2, 'large GUI panel follows its compact content')
    for axis, name in [(0, 'x'), (2, 'z'), (1, 'y')]:
        button(client, axis, 'axis-' + name)
        selected = wait_state(client, lambda s: s.get('session', {}).get('status') == 'READY' and s['session'].get('axis') == axis and not s['session']['waiting'])
        require(selected['session']['ghost'], 'real socket axis ' + name + ' ghost')
        if axis == 0: require(capture(client, 'ready-en-small')['session']['status'] == 'READY', 'small English ready panel')
        if axis == 1: require(capture(client, 'ready-zh-small', 'zh_tw')['session']['status'] == 'READY', 'small Chinese ready panel')
    closed(client, 'cancel-preview')
    after_cancel = server_state()
    require(all(after_cancel[k] == baseline[k] for k in ['inventory', 'order', 'ownedCells', 'journal', 'cells']), 'Escape preview has no world/material/history effect')
    require(not confirmation_frames(wait_state(client)), 'cancel sends no confirmation')
    command(client, 'interact', 'reopen-survival')
    wait_state(client, lambda s: s.get('session', {}).get('status') == 'READY' and not s['session']['waiting'])
    command(client, 'key', 'tab-to-cancel', key=258)
    keyboard = command(client, 'inspect', 'inspect-keyboard-cancel')['after']
    require(keyboard['buttons'][-1]['focused'], 'native Tab moves focus to cancel')
    command(client, 'key', 'enter-cancels', key=257); wait_state(client, lambda s: s['screen'] == 'none')
    keyboard_cancel = server_state()
    require(all(keyboard_cancel[k] == after_cancel[k] for k in ['inventory', 'order', 'journal', 'cells']), 'native Enter on cancel leaves construction unchanged')
    command(client, 'interact', 'reopen-keyboard-confirm')
    wait_state(client, lambda s: s.get('session', {}).get('status') == 'READY' and not s['session']['waiting'])
    command(client, 'key', 'enter-confirms', key=257)
    committed = wait_state(client, lambda s: s.get('session', {}).get('terminal') and s['session']['status'] == 'COMMITTED' and s['heldCount'] == 7)
    require(not committed['buttons'][-2]['visible'] and committed['buttons'][-1]['focused'], 'terminal receipt hides retry and moves keyboard focus to Done')
    after = server_state()
    require(after['order'] == 1 and after['ownedCells'] == 1 and after['heldCount'] == 7 and 'steel_beam' in after['cells']['1026'] and 'axis:"y"' in after['cells']['1026'], 'socket survival consumes one and commits declared Y cell')
    require(not committed['session']['ghost'] and pending_count() == 0, 'terminal success clears ghost and exact outbox')
    capture(client, 'committed-zh-small', 'zh_tw'); closed(client, 'close-committed')
    prepare(client, 1028, creative=True); button(client, 3, 'confirm-creative')
    wait_state(client, lambda s: s.get('session', {}).get('terminal') and s['session']['status'] == 'COMMITTED')
    creative = server_state(); require(creative['heldCount'] == 8 and creative['order'] == 2 and creative['ownedCells'] == 2, 'socket creative commits with no debit'); closed(client, 'close-creative')
    prepare(client, 1030); command(server_output, 'cancel-next', 'protect-next'); button(client, 3, 'confirm-protected')
    wait_state(client, lambda s: s.get('session', {}).get('terminal') and s['session']['status'] == 'ABORTED')
    protected = server_state(); require(protected['heldCount'] == 8 and protected['order'] == 2 and 'minecraft:air' in protected['cells']['1030'], 'actual protection refusal restores world and items')
    capture(client, 'refused-zh-small', 'zh_tw'); closed(client, 'close-refused')
    before_frames = len(wait_state(client)['frames']); prepare(client, 1032, chest=True)
    wait_state(client, lambda s: s['screen'] == 'ContainerScreen')
    container = server_state(); require(container['menu'] == 'ChestMenu' and container['order'] == 2, 'vanilla chest has interaction priority')
    require(len(wait_state(client)['frames']) == before_frames, 'chest sends no construction channel request'); closed(client, 'close-chest')
    prepare(client, 1034); command(client, 'drop-outcome', 'arm-lost-response'); button(client, 3, 'confirm-lost-response')
    pending = wait_state(client, lambda s: s.get('session', {}).get('localError') == 'br.build.unresolved' and not s['session']['waiting'] and s['heldCount'] == 7)
    lost_server = server_state(); require(lost_server['order'] == 3 and lost_server['heldCount'] == 7, 'server committed despite one dropped actual outcome')
    require(sum(f['dropped'] for f in pending['frames']) == 1 and pending_count() == 1, 'one recorded actual outcome dropped; durable retry retained')
    pending_id = pending['session']['request']; pending_wire = confirmation_frames(pending)[-1]
    capture(client, 'pending-zh-small', 'zh_tw'); command(client, 'key', 'pending-page-down', key=267); capture(client, 'pending-scrolled-zh-small', 'zh_tw')
    closed(client, 'close-pending'); require(pending_count() == 1, 'closing unresolved request retains exact outbox')
    shutil.copy2(profile / 'blockreality/construction/pending.bin', run / 'pending-before-client-restart.bin')
    command(client, 'exit', 'exit-client-first'); require(client_process.wait(timeout=120) == 0, 'first actual client exits normally')
    wait_state(server_output, lambda s: not s['connected'])
    client2, client2_process = start_client('client-second')
    require(pending_count() == 1, 'client JVM restart retained pending record')
    command(client2, 'aim', 'aim-retry-new-target', x=1036); command(client2, 'interact', 'reopen-pending')
    restored = wait_state(client2, lambda s: s.get('session', {}).get('request') == pending_id and s['screen'] == 'PlacementScreen')
    require(restored['session']['target'] == [1034, 81, 1026] and not restored['session']['ghost'], 'restored pending keeps original binding over new cursor target')
    replay_before = server_state(); button(client2, 3, 'retry-original')
    replay = wait_state(client2, lambda s: s.get('session', {}).get('terminal') and s['session']['status'] == 'COMMITTED')
    replay_after = server_state()
    require(confirmation_frames(replay) == [pending_wire], 'actual socket retry sends byte-identical confirmation after JVM restart')
    require(all(replay_before[k] == replay_after[k] for k in ['inventory', 'order', 'ownedCells', 'journal', 'cells']), 'retry creates no new debit/world/identity/history')
    require(pending_count() == 0 and replay['heldCount'] == 7, 'recovered receipt clears exact pending record once')
    capture(client2, 'retry-committed-en-large', small=False); command(client2, 'exit', 'exit-client-second')
    require(client2_process.wait(timeout=120) == 0, 'second actual client exits normally')
    command(server_output, 'exit', 'exit-server'); require(server_process.wait(timeout=120) == 0, 'installed server exits normally')
    (run / 'result.json').write_text(json.dumps({'status': 'PASS', 'checks': checks, 'receipts': receipts, 'elapsed_seconds': time.monotonic() - start, 'client_scope': 'Linux dev client exact shipping sources plus test-only probe, llvmpipe, synthetic account; installed ordinary server jar', 'server_jar_sha256': hashlib.sha256(ordinary.read_bytes()).hexdigest()}, indent=2))
    print('Actual placement UI/socket PASS', len(checks), flush=True)
except BaseException:
    (run / 'first-failure.txt').write_text(traceback.format_exc())
    (run / 'result.json').write_text(json.dumps({'status': 'FAIL', 'checks': checks, 'receipts': receipts, 'elapsed_seconds': time.monotonic() - start}, indent=2))
    raise
finally:
    for process, log, output in reversed(processes):
        terminated = process.poll() is None
        if terminated:
            os.killpg(process.pid, signal.SIGTERM)
            try: process.wait(timeout=20)
            except subprocess.TimeoutExpired: os.killpg(process.pid, signal.SIGKILL); process.wait()
        log.close(); (output / 'exit.json').write_text(json.dumps({'exit': process.returncode, 'cleanup_terminated_owned_group': terminated}))
