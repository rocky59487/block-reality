from pathlib import Path
import copy, hashlib, json, os, shutil, subprocess, sys, zipfile

root = Path('/home/rocky/br-transactional-placement')
win = Path('/mnt/c/Users/wmc02/Desktop/block-reality/build/transactional-placement')
out = root / 'qualification'; build = root / 'policy-mutant-build-first'
assert (root / 'OWNER').read_text().strip() == 'block-reality-transactional-placement-qualification-v1'
assert not build.exists(); build.mkdir()
with zipfile.ZipFile(win / 'source-candidate-second.zip') as source:
    manifest = json.loads(source.read('__sha256.json'))
    for name, digest in manifest.items():
        data = source.read(name); assert hashlib.sha256(data).hexdigest() == digest
        path = build / name; path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(data)

prefix = 'forge/src/main/java/com/blockreality/impl/server/construction/'
originals = {name: (build / (prefix + name + '.java')).read_text() for name in ['LivePlayerInventory', 'ConstructionService']}
specs = [
    ('debit-two', 'LivePlayerInventory', 'source.getCount()-1', 'source.getCount()-2', 'LivePlayerInventory.class'),
    ('lose-tag', 'LivePlayerInventory', 'tag.putByte("Count",(byte)(source.getCount()-1));',
     'tag.putByte("Count",(byte)(source.getCount()-1)); tag.remove("tag");', 'LivePlayerInventory.class'),
    ('replay-debit', 'ConstructionService', 'return outcome(confirmation,previous.get().receipt());',
     'actor.getMainHandItem().shrink(1); return outcome(confirmation,previous.get().receipt());', 'ConstructionService.class'),
    ('ignore-protection', 'ConstructionService', 'if (net.minecraftforge.event.ForgeEventFactory.onBlockPlace(actor,snapshot,placement.face()))',
     'if (net.minecraftforge.event.ForgeEventFactory.onBlockPlace(actor,snapshot,placement.face()) && false)', 'ConstructionService$Host.class'),
]
env = dict(os.environ, PYTHONUTF8='1', PYTHONIOENCODING='utf-8')
env.pop('BR_ENGINE', None); env.pop('BR_SIDECAR', None)
results = []
for label, unit, old, new, class_name in specs:
    for name, source in originals.items(): (build / (prefix + name + '.java')).write_text(source)
    source = originals[unit]; assert source.count(old) == 1
    changed = source.replace(old, new); (build / (prefix + unit + '.java')).write_text(changed)
    (out / ('policy-' + label + '-source.java')).write_text(changed)
    command = ['bash', 'gradlew', '--no-daemon', '--console=plain', '-PbrNativesDir=/home/rocky/br-native-v15-consumer/staged', 'jar', 'reobfJar']
    with (out / ('policy-' + label + '-build-first.log')).open('xb') as log:
        result = subprocess.run(command, cwd=build / 'forge', env=env, stdout=log, stderr=subprocess.STDOUT)
    (out / ('policy-' + label + '-build-first-exit.json')).write_text(json.dumps({'exit': result.returncode, 'command': command}))
    print(label, 'compile', result.returncode, flush=True)
    if result.returncode: sys.exit(result.returncode)
    target = 'com/blockreality/impl/server/construction/' + class_name
    output = out / ('blockreality-policy-' + label + '-first.jar')
    with zipfile.ZipFile(build / 'forge/build/libs/blockreality-0.4.0-dev.jar') as compiled, zipfile.ZipFile(win / 'blockreality-candidate-second.jar') as ordinary:
        replacement = compiled.read(target); assert replacement != ordinary.read(target)
        with zipfile.ZipFile(output, 'x') as mutant:
            for entry in ordinary.infolist():
                mutant.writestr(copy.copy(entry), replacement if entry.filename == target else ordinary.read(entry.filename))
        with zipfile.ZipFile(output) as mutant:
            assert mutant.namelist() == ordinary.namelist()
            assert [name for name in ordinary.namelist() if ordinary.read(name) != mutant.read(name)] == [target]
    identity = {'sha256': hashlib.sha256(output.read_bytes()).hexdigest(), 'bytes': output.stat().st_size,
                'only_changed_entry': target, 'source_file': prefix + unit + '.java', 'before': old, 'after': new,
                'mutated_source_sha256': hashlib.sha256(changed.encode()).hexdigest(), 'compiler_exit': 0,
                'unchanged_remainder': 'blockreality-candidate-second.jar'}
    (out / ('policy-' + label + '-first-identity.json')).write_text(json.dumps(identity, indent=2))
    results.append(identity)
(out / 'policy-mutants-first.json').write_text(json.dumps(results, indent=2))
