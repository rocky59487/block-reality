from pathlib import Path
import zipfile,hashlib,json,copy
root=Path('C:/Users/wmc02/Desktop/block-reality/build/transactional-placement')
name='com/blockreality/impl/server/StructureManager.class';source='forge/src/main/java/com/blockreality/impl/server/StructureManager.java'
with zipfile.ZipFile(root/'source-candidate-first.zip') as first,zipfile.ZipFile(root/'source-candidate-second.zip') as second:
    old=first.read(source).decode().splitlines();new=second.read(source).decode().splitlines()
    assert [line for line in new if 'if (ConstructionService.alreadyAnnouncedNeighbor(e)) return;' not in line]==old
with zipfile.ZipFile(root/'blockreality-candidate-first.jar') as first,zipfile.ZipFile(root/'blockreality-candidate-second.jar') as candidate:
    output=root/'blockreality-neighbor-guard-omitted-second.jar';assert not output.exists()
    with zipfile.ZipFile(output,'w') as mutant:
        for entry in candidate.infolist():mutant.writestr(copy.copy(entry),first.read(name) if entry.filename==name else candidate.read(entry.filename))
    with zipfile.ZipFile(output) as mutant:
        assert mutant.namelist()==candidate.namelist()
        changed=[entry for entry in candidate.namelist() if candidate.read(entry)!=mutant.read(entry)]
        assert changed==[name]
    identity={'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'bytes':output.stat().st_size,
        'compiled_negative':'Omit the already-announced root neighbor guard from StructureManager.onNeighbourChange',
        'compiled_class_source':'source-candidate-first.zip','unchanged_remainder':'blockreality-candidate-second.jar',
        'only_changed_entry':name,'candidate_class_sha256':hashlib.sha256(candidate.read(name)).hexdigest(),
        'negative_class_sha256':hashlib.sha256(first.read(name)).hexdigest()}
    (root/'neighbor-guard-omitted-identity.json').write_text(json.dumps(identity,indent=2));print(json.dumps(identity))
