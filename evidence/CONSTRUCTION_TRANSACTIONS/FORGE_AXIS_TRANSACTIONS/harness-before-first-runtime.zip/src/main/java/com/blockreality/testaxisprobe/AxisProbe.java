package com.blockreality.testaxisprobe;

import com.google.gson.*;
import com.mojang.authlib.GameProfile;
import net.minecraft.core.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.*;
import net.minecraft.server.level.*;
import net.minecraft.world.*;
import net.minecraft.world.item.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.*;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.util.FakePlayerFactory;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;
import java.io.*;
import java.lang.reflect.*;
import java.nio.channels.FileChannel;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.atomic.*;

/** Installed-server tests. No production classes, access transformers or test switches enter the ordinary jar. */
@Mod("br_axis_probe")
public final class AxisProbe {
    private static final Gson JSON=new GsonBuilder().setPrettyPrinting().create();
    private final List<String> checks=new ArrayList<>();
    private final List<Map<String,Object>> phases=new ArrayList<>();
    private final Map<String,Object> receipt=new LinkedHashMap<>();
    private final BlockPos cell=new BlockPos(1026,80,1026);
    private boolean cancel;
    private Path output,serverFolder;
    private String mode;
    private ServerLevel level;
    private ServerPlayer actor;
    private Class<?> serviceClass,managerClass;
    private Object service,manager,journal,metadata;
    private AtomicLong sequence;
    private long base,order,seq;
    private String before,after;
    private Object originalFaults;
    public AxisProbe() {
        MinecraftForge.EVENT_BUS.addListener(this::started);
        MinecraftForge.EVENT_BUS.addListener(EventPriority.HIGHEST,this::rightClick);
    }
    private void rightClick(PlayerInteractEvent.RightClickBlock event) { if(cancel && event.getPos().equals(cell))event.setCanceled(true); }
    private void started(ServerStartedEvent event) {
        try {
            output=Path.of(System.getProperty("br.axisOutput"));serverFolder=Path.of(System.getProperty("br.axisServer"));mode=System.getProperty("br.axisMode");
            require(output.isAbsolute() && Files.readString(output.resolve("OWNER")).strip().equals("block-reality-axis-runtime-v1"),"owned output");
            level=event.getServer().overworld();serviceClass=Class.forName("com.blockreality.impl.server.construction.ConstructionService");
            managerClass=Class.forName("com.blockreality.impl.server.StructureManager");
            Map<String,String> origins=new LinkedHashMap<>();
            for(String name:List.of("com.blockreality.impl.server.construction.ConstructionService","com.blockreality.impl.server.construction.CellStateImage",
                    "com.blockreality.impl.server.StructureManager","com.blockreality.core.transaction.ManufacturedRegistry")) {
                Class<?> type=Class.forName(name);String origin=type.getResource(type.getSimpleName()+".class").toString();origins.put(name,origin);
                require(origin.contains("blockreality-0.4.0-dev.jar") && !origin.contains("br-axis-probe.jar"),"ordinary jar origin "+type.getSimpleName());
            }
            receipt.put("classOrigins",origins);
            require((boolean)call(serviceClass,"available",event.getServer()),"service recovered before server-started/player access");
            service=((Map<?,?>)field(serviceClass,"SERVERS")).get(event.getServer());journal=field(service,"journal");metadata=field(service,"metadata");
            manager=call(managerClass,"of",level);sequence=(AtomicLong)field(Class.forName("com.blockreality.impl.net.BRNetwork"),"SEQUENCE");
            if(mode.startsWith("restart")) restart();
            else {
                codec();level.getChunk(cell.getX()>>4,cell.getZ()>>4);
                CompoundTag tag=new CompoundTag();tag.putString("Name","blockreality:steel_beam");CompoundTag properties=new CompoundTag();properties.putString("axis","x");tag.put("Properties",properties);
                BlockState state=NbtUtils.readBlockState(BuiltInRegistries.BLOCK.asLookup(),tag);
                require(state.getBlock()!=Blocks.AIR && axis(state).equals("x"),"real registered structural fixture");
                level.setBlock(cell,state,3);
                actor=FakePlayerFactory.get(level,new GameProfile(UUID.fromString("0b4a485e-299f-428d-afbf-9486af690321"),"AxisFixture"));
                actor.gameMode.changeGameModeForPlayer(GameType.SURVIVAL);actor.setShiftKeyDown(true);near();
                ItemStack material=new ItemStack(Items.IRON_INGOT,7);material.getOrCreateTag().putString("br_axis_fixture","不扣除也不退款");actor.getInventory().setItem(9,material);
                installFaultObserver();
                if(mode.equals("control")) {
                    refusalCases();action(GameType.SURVIVAL);action(GameType.CREATIVE);
                    require((int)call(metadata,"ownedCells")==0,"legacy axis edits do not manufacture new piece IDs");
                } else action(GameType.SURVIVAL);
            }
            receipt.put("status","PASS");
        } catch(Throwable problem) {
            receipt.put("status","FAIL");receipt.put("failure",problem.toString());var trace=new StringWriter();problem.printStackTrace(new PrintWriter(trace));receipt.put("trace",trace.toString());
        } finally {
            try { if(journal!=null && originalFaults!=null)setField(journal,"faults",originalFaults); }catch(Exception ignored){}
            receipt.put("checks",checks);receipt.put("phases",phases);receipt.put("syntheticPlayer",true);
            try{if(output!=null)Files.writeString(output.resolve("result.json"),JSON.toJson(receipt)+"\n",StandardOpenOption.CREATE_NEW);}catch(Exception problem){problem.printStackTrace();}
            System.out.println("BR_AXIS_PROBE "+mode+" "+receipt.get("status")+" checks="+checks.size());event.getServer().halt(false);
        }
    }
    private void codec() throws Exception {
        Class<?> codec=Class.forName("com.blockreality.impl.server.construction.CellStateImage");
        Class<?> canonical=Class.forName("com.blockreality.impl.server.construction.CanonicalNbt");
        Class<?> value=Class.forName("com.blockreality.core.transaction.ConstructionTransaction$Value");
        for(BlockState state:List.of(Blocks.AIR.defaultBlockState(),Blocks.STONE.defaultBlockState(),Blocks.OAK_LOG.defaultBlockState().setValue(RotatedPillarBlock.AXIS,Direction.Axis.Z)))
            require(call(codec,"decode",call(codec,"encode",state))==state,"exact real registry round trip "+state);
        CompoundTag original=NbtUtils.writeBlockState(Blocks.OAK_LOG.defaultBlockState());
        for(int fault=0;fault<7;fault++) {
            CompoundTag changed=original.copy();switch(fault) {
                case 0->changed.putString("Name","missing:unknown");case 1->changed.remove("Name");
                case 2->changed.getCompound("Properties").putString("axis","invalid");case 3->changed.getCompound("Properties").putString("invented","yes");
                case 4->changed.putString("Properties","wrong type");case 5->changed.getCompound("Properties").putInt("axis",1);case 6->changed.putString("extra","not a block-state field");
            }
            Object encoded=call(value,"of",call(canonical,"encode",changed,1<<20));
            ioRefuses(()->call(codec,"decode",encoded),"real registry refuses invalid state "+fault);
        }
        ioRefuses(()->call(codec,"decode",call(value,"missing")),"missing cell is not air");
        ioRefuses(()->call(codec,"decode",call(value,"of",(Object)new byte[0])),"empty cell image refuses");
    }
    private void refusalCases() throws Exception {
        String expected=axis(level.getBlockState(cell));long count=(long)call(metadata,"order"),revision=revision();
        cancel=true;interact();cancel=false;unchanged(expected,count,revision,"Forge RightClickBlock protection");
        actor.gameMode.changeGameModeForPlayer(GameType.ADVENTURE);interact();unchanged(expected,count,revision,"adventure permission");
        actor.gameMode.changeGameModeForPlayer(GameType.SURVIVAL);actor.moveTo(cell.getX()+100,cell.getY(),cell.getZ(),0,0);interact();unchanged(expected,count,revision,"server reach");near();
        actor.setShiftKeyDown(false);interact();unchanged(expected,count,revision,"sneak required");actor.setShiftKeyDown(true);
        actor.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(Items.STICK));interact();unchanged(expected,count,revision,"empty hand required");actor.setItemInHand(InteractionHand.MAIN_HAND,ItemStack.EMPTY);
    }
    private void unchanged(String state,long order,long revision,String name)throws Exception {
        require(axis(level.getBlockState(cell)).equals(state) && (long)call(metadata,"order")==order && revision()==revision,name+" changes no world/metadata/revision");
    }
    private void near(){actor.moveTo(cell.getX()+.5,cell.getY(),cell.getZ()+2.5,0,0);}
    private void interact(){actor.gameMode.useItemOn(actor,level,actor.getMainHandItem(),InteractionHand.MAIN_HAND,new BlockHitResult(Vec3.atCenterOf(cell),Direction.UP,cell,false));}
    private void action(GameType gameType)throws Exception {
        actor.gameMode.changeGameModeForPlayer(gameType);near();before=axis(level.getBlockState(cell));after=switch(before){case "x"->"y";case "y"->"z";default->"x";};
        base=revision();order=(long)call(metadata,"order");seq=sequence.get();long start=System.nanoTime();interact();
        require(axis(level.getBlockState(cell)).equals(after),gameType+" vanilla interaction commits axis");
        require(revision()==base+1,gameType+" exactly one public revision");require((long)call(metadata,"order")==order+1,gameType+" one committed metadata order");
        require(sequence.get()==seq+1,gameType+" exactly one result-envelope publication");
        require(declaredAxis()==axisWire(after),gameType+" observation publishes final declaration");
        require(actor.getInventory().getItem(9).getCount()==7 && actor.getInventory().getItem(9).getTag().getString("br_axis_fixture").equals("不扣除也不退款"),gameType+" inventory exact and unchanged");
        receipt.put("lastActionNanosRecordedOnly",System.nanoTime()-start);
    }
    private void installFaultObserver()throws Exception {
        Field slot=journal.getClass().getDeclaredField("faults");slot.setAccessible(true);originalFaults=slot.get(journal);Class<?> type=slot.getType();
        Object observer=Proxy.newProxyInstance(type.getClassLoader(),new Class<?>[]{type},(proxy,method,args)->{
            if(!method.getName().equals("at"))return method.getName().equals("toString")?"AxisProbeFaultObserver":method.getName().equals("hashCode")?System.identityHashCode(proxy):proxy==args[0];
            phase(args[0].toString(),args[1]);return null;
        });slot.set(journal,observer);
    }
    private void phase(String stage,Object entry)throws Exception {
        String phase=call(entry,"phase").toString();
        if(!phase.equals("PREPARED") && !phase.equals("COMMITTED"))return;
        boolean barrier=phase.equals("PREPARED")&&stage.equals("DIRECTORY_FORCED") || phase.equals("COMMITTED")&&stage.equals("TEMP_FORCED");
        if(barrier) {
            require((boolean)call(serviceClass,"busy",level.getServer()),phase+" owner remains private");
            call(managerClass,"observedStructure",level,cell,level.getBlockState(cell));
            boolean flight=((AtomicBoolean)field(manager,"inFlight")).get();
            call(managerClass,"onServerTick",new TickEvent.LevelTickEvent(LogicalSide.SERVER,TickEvent.Phase.END,level,()->true));
            call(managerClass,"sendSnapshot",actor);
            try {call(manager,"requestResolve");throw new AssertionError("reentrant resolve accepted");}catch(IllegalStateException expected){checks.add(phase+" reentrant resolve refuses");}
            require(((AtomicBoolean)field(manager,"inFlight")).get()==flight,phase+" native dispatch paused");
            require(revision()==base && sequence.get()==seq && (long)call(metadata,"order")==order && declaredAxis()==axisWire(before),phase+" no provisional revision/metadata/observation/envelope");
            phases.add(Map.of("phase",phase,"stage",stage,"liveAxis",axis(level.getBlockState(cell)),"publicRevision",revision(),"metadataOrder",order,"sequence",sequence.get()));
        }
        boolean crash=mode.equals("prepared")&&phase.equals("PREPARED")&&stage.equals("DIRECTORY_FORCED")
                || mode.equals("flushed")&&phase.equals("COMMITTED")&&stage.equals("TEMP_FORCED")
                || mode.equals("committed")&&phase.equals("COMMITTED")&&stage.equals("DIRECTORY_FORCED");
        if(crash) {
            Object request=call(entry,"request");
            Map<String,Object> expected=new LinkedHashMap<>();expected.put("kind",mode);expected.put("transaction",call(request,"id").toString());
            expected.put("baseRevision",base);expected.put("before",before);expected.put("after",after);expected.put("source",call(manager,"analysisSourceId").toString());
            Files.writeString(serverFolder.resolve("PROBE_EXPECTED.json"),JSON.toJson(expected),StandardOpenOption.CREATE_NEW);
            try(FileChannel channel=FileChannel.open(serverFolder.resolve("PROBE_EXPECTED.json"),StandardOpenOption.WRITE)){channel.force(true);}
            Path saved=Files.createDirectory(output.resolve("journal-at-interruption"));copyJournal(saved);
            receipt.put("status","INTERRUPTED");receipt.put("checks",checks);receipt.put("phases",phases);receipt.put("stage",stage);receipt.put("phase",phase);
            Files.writeString(output.resolve("result.json"),JSON.toJson(receipt),StandardOpenOption.CREATE_NEW);
            System.out.println("BR_AXIS_PROBE deliberate halt "+mode);Runtime.getRuntime().halt(73);
        }
    }
    private void restart()throws Exception {
        JsonObject expected=JsonParser.parseString(Files.readString(serverFolder.resolve("PROBE_EXPECTED.json"))).getAsJsonObject();String kind=expected.get("kind").getAsString();
        boolean committed=kind.equals("committed");long floor=expected.get("baseRevision").getAsLong()+(committed?1:0);
        require(revision()>=floor,"transaction revision floor restored before chunk load");
        require((int)call(manager,"structuralBlockCount")>=1,"legacy coverage survived interrupted publication");
        require(!call(manager,"analysisSourceId").toString().equals(expected.get("source").getAsString()),"new server result source rejects prior-session packets");
        UUID id=UUID.fromString(expected.get("transaction").getAsString());Object entry=((Optional<?>)call(journal,"verify",id)).orElseThrow();
        require(call(entry,"phase").toString().equals(committed?"COMMITTED":"ABORTED"),"restart terminal decision matches interruption");
        require((long)call(metadata,"order")== (committed?1L:0L),"restart metadata decision is not replayed twice");
        level.getChunk(cell.getX()>>4,cell.getZ()>>4);
        require(axis(level.getBlockState(cell)).equals(expected.get(committed?"after":"before").getAsString()),"restart exact world cell matches durable decision");
        require(declaredAxis()==axisWire(axis(level.getBlockState(cell))),"restart observation reads current cell instead of replaying old metadata");
        Path saved=Files.createDirectory(output.resolve("journal-after-recovery"));copyJournal(saved);
        String digest=hash(Files.readAllBytes(((Path)field(journal,"directory")).resolve("txn-"+id+".brtx")));
        Path prior=serverFolder.resolve("PROBE_RECOVERED_SHA.txt");
        if(mode.equals("restart-again"))require(Files.readString(prior).equals(digest),"second restart leaves terminal journal bytes unchanged");
        else Files.writeString(prior,digest,StandardOpenOption.CREATE_NEW);
        receipt.put("revisionFloor",floor);receipt.put("currentRevision",revision());receipt.put("journalSha256",digest);
    }
    private void copyJournal(Path dest)throws Exception {
        Path source=(Path)field(journal,"directory");
        try(var files=Files.list(source)){for(Path p:files.filter(Files::isRegularFile).toList())Files.copy(p,dest.resolve(p.getFileName()));}
    }
    private long revision()throws Exception{return ((Number)call(call(call(manager,"gate"),"current"),"value")).longValue();}
    private int declaredAxis()throws Exception {
        Object ledger=call(manager,"constructionObjects");Map<?,?> declarations=(Map<?,?>)call(ledger,"declarations");
        Object key=Class.forName("com.blockreality.api.geom.BlockKey").getConstructor(int.class,int.class,int.class).newInstance(cell.getX(),cell.getY(),cell.getZ());
        return (int)call(Objects.requireNonNull(declarations.get(key),"missing declaration"),"axis");
    }
    private static String axis(BlockState state){return NbtUtils.writeBlockState(state).getCompound("Properties").getString("axis");}
    private static int axisWire(String axis){return switch(axis){case "x"->0;case "y"->1;case "z"->2;default->-1;};}
    private interface Checked{void run()throws Exception;}
    private void ioRefuses(Checked operation,String name)throws Exception{try{operation.run();throw new AssertionError(name+" accepted");}catch(IOException expected){checks.add(name);}}
    private void require(boolean value,String name){if(!value)throw new AssertionError(name);checks.add(name);}
    private static Object field(Object target,String name)throws Exception{Class<?> type=target instanceof Class<?> c?c:target.getClass();Field f=type.getDeclaredField(name);f.setAccessible(true);return f.get(target instanceof Class<?>?null:target);}
    private static void setField(Object target,String name,Object value)throws Exception{Field f=target.getClass().getDeclaredField(name);f.setAccessible(true);f.set(target,value);}
    private static Object call(Object target,String name,Object...args)throws Exception {
        Class<?> type=target instanceof Class<?> c?c:target.getClass();
        for(Method method:type.getDeclaredMethods()) {
            if(!method.getName().equals(name) || method.getParameterCount()!=args.length)continue;
            boolean match=true;Class<?>[] parameters=method.getParameterTypes();
            for(int i=0;i<args.length;i++){Class<?> p=parameters[i];if(p==int.class)p=Integer.class;else if(p==long.class)p=Long.class;else if(p==boolean.class)p=Boolean.class;if(args[i]!=null&&!p.isInstance(args[i]))match=false;}
            if(!match)continue;method.setAccessible(true);
            try{return method.invoke(target instanceof Class<?>?null:target,args);}catch(InvocationTargetException problem){if(problem.getCause() instanceof Exception exception)throw exception;if(problem.getCause() instanceof Error error)throw error;throw new AssertionError(problem.getCause());}
        }
        throw new NoSuchMethodException(type.getName()+"."+name);
    }
    private static String hash(byte[] bytes)throws Exception{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));}
}
