package com.blockreality.testcaptureprobe;

import com.google.gson.GsonBuilder;
import net.minecraft.core.*;
import net.minecraft.nbt.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.storage.ChunkSerializer;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.capabilities.*;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.level.ChunkDataEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.fml.common.Mod;
import java.io.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;

@Mod("br_capture_probe")
public final class LiveCaptureProbe {
    private final List<String> checks=new ArrayList<>();
    private final Map<String,Object> receipt=new LinkedHashMap<>();
    private final Map<Object,ProbeCapability> capabilities=new IdentityHashMap<>();
    private final ChunkPos position=new ChunkPos(64,64);
    private int hookMode,hookCalls;
    private CompoundTag retained;
    private Path output;
    public LiveCaptureProbe() {
        MinecraftForge.EVENT_BUS.addGenericListener(LevelChunk.class,this::chunkCapabilities);
        MinecraftForge.EVENT_BUS.addGenericListener(BlockEntity.class,this::entityCapabilities);
        MinecraftForge.EVENT_BUS.addListener(this::save);
        MinecraftForge.EVENT_BUS.addListener(this::started);
    }
    private void chunkCapabilities(AttachCapabilitiesEvent<LevelChunk> event) {
        if(event.getObject().getPos().equals(position)) attach(event);
    }
    private void entityCapabilities(AttachCapabilitiesEvent<BlockEntity> event) {
        if(new ChunkPos(event.getObject().getBlockPos()).equals(position)) attach(event);
    }
    private <T> void attach(AttachCapabilitiesEvent<T> event) {
        ProbeCapability capability=new ProbeCapability();capabilities.put(event.getObject(),capability);
        event.addCapability(new ResourceLocation("br_capture_probe","preserve"),capability);
    }
    private void save(ChunkDataEvent.Save event) {
        if(!event.getChunk().getPos().equals(position)) return;
        hookCalls++;retained=event.getData();
        if(hookMode==1) retained.putString("br_capture_probe:custom","存檔欄位完整保存");
        if(hookMode==2) retained.remove("block_entities");
        if(hookMode==3) retained.getCompound("ForgeCaps").putInt("unexpected",9);
        if(hookMode==4) throw new IllegalStateException("intentional save hook failure");
        if(hookMode==5) capabilities.get(event.getChunk()).value++;
    }
    private static final class ProbeCapability implements ICapabilitySerializable<CompoundTag> {
        int calls,throwAt,value=12345;
        public <T> LazyOptional<T> getCapability(Capability<T> capability,Direction side) { return LazyOptional.empty(); }
        public CompoundTag serializeNBT() {
            calls++;if(calls==throwAt) throw new IllegalStateException("intentional capability failure at call "+calls);
            CompoundTag tag=new CompoundTag();tag.putInt("value",value);tag.putString("label","能力原始資料");
            tag.putLongArray("exact",new long[]{Long.MIN_VALUE,Long.MAX_VALUE,-1,0});return tag;
        }
        public void deserializeNBT(CompoundTag tag) { value=tag.getInt("value"); }
        void reset(int fail) { calls=0;throwAt=fail;value=12345; }
    }
    private void started(ServerStartedEvent event) {
        try {
            output=Path.of(System.getProperty("br.captureProbeOutput"));
            require(output.isAbsolute() && Files.readString(output.resolve("OWNER")).strip().equals("block-reality-live-capture-runtime-v1"),"owned output");
            ServerLevel level=event.getServer().overworld();require(event.getServer().isSameThread(),"real server thread");
            Class<?> captureClass=Class.forName("com.blockreality.impl.server.construction.LiveChunkCapture");
            Class<?> writer=Class.forName("com.blockreality.impl.server.construction.ChunkFileParticipant");
            Map<String,String> origins=new LinkedHashMap<>();
            for(Class<?> type:List.of(captureClass,writer)) {
                String origin=type.getResource(type.getSimpleName()+".class").toString();origins.put(type.getName(),origin);
                require(origin.contains("blockreality-0.4.0-dev.jar") && !origin.contains("br-capture-probe.jar"),"ordinary jar origin "+type.getSimpleName());
            }
            receipt.put("classOrigins",origins);
            Method capture=method(captureClass,"capture",ServerLevel.class,LevelChunk.class);
            Object participant=call(method(writer,"bind",ServerLevel.class),null,level);
            Method captureBatch=method(writer,"capture",ServerLevel.class,Collection.class),read=method(writer,"read",Collection.class);
            Class<?> batchClass=Class.forName("com.blockreality.impl.server.construction.ChunkFileParticipant$Batch");
            Method persist=method(writer,"persist",batchClass),image=method(batchClass,"image",ChunkPos.class);
            LevelChunk chunk=level.getChunk(position.x,position.z);
            BlockPos cell=new BlockPos(position.getMinBlockX()+2,80,position.getMinBlockZ()+2);
            level.setBlock(cell,Blocks.CHEST.defaultBlockState(),3);
            var chest=(net.minecraft.world.level.block.entity.ChestBlockEntity)level.getBlockEntity(cell);
            var item=new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.IRON_INGOT,7);
            item.getOrCreateTag().putString("br_probe","精確物品");chest.setItem(0,item);chest.setChanged();
            ProbeCapability chunkCap=capabilities.get(chunk),entityCap=capabilities.get(chest);
            require(chunkCap!=null && entityCap!=null,"real attached serializable chunk and chest capabilities");
            require(level.getChunkSource().getChunkNow(position.x,position.z)==chunk,"current loaded chunk without generation in capture");
            hookMode=1;hookCalls=0;
            CompoundTag captured=(CompoundTag)call(capture,null,level,chunk);
            require(hookCalls==1,"normal save event posted exactly once");
            require(captured.getString("br_capture_probe:custom").equals("存檔欄位完整保存"),"additive custom save data retained");
            require(captured.getCompound("ForgeCaps").getCompound("br_capture_probe:preserve").getInt("value")==12345,"chunk capability preserved");
            require(captured.getList("block_entities",Tag.TAG_COMPOUND).getCompound(0).getCompound("ForgeCaps")
                .getCompound("br_capture_probe:preserve").getInt("value")==12345,"chest capability preserved");
            retained.putString("br_capture_probe:custom","mutated after return");
            require(captured.getString("br_capture_probe:custom").equals("存檔欄位完整保存"),"private image unaffected by retained hook tag");
            Object batch=call(captureBatch,participant,level,List.of(position));call(persist,participant,batch);
            CompoundTag baseline=(CompoundTag)call(image,call(read,participant,List.of(position)),position);
            require(baseline.equals(call(image,batch,position)),"complete live batch durable readback");
            NbtIo.writeCompressed(baseline,output.resolve("live-checkpoint.nbt.gz").toFile());
            require(chunk.isUnsaved(),"checkpoint does not clear unsaved ownership");

            hookMode=0;
            for(boolean entity:new boolean[]{false,true}) for(int at:new int[]{1,2,3,4}) {
                chunkCap.reset(0);entityCap.reset(0);(entity?entityCap:chunkCap).reset(at);
                String name=(entity?"entity":"chunk")+" capability failure call "+at;
                refuses(()->call(captureBatch,participant,level,List.of(position)),name);
                chunkCap.reset(0);entityCap.reset(0);
                require(baseline.equals(call(image,call(read,participant,List.of(position)),position)),name+" leaves durable baseline unchanged");
            }
            // Demonstrate that the specific second-call failures really are swallowed by vanilla.
            chunkCap.reset(1);CompoundTag swallowed=ChunkSerializer.write(level,chunk);chunkCap.reset(0);
            require(!swallowed.contains("ForgeCaps"),"pinned vanilla swallows chunk capability exception");
            entityCap.reset(1);swallowed=ChunkSerializer.write(level,chunk);entityCap.reset(0);
            require(swallowed.getList("block_entities",Tag.TAG_COMPOUND).isEmpty(),"pinned vanilla swallows block entity exception");
            for(int mode:new int[]{2,3,4,5}) {
                hookMode=mode;refuses(()->call(capture,null,level,chunk),"save hook refusal mode "+mode);
                chunkCap.reset(0);entityCap.reset(0);
            }
            hookMode=0;
            ChunkPos pendingPosition=new ChunkPos(65,64);LevelChunk pending=level.getChunk(pendingPosition.x,pendingPosition.z);
            CompoundTag pendingTag=new CompoundTag();pendingTag.putString("id","missing:preserve_unknown");
            pendingTag.putInt("x",pendingPosition.getMinBlockX()+1);pendingTag.putInt("y",80);pendingTag.putInt("z",pendingPosition.getMinBlockZ()+1);
            pendingTag.putString("do_not_lose","原始待載入資料");pending.setBlockEntityNbt(pendingTag.copy());
            BlockPos pendingCell=new BlockPos(pendingTag.getInt("x"),80,pendingTag.getInt("z"));
            refuses(()->call(captureBatch,participant,level,List.of(position,pendingPosition)),"batch with pending entity refuses before store");
            require(pendingTag.equals(pending.getBlockEntityNbt(pendingCell)),"pending NBT was not promoted or erased");
            require(baseline.equals(call(image,call(read,participant,List.of(position)),position)),"later capture refusal preserves earlier chunk on disk");
            NbtIo.writeCompressed(pending.getBlockEntityNbt(pendingCell),output.resolve("refused-pending.nbt.gz").toFile());
            int hooksBefore=hookCalls;ChunkPos unloaded=new ChunkPos(10000,10000);
            refuses(()->call(captureBatch,participant,level,List.of(position,unloaded)),"unloaded batch key refuses");
            require(hooksBefore==hookCalls && level.getChunkSource().getChunkNow(unloaded.x,unloaded.z)==null,"all keys validated before hooks and no chunk generation");
            refuses(()->call(captureBatch,participant,level,List.of(position,position)),"duplicate batch refuses");
            refuses(()->call(captureBatch,participant,event.getServer().getLevel(net.minecraft.world.level.Level.NETHER),List.of(position)),"foreign level binding refuses");
            var executor=Executors.newSingleThreadExecutor();
            try {
                require(executor.submit(()-> { try { call(capture,null,level,chunk);return false; }catch(IOException expected){return true;}catch(Exception failure){throw new RuntimeException(failure);} }).get(10,TimeUnit.SECONDS),"off-thread live capture refuses");
            }finally{executor.shutdownNow();}
            require(chest.getItem(0).getCount()==7 && chest.getItem(0).getTag().getString("br_probe").equals("精確物品"),"live inventory unchanged across captures and refusals");
            hookMode=1;List<Long> nanos=new ArrayList<>();
            for(int i=0;i<12;i++) { long start=System.nanoTime();call(capture,null,level,chunk);if(i>=2)nanos.add(System.nanoTime()-start); }
            receipt.put("captureNanosRecordedOnly",nanos);receipt.put("status","PASS");
        }catch(Throwable failure){
            receipt.put("status","FAIL");receipt.put("failure",failure.toString());
            var trace=new StringWriter();failure.printStackTrace(new PrintWriter(trace));receipt.put("trace",trace.toString());
        }finally{
            hookMode=0;capabilities.values().forEach(capability->capability.reset(0));receipt.put("checks",checks);
            try{if(output!=null)Files.writeString(output.resolve("result.json"),new GsonBuilder().setPrettyPrinting().create().toJson(receipt)+"\n",StandardOpenOption.CREATE_NEW);}catch(Exception failure){failure.printStackTrace();}
            System.out.println("BR_CAPTURE_PROBE "+receipt.get("status")+" checks="+checks.size());event.getServer().halt(false);
        }
    }
    private interface Checked { void run() throws Exception; }
    private void refuses(Checked operation,String name) throws Exception {
        try{operation.run();throw new AssertionError(name+" accepted");}catch(IOException expected){checks.add(name);}
    }
    private void require(boolean value,String name){if(!value)throw new AssertionError(name);checks.add(name);}
    private static Method method(Class<?> type,String name,Class<?>... args)throws Exception{Method m=type.getDeclaredMethod(name,args);m.setAccessible(true);return m;}
    private static Object call(Method method,Object target,Object... args)throws Exception{
        try{return method.invoke(target,args);}catch(InvocationTargetException failure){
            if(failure.getCause() instanceof Exception exception)throw exception;if(failure.getCause() instanceof Error error)throw error;throw new AssertionError(failure.getCause());
        }
    }
}
