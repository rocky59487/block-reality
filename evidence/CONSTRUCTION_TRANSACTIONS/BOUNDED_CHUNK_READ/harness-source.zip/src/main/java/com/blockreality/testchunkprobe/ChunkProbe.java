package com.blockreality.testchunkprobe;

import com.google.gson.GsonBuilder;
import com.mojang.datafixers.util.Either;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.*;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.chunk.storage.*;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.util.ObfuscationReflectionHelper;
import java.io.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Supplier;

/** Isolated installed-server harness. This separate test mod never enters Block Reality's jar. */
@Mod("br_chunk_probe")
public final class ChunkProbe {
    private static final int LIMIT=16*1024*1024;
    private final List<String> checks=new ArrayList<>();
    private final Map<String,Object> receipt=new LinkedHashMap<>();
    private Path output;
    public ChunkProbe() { MinecraftForge.EVENT_BUS.addListener(this::started); }

    private void started(ServerStartedEvent event) {
        try {
            output=Path.of(System.getProperty("br.chunkProbeOutput"));
            require(output.isAbsolute() && Files.readString(output.resolve("OWNER")).strip().equals("block-reality-bounded-chunk-runtime-v1"),"owned output");
            ServerLevel level=event.getServer().overworld();
            require(event.getServer().isSameThread(),"real server owner thread");
            Class<?> reader=Class.forName("com.blockreality.impl.server.construction.BoundedChunkRead");
            Class<?> writer=Class.forName("com.blockreality.impl.server.construction.ChunkFileParticipant");
            Map<String,String> origins=new LinkedHashMap<>();
            for(Class<?> type:List.of(reader,writer)) {
                String origin=type.getResource(type.getSimpleName()+".class").toString();origins.put(type.getName(),origin);
                require(origin.contains("blockreality-0.4.0-dev.jar") && !origin.contains("br-chunk-probe.jar"),"ordinary jar origin "+type.getSimpleName());
            }
            receipt.put("classOrigins",origins);
            Method load=method(reader,"load",IOWorker.class,ChunkPos.class);
            Object participant=call(method(writer,"bind",ServerLevel.class),null,level);
            Method prepare=method(writer,"prepare",Map.class),read=method(writer,"read",Collection.class);
            Class<?> batch=Class.forName("com.blockreality.impl.server.construction.ChunkFileParticipant$Batch");
            Method persist=method(writer,"persist",batch),image=method(batch,"image",ChunkPos.class);
            ChunkPos pos=new ChunkPos(64,64);BlockPos cell=new BlockPos(pos.getMinBlockX()+2,80,pos.getMinBlockZ()+2);
            level.getChunk(pos.x,pos.z);level.setBlock(cell,Blocks.CHEST.defaultBlockState(),3);
            var chest=(net.minecraft.world.level.block.entity.ChestBlockEntity)level.getBlockEntity(cell);
            var item=new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.IRON_INGOT,7);
            item.getOrCreateTag().putString("br_probe","完整資料");chest.setItem(0,item);chest.setChanged();
            CompoundTag original=ChunkSerializer.write(level,level.getChunk(pos.x,pos.z));
            Object baseline=call(prepare,participant,Map.of(pos,original));call(persist,participant,baseline);
            Object actual=call(read,participant,List.of(pos));
            require(original.equals(call(image,actual,pos)),"real level full NBT checkpoint and readback");
            CompoundTag changed=original.copy();changed.putString("br_probe_unrelated","must survive complete readback");
            call(persist,participant,call(prepare,participant,Map.of(pos,changed)));
            require(changed.equals(call(image,call(read,participant,List.of(pos)),pos)),"real level complete after-image");
            call(persist,participant,baseline);
            require(original.equals(call(image,call(read,participant,List.of(pos)),pos)),"real level exact baseline restoration");
            require(level.getBlockState(cell).is(Blocks.CHEST) && chest.getItem(0).getCount()==7
                && chest.getItem(0).getTag().getString("br_probe").equals("完整資料"),"live chest and exact custom inventory remain unchanged");
            NbtIo.writeCompressed(original,output.resolve("live-chunk-baseline.nbt.gz").toFile());

            // Independent fixture files belong only to this harness; the production reader still runs from the installed jar.
            byte[] encoded=nbt(original);var duplicate=new ByteArrayOutputStream();duplicate.write(encoded,0,encoded.length-1);
            var data=new DataOutputStream(duplicate);data.writeByte(3);data.writeUTF("xPos");data.writeInt(pos.x);data.writeByte(0);
            rejected(reader,load,pos,duplicate.toByteArray(),"duplicate");
            CompoundTag large=original.copy();large.putByteArray("oversized",new byte[LIMIT+1]);
            rejected(reader,load,pos,nbt(large),"oversized");
            receipt.put("status","PASS");
        } catch(Throwable failure) {
            receipt.put("status","FAIL");receipt.put("failure",failure.toString());
            var trace=new StringWriter();failure.printStackTrace(new PrintWriter(trace));receipt.put("trace",trace.toString());
        } finally {
            receipt.put("checks",checks);
            try {
                if(output!=null) Files.writeString(output.resolve("result.json"),new GsonBuilder().setPrettyPrinting().create().toJson(receipt)+"\n",StandardOpenOption.CREATE_NEW);
            } catch(Exception failure) { failure.printStackTrace(); }
            System.out.println("BR_CHUNK_PROBE "+receipt.get("status")+" checks="+checks.size());
            event.getServer().halt(false);
        }
    }

    private void rejected(Class<?> reader,Method load,ChunkPos pos,byte[] bytes,String name) throws Exception {
        Path folder=Files.createDirectory(output.resolve(name));
        Files.writeString(folder.resolve("raw-size-sha256.txt"),bytes.length+"\n"+hash(bytes)+"\n");
        try(var worker=new FixtureWorker(folder.resolve("region"))) {
            Method submit=ObfuscationReflectionHelper.findMethod(IOWorker.class,"m_63545_",Supplier.class);
            Field storage=ObfuscationReflectionHelper.findField(IOWorker.class,"f_63518_");
            Method region=ObfuscationReflectionHelper.findMethod(RegionFileStorage.class,"m_63711_",ChunkPos.class);
            Supplier<Either<Void,Exception>> rawWrite=() -> {
                try {
                    RegionFile file=(RegionFile)call(region,storage.get(worker),pos);
                    try(var out=file.getChunkDataOutputStream(pos)) { out.write(bytes); }
                    return Either.left(null);
                } catch(Exception failure) { return Either.right(failure); }
            };
            ((CompletableFuture<?>)call(submit,worker,rawWrite)).get(10,TimeUnit.SECONDS);
            worker.synchronize(true).get(10,TimeUnit.SECONDS);Map<String,String> before=hashes(folder.resolve("region"));
            try {
                ((CompletableFuture<?>)call(load,null,worker,pos)).get(10,TimeUnit.SECONDS);
                throw new AssertionError(name+" was accepted");
            } catch(ExecutionException failure) {
                require(failure.getCause() instanceof IOException,"installed reader refuses "+name);
            }
            require(before.equals(hashes(folder.resolve("region"))),"installed refusal preserves "+name+" region bytes");
            Files.writeString(folder.resolve("region-hashes.json"),new GsonBuilder().setPrettyPrinting().create().toJson(before));
        }
    }
    private static final class FixtureWorker extends IOWorker { FixtureWorker(Path path) { super(path,false,"br-installed-chunk-fixture"); } }
    private void require(boolean value,String name) { if(!value) throw new AssertionError(name);checks.add(name); }
    private static Method method(Class<?> type,String name,Class<?>... args) throws Exception { Method m=type.getDeclaredMethod(name,args);m.setAccessible(true);return m; }
    private static Object call(Method method,Object target,Object... args) throws Exception {
        try { return method.invoke(target,args); }
        catch(InvocationTargetException failure) {
            if(failure.getCause() instanceof Exception exception) throw exception;
            if(failure.getCause() instanceof Error error) throw error;
            throw new AssertionError(failure.getCause());
        }
    }
    private static byte[] nbt(CompoundTag tag) throws IOException { var bytes=new ByteArrayOutputStream();NbtIo.write(tag,new DataOutputStream(bytes));return bytes.toByteArray(); }
    private static String hash(byte[] bytes) throws Exception { return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes)); }
    private static Map<String,String> hashes(Path root) throws Exception {
        var result=new TreeMap<String,String>();
        try(var files=Files.walk(root)) { for(Path p:files.filter(Files::isRegularFile).toList()) result.put(root.relativize(p).toString(),hash(Files.readAllBytes(p))); }
        return result;
    }
}
